package com.xxxx.interproc;

public class SetNullMethodCase {
    public void method1() {
        Inited obj = new Inited();
        obj.field.toString();// no warning: this won't cause npe
        obj.setNull();
        obj.field.toString();// one warning: this will cause npe.
    }
    public static class Inited {
        public Object field;
        public Inited() {
            this.field = new Object();
        }
        public void setNull() {
            this.field = null;
        }
    }
}
