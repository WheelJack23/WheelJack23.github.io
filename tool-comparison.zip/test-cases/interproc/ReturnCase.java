package com.xxxx.interproc;


public class ReturnCase {
    public void entry() {
        Object obj1 = m1();
        obj1.toString();// one warning
        Object obj2 = m2();// no warning
        if (obj2 != null) obj2.toString();
    }
    public Object m1() {
        return null;// one warning
    }
    public Object m2() {
        return null;// no warning
    }
}
