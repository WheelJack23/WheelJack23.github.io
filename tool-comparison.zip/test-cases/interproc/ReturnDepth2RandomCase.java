package com.xxxx.interproc;

public class ReturnDepth2RandomCase {
    public void method1() {
        Object a = method2();
        a.toString();// one warning: will cause npe
    }

    public Object method2() {
        if (Math.random() > 0.5) return method3();
        return new Object();
    }
    public Object method3() {
        if (Math.random() > 0.5) return null;// one warning
        return new Object();
    }
}
