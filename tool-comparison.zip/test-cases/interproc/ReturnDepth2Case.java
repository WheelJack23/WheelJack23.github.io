package com.xxxx.interproc;

public class ReturnDepth2Case {
    public void method1() {
        Object a = method2();
        a.toString();// warning: will cause npe
    }

    public Object method2() {
        return method3();
    }
    public Object method3() {
        return null;
    }
}
