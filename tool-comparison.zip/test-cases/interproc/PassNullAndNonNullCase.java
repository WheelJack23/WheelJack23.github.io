package com.xxxx.interproc;

public class PassNullAndNonNullCase {
    public void method1() {
        method3(null); // one warning: shouldn't pass null value
    }
    public void method2() {
        method3(new Object());
    }
    public void method3(Object obj) {
        System.out.println(obj.toString()); // one warning: method1 passes null value.
    }

}
