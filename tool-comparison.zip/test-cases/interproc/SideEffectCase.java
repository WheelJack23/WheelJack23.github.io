package com.xxxx.interproc;

public class SideEffectCase {
    public void method1() {
        NotInited obj = new NotInited();
        obj.field.toString();// one warning
        obj.setField(new Object());
        obj.field.toString();// no warning
        obj.setField(null);
        obj.field.toString(); // one warning
    }
    public static class NotInited {
        public Object field;
        public NotInited() {}
        public void setField(Object field) {
            this.field = field;
        }
    }
}
