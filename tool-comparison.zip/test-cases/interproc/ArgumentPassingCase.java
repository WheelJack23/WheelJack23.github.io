package com.xxxx.interproc;

public class ArgumentPassingCase {
    public void entry() {
        m1(new Object());// no warning: for spotbugs confusion
        m2(null, null, null);
    }
    private void m1(Object obj) {
        if (obj == null) {
            System.out.println();
        }
        obj.toString();// no warning
    }
    private void m2(Object p1, Object p2, Object p3) {// no warning: p2 for type-based ones
        p1.toString();// one warning: p1
        if (p3 == null) return;
        p3.toString(); // no warning: p2 for type-based ones
    }

}
