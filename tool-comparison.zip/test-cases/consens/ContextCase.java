package com.xxxx.consens;

public class ContextCase {
    public void m1() {
        String a = cut(null, 0, 1);
        a.hashCode();// NPE
        String b = cut("abc", 1, 2);
        b.hashCode();
    }

    public String cut(String str, int start, int end) {
        if (str == null) return null;
        return str.substring(start, end);
    }
}
