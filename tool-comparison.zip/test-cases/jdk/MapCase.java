package com.xxxx.jdk;

import java.util.HashMap;
import java.util.Map;


public class MapCase {
    public void method1() {
        Map<String, String> map = new HashMap<>();
        map.get("not existed").toString();// one warning: map will return null when the key doesn't exist.
        map.put("exist1", null);
        map.get("exist1").toString();// one warning: map will return null because the value is null.
        map.put("exist2", "value");
        map.get("exist2").toString();// no warning
        map.put(null, "value");// no warning
    }
}
