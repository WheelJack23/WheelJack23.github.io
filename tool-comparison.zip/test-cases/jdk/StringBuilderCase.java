package com.xxxx.jdk;

public class StringBuilderCase {
    public void method1() {
        StringBuilder sb = new StringBuilder();
        sb.append("hello").append(" world");// no warning
        sb.toString();// no warning
    }
}
