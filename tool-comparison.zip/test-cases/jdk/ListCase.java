package com.xxxx.jdk;

import java.util.ArrayList;
import java.util.List;


public class ListCase {
    public void method1() {
        List<String> list = new ArrayList<>();
        list.add(null);// one warning
        list.add("abc");
        list.get(0).toString();// one warning
    }
}
