package com.xxxx.fieldsens;

public class InitializationCase {
    private Object f1,f2;
    public InitializationCase() {}
    @Override
    public String toString() {
        return "{field1:"+ f1.toString()+",field2:" // NPE
                +(f2==null? "N/A":f2.toString())+'}';
    }
}