package com.xxxx.fieldsens;

public class AliasCase {
    public void entry() {
        Inited a = new Inited();
        Inited b = a;
        b.field.toString();// no warning
        a.field = null;
        b.field.toString();// one warning
    }
    public static class Inited {
        public Object field = new Object();
        public Inited() {}
    }
}