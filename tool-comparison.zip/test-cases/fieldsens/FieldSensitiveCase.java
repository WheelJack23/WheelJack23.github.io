package com.xxxx.fieldsens;

public class FieldSensitiveCase {
    public void method1() {
        Container a = new Container();
        a.field1 = new Object();
        a.field2 = null;
        a.field1.toString();// no warning
        a.field2.toString();// one warning
    }
    public class Container {
        public Object field1;
        public Object field2;
    }
}
