package com.xxxx.fieldsens;

public class InitMethodCase {
    private class Complicated {
        public Object field;
        public Complicated() {
            init();
            field.toString();// no warning
        }
        public void init() {
            field = new Object();
        }
    }
}
