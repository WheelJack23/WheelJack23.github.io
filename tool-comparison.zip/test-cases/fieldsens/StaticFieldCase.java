package com.xxxx.fieldsens;


public class StaticFieldCase {
    public static Object field;
    public void method1() {
        if (field == null) field = new Object();
        field.toString();// no warning
    }
}
