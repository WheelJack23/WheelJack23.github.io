package com.xxxx.fieldsens;

public @interface Initializer {

}
