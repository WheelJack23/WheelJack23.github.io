package com.xxxx.fieldsens;

public class ComplicatedStructureCase {
    public void entry() {
        NotInited obj1 = new NotInited();
        NotInited obj2 = new NotInited();
        obj2.field = obj1;
        obj2.field.field.toString();// one warning
    }
    public static class NotInited {
        public NotInited field;
        public NotInited() {}
    }
}
