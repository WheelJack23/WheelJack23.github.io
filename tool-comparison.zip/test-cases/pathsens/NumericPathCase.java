package com.xxxx.pathsens;

public class NumericPathCase {
    public void method() {
        int c = 0;
        Object obj = null;
        if (c == 0) obj = new Object();
        obj.toString();// no warning
    }
}
