package com.xxxx.pathsens;

public class InstanceOfCase {
    public void method1(Object obj) {
        if (obj instanceof A) {
            A a = (A)obj;
            a.toString(); // no warning
        }
    }
    public class A {}
}
