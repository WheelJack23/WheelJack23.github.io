package com.xxxx.pathsens;

public class NullCheckCase {
    public void method1() {
        Object obj = null;
        if (obj == null) obj = new Object();
        obj.toString();// one warning
    }
}
