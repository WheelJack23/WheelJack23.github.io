package com.xxxx.objsens;

public class ObjectSensitiveCase {
    public void method1() {
        Container a = new Container();
        Container b = new Container();
        a.field = new Object();
        b.field = null;
        a.field.toString();// no warning
        b.field.toString();// one warning
    }

    private class Container {
        public Object field;
    }
}
