package com.xxxx.objsens;

public class AliasCase {
    public void m1() {
        Object a = new Object();
        Object b = a;
        b.toString();// no warning here
    }
}
