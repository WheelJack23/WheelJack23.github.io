# WheelJack
WheelJack is developed for npe detection and it depends on callgraph project and redundant-check-analysis. You should 
open the two projects and run `mvn install` to install the dependencies. WheelJack shares its nullness analysis and 
reachable analysis with redundant-check-analysis for they both need to track the nullness status of a program. 

Hope you have a good time exploring the codes!

## For anonymous reasons, we delete test code temporarily.