package analyses;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.nullness.NullnessTool;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.reachable.NotReachableCollection;
import edu.redundantcheck.analyses.reachable.ReachableTool;
import jdt.MethodHandleUtil;
import soot.*;
import soot.JastAddJ.ArithmeticExpr;
import soot.jimple.*;
import soot.jimple.internal.*;
import soot.toolkits.graph.UnitGraph;

import java.util.*;
import java.util.regex.Pattern;

// Intra-procedural analysis for NPE detection
public class NPEAnalysis extends DataflowAnalysis {
    private static final Pattern pattern = Pattern.compile("#[0-9]$");
    private Set<NPETool.DereferenceNode> nullDereferenceNodes;
    private Set<NPETool.DereferenceNode> unknownDereferenceNodes;
    private Map<Value, Value> stackVar2assign;

    public void putStackVarAssign(Stmt stmt) {
        if (stmt instanceof DefinitionStmt) {
            DefinitionStmt defStmt = (DefinitionStmt) stmt;
            Value left = defStmt.getLeftOp();
            Value right = defStmt.getRightOp();
            if (left instanceof Local) {
                stackVar2assign.put(left, right);
            }
        }
    }

    /**
     * convert value to string, especially for instance field and static field.
     * */
    private String getValueString(Value value, Set<Value> visited) {
        if (visited.contains(value)) return value.toString();
        visited.add(value);
        if (value instanceof JInstanceFieldRef) {
            JInstanceFieldRef instanceFieldRef = (JInstanceFieldRef) value;
            Value base = instanceFieldRef.getBase();
            SootField field = instanceFieldRef.getField();
            return getStackVarString(base, visited) + "." + field.getName();
        }
        if (value instanceof InvokeExpr) {
            InvokeExpr invokeExpr = (InvokeExpr) value;
            if (invokeExpr instanceof InstanceInvokeExpr) {
                return getInstanceInvokeStr((InstanceInvokeExpr) invokeExpr, visited);
            }
            else if (invokeExpr instanceof StaticInvokeExpr) {
                return getStaticInvokeStr((StaticInvokeExpr) invokeExpr,visited);
            }
            else {
                throw new RuntimeException(invokeExpr.getClass()+" invocation not handled.");
            }
        }
        if (value instanceof StaticFieldRef) {
            StaticFieldRef staticFieldRef = (StaticFieldRef) value;
            SootField field = staticFieldRef.getField();
            SootClass sootClass = field.getDeclaringClass();
            return sootClass.getShortName()+"."+field.getName();
        }
        if (value instanceof CastExpr) {
            value = ((CastExpr)value).getOp();
            return getStackVarString(value, visited);
        }
        if (value instanceof ArrayRef) {
            StringBuilder sb = new StringBuilder();
            ArrayRef arrayRef = (ArrayRef)value;
            sb.append(getStackVarString(arrayRef.getBase(),visited)).
                    append("[").append(getStackVarString(arrayRef.getIndex(),
                            visited)).append("]");
            return sb.toString();
        }
        if (value instanceof AbstractBinopExpr) {
            return getBinopExpr(value, visited);
        }
        return value.toString();
    }
    private String getBinopExpr(Value value, Set<Value> visited) {
        AbstractBinopExpr binopExpr = (AbstractBinopExpr) value;
        StringBuilder sb = new StringBuilder();
        sb.append(getStackVarString(binopExpr.getOp1(), visited));
        if (binopExpr instanceof AddExpr) sb.append(" + ");
        else if (binopExpr instanceof SubExpr) sb.append(" - ");
        else if (binopExpr instanceof RemExpr) sb.append(" % ");
        else if (binopExpr instanceof MulExpr) sb.append(" * ");
        else if (binopExpr instanceof DivExpr) sb.append(" / ");
        else sb.append(" op ");
        sb.append(getStackVarString(binopExpr.getOp2(), visited));
        return sb.toString();
    }

    private String getStaticInvokeStr(StaticInvokeExpr invokeExpr, Set<Value> visited) {
        StringBuilder sb = new StringBuilder();
        sb.append(invokeExpr.getMethod().getDeclaringClass().getShortName()).append(".");
        appendMethodArgs(sb, invokeExpr, visited);
        return sb.toString();
    }
    private void appendMethodArgs(StringBuilder sb, InvokeExpr invokeExpr, Set<Value> visited){
        sb.append(invokeExpr.getMethod().getName()).append("(");
        List<Value> args = invokeExpr.getArgs();
        if (!args.isEmpty()) {
            sb.append(getStackVarString(args.get(0), visited));
            for (int i = 1; i < args.size(); i++) {
                sb.append(",").append(getStackVarString(args.get(i), visited));
            }
        }
        sb.append(")");
    }

    private String getInstanceInvokeStr(InstanceInvokeExpr invokeExpr, Set<Value> visited) {
        StringBuilder sb = new StringBuilder();
        sb.append(getStackVarString(invokeExpr.getBase(), visited)).append(".");
        appendMethodArgs(sb, invokeExpr, visited);
        return sb.toString();
    }



    private static boolean isStackValueStr(String valueStr) {
        return valueStr.startsWith("$stack") || pattern.matcher(valueStr).find();
    }

    public String getStackVarString(Value value) {
        return getStackVarString(value, new HashSet<>());
    }

    // 如果有 $stack1 = a
    // 那么会返回 a
    private String getStackVarString(Value value, Set<Value> visited) {
        if (value instanceof CastExpr) {
            value = ((CastExpr)value).getOp();
        }
        String valStr = value.toString();
        if (stackVar2assign.containsKey(value) && isStackValueStr(valStr)) {
            if (stackVar2assign.get(value) == null || stackVar2assign.get(value) == NullConstant.v()) {
                return "VARIABLE";
            }
            return getValueString(stackVar2assign.get(value), visited);
        }
        return valStr;
    }


    public NotReachableCollection getNotReachableCollection() {
        return notReachableCollection;
    }

    /**
     * 直接传入参数的结论，进行下一步分析
     * */
    public NPEAnalysis(UnitGraph graph, ParamConclusion.BaseParamConclusion baseParamConclusion,
                       int paramCount, String declaringClass) {
        super(graph, baseParamConclusion, paramCount, declaringClass);
        this.nullDereferenceNodes = new HashSet<>();
        this.unknownDereferenceNodes = new HashSet<>();
        this.stackVar2assign = new HashMap<>();
        doAnalysis();
        // detect npe when VarStatus info is stable.
        for (Unit unit : unitGraph) {
            VarStatusInfo in = getFlowBefore(unit);
            NPETool.analyze((Stmt) unit, in, this);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void flowThrough(VarStatusInfo in, Unit unit,
                               List<VarStatusInfo> fallOuts, // 下一条语句
                               List<VarStatusInfo> branchOuts // 跳转
    ) {
        prepareFlowThrough();
        if (notReachableCollection.contains(unit)) {// 如果当前语句不可达
            handleUnreachableUnit(in, unit, fallOuts, branchOuts);
            return;
        }
        // showStatus(in, unit);
        Stmt s = (Stmt) unit;

        putStackVarAssign(s);


        // 分析Nullness
        NullnessTool.flowThrough(s, in, fallOuts, branchOuts, NullnessConfig.getInvocationDepth(), this);

        // 分析可达性
        ReachableTool.analyzeReachable(s, (UnitGraph) this.graph, in,this, fallOuts, branchOuts);
    }

    public Set<Unit> getCertainReachableSet() {
        return certainReachableSet;
    }

    public Set<Unit> getNotReachableSet() {
        return notReachableCollection.getNotReachableSet();
    }


    public Set<NPETool.DereferenceNode> getNullDereferenceNodes() {
        return nullDereferenceNodes;
    }

    public Set<NPETool.DereferenceNode> getUnknownDereferenceNodes() {
        return unknownDereferenceNodes;
    }
}