package analyses;

import analyses.analyzer.AnalyzerInNPE;
import analyses.analyzer.DfsAnalyzer;
import analyses.analyzer.TopoAnalyzer;
import analyses.exception.EmptyNodeSetException;
import analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;
import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.util.CallGraphUtil;
import edu.redundantcheck.util.Class2PathUtils;

import java.util.*;

// apply whole detection here.
public class NPEAnalyzer {

    public static CombineResult analyze(String inputJarPath, String[] methodNames, String inputSrcPath) {
        Class2PathUtils.initData(inputSrcPath);
        List<Node> nodes = CallGraphUtil.generateCallGraph(inputJarPath, methodNames);
        return analyzeNodes(nodes);
    }

    public static CombineResult analyzeSingleWar(String inputWarPath, String[] methodNames, String inputSrcPath) {
        Class2PathUtils.initData(inputSrcPath);
        List<Node> nodes = CallGraphUtil.generateCallGraphForSingleWar(inputWarPath, methodNames);
        return analyzeNodes(nodes);
    }

    public static CombineResult analyzeMultiModule(String projectPath, String[] methodNames) {
        Class2PathUtils.initData(projectPath);
        List<Node> nodes = CallGraphUtil.generateCallGraphForMultiModule(projectPath, methodNames);
//        if (nodes.size() > 10000) NullnessConfig.setReturnDepth(2);
//        else NullnessConfig.setReturnDepth(3);
        return analyzeNodes(nodes);
    }

    private static CombineResult analyzeNodes(List<Node> nodeSet) {
        if (nodeSet.size() == 0) throw new EmptyNodeSetException("No node provided.");
//        NPETool topoAnalyzer = new TopoAnalyzer();
//        return topoAnalyzer.analyzeNodes(nodeSet);
        AnalyzerInNPE analyzer = new TopoAnalyzer();
        return analyzer.analyzeNodes(nodeSet);
    }
}
