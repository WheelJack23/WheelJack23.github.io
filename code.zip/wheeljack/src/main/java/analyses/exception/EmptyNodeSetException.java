package analyses.exception;

public class EmptyNodeSetException extends RuntimeException {
    public EmptyNodeSetException(String msg) {
        super(msg);
    }
}
