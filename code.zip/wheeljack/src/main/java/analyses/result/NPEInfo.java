package analyses.result;

import com.alibaba.fastjson.JSONObject;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.VarStatus;

import java.io.File;
import java.util.Objects;

// NPE warning information
public class NPEInfo {
    protected String declaringClass;
    protected String declaringMethod;
    protected int lineNo;
    protected File javaFile;
    protected String dereferenceBase;
    protected String dereferencePart;// base + "." + method/field
    protected RiskLevel riskLevel;
    protected String nullValue;
    protected String projectName;
    private Boolean right;

    public NPEInfo() {

    }

    public NPEInfo(String declaringClass, int lineNo, RiskLevel riskLevel) {
        this.declaringClass = declaringClass;
        this.lineNo = lineNo;
        this.riskLevel = riskLevel;
    }

    public static NPEInfo getInstance(JSONObject record) {
        NPEInfo npeInfo = new NPEInfo();
        npeInfo.setRight(record.getBoolean("right"));
        npeInfo.setRiskLevel(RiskLevel.parse(record.getString("riskLevel")));
        npeInfo.setDeclaringClass(record.getString("declaringClass"));
        npeInfo.setDereferencePart(record.getString("dereferencePart"));
        npeInfo.setNullValue(record.getString("nullValue"));
        npeInfo.setLineNo(record.getInteger("lineNo"));
        npeInfo.setDereferenceBase(record.getString("dereferenceBase"));
        npeInfo.setDeclaringMethod(record.getString("declaringMethod"));
        npeInfo.setProjectName(record.getString("projectName"));
        if (record.getString("javaFile") != null) npeInfo.setJavaFile(new File(record.getString("javaFile")));
        return npeInfo;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NPEInfo npeInfo = (NPEInfo) o;
        return lineNo == npeInfo.lineNo && Objects.equals(declaringClass, npeInfo.declaringClass)
                && Objects.equals(declaringMethod, npeInfo.declaringMethod)
                && Objects.equals(dereferenceBase, npeInfo.dereferenceBase)
                && Objects.equals(dereferencePart, npeInfo.dereferencePart);
                // && riskLevel == npeInfo.riskLevel;
                // && Objects.equals(nullValue, npeInfo.nullValue);
    }

    public Boolean isRight() {
        return right;
    }

    public void setRight(Boolean right) {
        this.right = right;
    }

    @Override
    public int hashCode() {
        return Objects.hash(declaringClass, declaringMethod, lineNo, dereferenceBase, dereferencePart);
    }

    @Override
    public String toString() {
        return "{" +
                "\n\t\"projectName\": \"" + projectName + "\"" +
                "\n\t\"declaringClass\": \"" + declaringClass + "\"" +
                ",\n\t\"declaringMethod\": \"" + declaringMethod + "\"" +
                ",\n\t\"lineNo\": " + lineNo +
                ",\n\t\"dereference base\": " + dereferenceBase +
                ",\n\t\"dereference part\": " + dereferencePart +
                ",\n\t\"risk level\": " + riskLevel +
                ",\n\t\"nullValue\":" + nullValue +
                "\n}";
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;

    }

    public String getProjectName() {
        return projectName;
    }

    public void setNullValue(Null nullValue) {
        if (nullValue == null || nullValue == VarStatus.NULL) {
            this.nullValue = "none";
            return;
        }
        this.nullValue = nullValue.toString();
    }

    public void setNullValue(String nullStr) {
        this.nullValue = nullStr;
    }

    public String getNullValue() {
        return nullValue;
    }

    public String getDeclaringClass() {
        return declaringClass;
    }

    public void setDeclaringClass(String declaringClass) {
        this.declaringClass = declaringClass;
    }

    public String getDeclaringMethod() {
        return declaringMethod;
    }

    public void setDeclaringMethod(String declaringMethod) {
        this.declaringMethod = declaringMethod;
    }

    public int getLineNo() {
        return lineNo;
    }

    public void setLineNo(int lineNo) {
        this.lineNo = lineNo;
    }

    public File getJavaFile() {
        return javaFile;
    }

    public void setJavaFile(File javaFile) {
        this.javaFile = javaFile;
    }

    public void setDereferenceBase(String dereferenceBase) {
        this.dereferenceBase = dereferenceBase;
    }

    public String getDereferencePart() {
        return dereferencePart;
    }

    public void setDereferencePart(String dereferencePart) {
        this.dereferencePart = dereferencePart;
    }

    public String getDereferenceBase() {
        return dereferenceBase;
    }

    public RiskLevel getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(RiskLevel riskLevel) {
        this.riskLevel = riskLevel;
    }
}
