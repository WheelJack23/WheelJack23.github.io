package analyses.result;

import analyses.NPETool;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.UnknownHighRisk;
import edu.redundantcheck.analyses.status.VarStatus;

public enum RiskLevel {
    LOW("LOW"), MIDDLE("MIDDLE"),HIGH("HIGH");
    private String riskLevel;
    RiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public static RiskLevel parse(String str) {
        if (str.equals("LOW")) return LOW;
        if (str.equals("HIGH")) return HIGH;
        return MIDDLE;
    }
    @Override
    public String toString() {
        return riskLevel;
    }

    public static RiskLevel parseUnknownRiskLevel(VarStatus status) {
        if (status.nullStatus == VarStatus.Status.UNKNOWN_HIGH_RISK) {
            RiskLevel level = HIGH;
            // high accuracy
//            if (((UnknownHighRisk)status).getNullValue().getNullType() == Null.NullType.FROM_NULL_CHECK) {
//                level = MIDDLE;
//            }
            return level;
        }
        else if (status.nullStatus == VarStatus.Status.UNKNOWN_MID_RISK) {
            return RiskLevel.MIDDLE;
        }
        return RiskLevel.LOW;
    }
}
