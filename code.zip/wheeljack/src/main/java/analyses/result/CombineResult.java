package analyses.result;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import edu.callgraph.global.Global;
import edu.redundantcheck.util.ResultJson;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

// NPE detection result.
public class CombineResult {
    private List<NPEInfo> npeWarningsHighRisk;
    private List<NPEInfo> npeWarningsLowRisk;
    private List<NPEInfo> npeWarningsMiddleRisk;
    private List<NPEInfo> npeErrors;
    private List<MethodMisuseInfo> methodMisuseWarnings;
    private List<MethodMisuseInfo> methodMisuseErrors;

    public CombineResult() {
        this.npeErrors = new LinkedList<>();
        this.npeWarningsHighRisk = new LinkedList<>();
        this.npeWarningsLowRisk = new LinkedList<>();
        this.npeWarningsMiddleRisk = new LinkedList<>();
        this.methodMisuseErrors = new LinkedList<>();
        this.methodMisuseWarnings = new LinkedList<>();
    }

    public void loadData(List<NPEInfo> infos) {
        this.npeErrors = new ArrayList<>();
        this.npeWarningsHighRisk = new ArrayList<>();
        this.npeWarningsMiddleRisk = new ArrayList<>();
        this.npeWarningsLowRisk = new ArrayList<>();
        this.methodMisuseWarnings = new ArrayList<>();
        this.methodMisuseErrors = new ArrayList<>();
        for (NPEInfo info: infos) {
            if (info.getRiskLevel() == RiskLevel.HIGH) {
                this.npeWarningsHighRisk.add(info);
                continue;
            }
            this.npeWarningsMiddleRisk.add(info);
        }
    }

    public void loadData(JSONObject dataResult) {
        JSONArray npeErrors = dataResult.getJSONArray("npeErrors");
        this.npeErrors = toNpeInfos(npeErrors, RiskLevel.HIGH);
        JSONArray npeWarningsHighRiskJson = dataResult.getJSONArray("npeWarningsHighRisk");
        this.npeWarningsHighRisk = toNpeInfos(npeWarningsHighRiskJson, RiskLevel.HIGH);
        JSONArray npeWarningsMiddleRiskJson = dataResult.getJSONArray("npeWarningsMiddleRisk");
        this.npeWarningsMiddleRisk = toNpeInfos(npeWarningsMiddleRiskJson, RiskLevel.MIDDLE);
        JSONArray npeWarningsLowRiskJson = dataResult.getJSONArray("npeWarningsLowRisk");
        this.npeWarningsLowRisk = toNpeInfos(npeWarningsLowRiskJson, RiskLevel.LOW);
        JSONArray methodMisuseWarnings = new JSONArray();
        if (dataResult.containsKey("methodMisuseWarnings")) methodMisuseWarnings = dataResult.getJSONArray("methodMisuseWarnings");
        this.methodMisuseWarnings = toMethodMisuseInfo(methodMisuseWarnings);
        JSONArray methodMisuseErrors = new JSONArray();
        if (dataResult.containsKey("methodMisuseErrors")) methodMisuseErrors = dataResult.getJSONArray("methodMisuseErrors");
        this.methodMisuseErrors = toMethodMisuseInfo(methodMisuseErrors);
    }

    public int getTotalNpeWarningNum() {
        return npeWarningsHighRisk.size() + npeWarningsMiddleRisk.size() + npeWarningsLowRisk.size();
    }

    private List<MethodMisuseInfo> toMethodMisuseInfo(JSONArray methodMisuseArray) {
        List<MethodMisuseInfo> methodMisuseInfos = new ArrayList<>();
        for (int i = 0 ; i < methodMisuseArray.size(); i++) {
            JSONObject record = methodMisuseArray.getJSONObject(i);
            String calleeClass = record.getString("calleeClass");
            int lineNo = record.getInteger("callLineNo");
            MethodMisuseInfo methodMisuseInfo = new MethodMisuseInfo();
            methodMisuseInfo.setCalleeClass(calleeClass);
            methodMisuseInfo.setCallLineNo(lineNo);
            methodMisuseInfos.add(methodMisuseInfo);
        }
        return methodMisuseInfos;
    }

    private List<NPEInfo> toNpeInfos(JSONArray npeArray, RiskLevel riskLevel) {
        List<NPEInfo> npeInfos = new ArrayList<>();
        if (npeArray == null) return npeInfos;
        for (int i = 0 ; i < npeArray.size(); i++) {
            JSONObject record = npeArray.getJSONObject(i);
//            String nullString = record.getString("nullValue");
//            if (
//                    //nullString.contains("FROM_INIT")
//                    nullString.contains("FROM_ANNOTATION")
//                    // || nullString.contains("FROM_NULL_CHECK")
//            ) continue;
            NPEInfo npeInfo = NPEInfo.getInstance(record);
            npeInfos.add(npeInfo);
        }
        return npeInfos;
    }

    public List<NPEInfo> getNpeWarningsMiddleRisk() {
        return npeWarningsMiddleRisk;
    }

    public List<MethodMisuseInfo> getMethodMisuseWarnings() {
        return methodMisuseWarnings;
    }

    public void setMethodMisuseWarnings(List<MethodMisuseInfo> methodMisuseWarnings) {
        this.methodMisuseWarnings = methodMisuseWarnings;
    }

    public List<MethodMisuseInfo> getMethodMisuseErrors() {
        return methodMisuseErrors;
    }

    public void setMethodMisuseErrors(List<MethodMisuseInfo> methodMisuseErrors) {
        this.methodMisuseErrors = methodMisuseErrors;
    }

    public List<NPEInfo> getNpeWarningsHighRisk() {
        return npeWarningsHighRisk;
    }

    public List<NPEInfo> getNpeWarningsLowRisk() {
        return npeWarningsLowRisk;
    }

    public List<NPEInfo> getNpeErrors() {
        return npeErrors;
    }

    public void setNpeErrors(List<NPEInfo> npeErrors) {
        this.npeErrors = npeErrors;
    }

    public ResultJson toJson() {
        ResultJson json = new ResultJson();
        json.put("result", this);
        json.put("npeErrorNum", npeErrors.size());
        json.put("npeWarningHighRiskNum", npeWarningsHighRisk.size());
        json.put("npeWarningLowRiskNum", npeWarningsLowRisk.size());
        json.put("npeWarningMiddleRiskNum", npeWarningsMiddleRisk.size());
        json.put("methodMisuseErrorsNum", methodMisuseErrors.size());
        json.put("methodMisuseWarningsNum", methodMisuseWarnings.size());
        json.put("nodeNum", Global.nodeSet.size());
        return json;
    }
}
