package analyses.result;

import edu.callgraph.impurity.bean.Node;
import soot.Unit;

import java.util.List;

// bad method invocation
public class MethodMisuseInfo {
    private String calleeClass;
    private String calleeMethod;
    private int callLineNo;
    private String callStmt;
    private String callerClass;
    private String callerMethod;
    private List<String> misuseParams;

    public MethodMisuseInfo() {

    }

    public MethodMisuseInfo(Node callerNode, Node calleeNode, Unit unit) {
        setCalleeClass(calleeNode.getDeclaringClass());
        setCalleeMethod(calleeNode.getMethodSignatureFull());
        setCallerMethod(callerNode.getMethodSignatureFull());
        setCallerClass(callerNode.getDeclaringClass());
        setCallLineNo(unit.getJavaSourceStartLineNumber());
        this.callStmt = unit.toString();
    }

    public String getCallStmt() {
        return callStmt;
    }

    public void setCallStmt(String callStmt) {
        this.callStmt = callStmt;
    }

    public String getCalleeClass() {
        return calleeClass;
    }

    public void setCalleeClass(String calleeClass) {
        this.calleeClass = calleeClass;
    }

    public String getCalleeMethod() {
        return calleeMethod;
    }

    public void setCalleeMethod(String calleeMethod) {
        this.calleeMethod = calleeMethod;
    }

    public int getCallLineNo() {
        return callLineNo;
    }

    public void setCallLineNo(int callLineNo) {
        this.callLineNo = callLineNo;
    }

    public String getCallerClass() {
        return callerClass;
    }

    public void setCallerClass(String callerClass) {
        this.callerClass = callerClass;
    }

    public String getCallerMethod() {
        return callerMethod;
    }

    public void setCallerMethod(String callerMethod) {
        this.callerMethod = callerMethod;
    }

    public List<String> getMisuseParams() {
        return misuseParams;
    }

    public void setMisuseParams(List<String> misuseParams) {
        this.misuseParams = misuseParams;
    }
}
