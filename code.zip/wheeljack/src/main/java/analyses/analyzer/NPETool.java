package analyses.analyzer;

import analyses.NPEAnalysis;
import analyses.result.CombineResult;
import analyses.result.MethodMisuseInfo;
import analyses.result.NPEInfo;
import analyses.result.RiskLevel;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.callgraph.impurity.bean.Var;
import edu.callgraph.impurity.dataflow.DataFlowParse;
import edu.callgraph.impurity.dataflow.InvokeStmt;
import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.nullness.MethodInfo;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.util.Class2PathUtils;
import soot.Unit;

import java.io.File;
import java.util.*;

import static edu.redundantcheck.analyses.analyzer.AnalyzerTool.getArgStatusList;
import static edu.redundantcheck.analyses.analyzer.AnalyzerTool.getDeclaringClassFromNode;

// help to generate npe warnings.
public class NPETool {
    public static Set<NPEInfo> produceNPEInfos(Set<analyses.NPETool.DereferenceNode> dereferenceNodes, Node node) {
        Set<NPEInfo> npeInfos = new HashSet<>();
        for (analyses.NPETool.DereferenceNode dereferenceNode: dereferenceNodes) {
            NPEInfo info = new NPEInfo();
            int lineNo = dereferenceNode.getLineNo();
            if (lineNo == -1) continue;
            info.setLineNo(lineNo);
            info.setDereferenceBase(dereferenceNode.getBase());
            info.setDereferencePart(dereferenceNode.getDereferencePart());
            info.setDeclaringClass(getDeclaringClassFromNode(node));
            info.setDeclaringMethod(node.getMethodSignatureFull());
            info.setRiskLevel(dereferenceNode.getRiskLevel());
            info.setNullValue(dereferenceNode.getNullValue());
            String filePath = Class2PathUtils.getPath(node.getDeclaringClass());
            File file = filePath == null? null:new File(filePath);
            info.setJavaFile(file);
            npeInfos.add(info);
        }
        return npeInfos;
    }

    public static MethodMisuseInfo[] generateMethodMisuseInfo(Node callerNode,
                                                            UnitWrapperToNodePair invokeStmtAndNode,
                                                            NPEAnalysis npeAnalysis) {
        MethodMisuseInfo[] result = new MethodMisuseInfo[2];
        Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit;
        VarStatusInfo infoBeforeCall = npeAnalysis.getFlowBefore(unit);
        InvokeStmt invokeStmt = (InvokeStmt) invokeStmtAndNode.getFromInvokeStmt().parsedStmt;
        List<Var> arguments = invokeStmt.args;
        Node invokeNode = invokeStmtAndNode.getToInvokedMethod();
        List<MethodInfo.ParamStatus> paramStatusList = MethodInfo.getAnnotatedParamStatusList(invokeNode);
        MethodMisuseInfo methodMisuseWarning = new MethodMisuseInfo(callerNode, invokeNode, unit);
        Null nullStatus = new Null(npeAnalysis.declaringClass, unit.getJavaSourceStartLineNumber());
        methodMisuseWarning = findMethodMisuseWarning(paramStatusList, methodMisuseWarning,
                infoBeforeCall, arguments, nullStatus);
        result[1] = methodMisuseWarning;

        MethodMisuseInfo methodMisuseError = new MethodMisuseInfo(callerNode, invokeNode, unit);
        methodMisuseError = findMethodMisuseError(paramStatusList, methodMisuseError,
                infoBeforeCall, arguments, nullStatus);
        result[1] = methodMisuseError;
        return result;
    }

    private static MethodMisuseInfo findMethodMisuseWarning(List<MethodInfo.ParamStatus> paramStatusList,
                                                            MethodMisuseInfo methodMisuseInfo,
                                                            VarStatusInfo info,
                                                            List<Var> arguments,
                                                            Null nullStatus) {
        List<VarStatus> argStatusList = getArgStatusList(info, arguments);
        List<String> misuseParams = new ArrayList<>();
        for (int i = 0 ; i < paramStatusList.size(); i ++) {
            if (paramStatusList.get(i) == MethodInfo.ParamStatus.NonNull
                    && argStatusList.get(i).nullStatus == VarStatus.Status.UNKNOWN_HIGH_RISK) { // pass null to not null
                misuseParams.add("No." + (i+1) + " parameter is nullable but is annotated @NonNull.");
            }
        }
        if (!misuseParams.isEmpty()) {
            methodMisuseInfo.setMisuseParams(misuseParams);
            return methodMisuseInfo;
        }
        return null;
    }

    private static boolean isUnknown(VarStatus status) {
        return (status == VarStatus.UNKNOWN_HIGH_RISK
                || status == VarStatus.UNKNOWN_LOW_RISK
                || status == VarStatus.UNKNOWN_DEFAULT);
    }

    private static MethodMisuseInfo findMethodMisuseError(List<MethodInfo.ParamStatus> paramStatusList,
                                                          MethodMisuseInfo methodMisuseInfo,
                                                          VarStatusInfo info,
                                                          List<Var> arguments,
                                                          Null nullStatus) {
        List<VarStatus> argStatusList = getArgStatusList(info, arguments);
        List<String> misuseParams = new ArrayList<>();
        for (int i = 0 ; i < paramStatusList.size(); i ++) {
            if (paramStatusList.get(i) == MethodInfo.ParamStatus.NonNull
                    && argStatusList.get(i) == VarStatus.NULL) { // pass null to not null
                misuseParams.add("No." + (i+1) + " parameter is null but is annotated @NonNull.");
            }
        }
        if (!misuseParams.isEmpty()) {
            methodMisuseInfo.setMisuseParams(misuseParams);
            return methodMisuseInfo;
        }
        return null;
    }

    public static void addNpeInfo(NPEAnalysis npeAnalysis, Node node, CombineResult result) {
        if (Class2PathUtils.getPath(node.getDeclaringClass()) == null) return;
        Set<analyses.NPETool.DereferenceNode> nullDereferenceNodes = npeAnalysis.getNullDereferenceNodes();
        Set<NPEInfo> npeErrors = produceNPEInfos(nullDereferenceNodes, node);
        result.getNpeErrors().addAll(npeErrors);

        Set<analyses.NPETool.DereferenceNode> unknownDereferenceNodes = npeAnalysis.getUnknownDereferenceNodes();
        Set<NPEInfo> npeWarnings = produceNPEInfos(unknownDereferenceNodes, node);
        for (NPEInfo npeWarning: npeWarnings) {
            if (npeWarning.getRiskLevel() == RiskLevel.HIGH) {
                result.getNpeWarningsHighRisk().add(npeWarning);
            }
            else if (npeWarning.getRiskLevel() == RiskLevel.MIDDLE) {
                result.getNpeWarningsMiddleRisk().add(npeWarning);
            }
            else {
                result.getNpeWarningsLowRisk().add(npeWarning);
            }
        }
    }

    protected static void addMethodMisuseInfo(Node root, UnitWrapperToNodePair invokeStmtAndNode,
                                              NPEAnalysis npeAnalysis, CombineResult result) {
        MethodMisuseInfo[] methodMisuseInfo = NPETool.generateMethodMisuseInfo(root, invokeStmtAndNode, npeAnalysis);
        if (methodMisuseInfo != null) {
            MethodMisuseInfo methodMisuseWarning = methodMisuseInfo[0];
            MethodMisuseInfo methodMisuseError = methodMisuseInfo[1];
            if (methodMisuseError != null) result.getMethodMisuseErrors().add(methodMisuseError);
            if (methodMisuseWarning != null) result.getMethodMisuseWarnings().add(methodMisuseWarning);
        }
    }
}
