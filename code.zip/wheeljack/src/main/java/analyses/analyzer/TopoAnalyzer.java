package analyses.analyzer;

import analyses.*;
import analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.redundantcheck.analyses.RedundantAnalysis;
import edu.redundantcheck.analyses.analyzer.AnalyzerTool;
import edu.redundantcheck.analyses.analyzer.GraphIterator;
import edu.redundantcheck.analyses.analyzer.PercentageCounter;
import edu.redundantcheck.util.GlobalCleaner;
import soot.Unit;
import soot.toolkits.graph.UnitGraph;

import java.util.List;
import java.util.Set;
import java.util.concurrent.*;

// traverse nodes in a topo order
public class TopoAnalyzer extends AnalyzerInNPE {
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override
    public CombineResult analyzeNodes(List<Node> nodeSet) {
        GlobalCleaner.clean();
        CombineResult result = new CombineResult();
        GraphIterator graphIterator = new GraphIterator(nodeSet);
        PercentageCounter pc = new PercentageCounter(nodeSet.size());
        while (graphIterator.hasNext()) {
            pc.addCount();
            pc.logInfo();
            Node node = graphIterator.next();

            // System.out.println("Start to analyze method " + node.getMethodSignatureFull());
            NPEAnalysis npeAnalysis = execute(node);
            if (npeAnalysis == null) continue;

            AnalyzerTool.updateCalleeParamConclusion(node, npeAnalysis);
            addMethodMisuseInfo(node, npeAnalysis, result);
            NPETool.addNpeInfo(npeAnalysis, node, result);
//            System.out.println("Analyze method " + node.getMethodSignatureFull() + " successfully!");
        }
        executor.shutdown();
        return result;
    }

    private NPEAnalysis execute(Node node) {
        Task task = new Task(node);
        Future<NPEAnalysis> future = executor.submit(task);
        try {
            return future.get(30, TimeUnit.SECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            // task will be cancelled in finally block
        } finally {
            future.cancel(true);
        }
        return null;
    }

    private class Task implements Callable<NPEAnalysis> {
        private Node node;

        public Task(Node node) {
            this.node = node;
        }
        @Override
        public NPEAnalysis call() throws Exception {
            UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromNode(node);
            if (unitGraph == null) return null;
            ParamConclusion.BaseParamConclusion paramConclusion = ParamConclusion.getConclusion(node);
            return new NPEAnalysis(unitGraph, paramConclusion,
                            node.getMethod().getParameterCount(), node.getMethod().getDeclaringClass().getShortName());
        }
    }

    private static void addMethodMisuseInfo(Node node,
                                                    NPEAnalysis npeAnalysis,
                                                    CombineResult result) {
        Set<Unit> notReachableSet = npeAnalysis.getNotReachableSet();
        List<UnitWrapperToNodePair> invokeStmtAndNodes = node.getUnitToNodePairList();
        if (invokeStmtAndNodes == null || invokeStmtAndNodes.size() == 0) return;
        for (UnitWrapperToNodePair invokeStmtAndNode: invokeStmtAndNodes) {
            Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit;
            if (notReachableSet.contains(unit)) continue;
            NPETool.addMethodMisuseInfo(node, invokeStmtAndNode, npeAnalysis, result);
        }
    }

}
