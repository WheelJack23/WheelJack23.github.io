package analyses.analyzer;

import analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;

import java.util.List;

// Inter-procedural analyzer for npe detection
public abstract class AnalyzerInNPE {
    public abstract CombineResult analyzeNodes(List<Node> nodeSet);
}
