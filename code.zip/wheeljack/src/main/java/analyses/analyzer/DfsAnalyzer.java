package analyses.analyzer;

import analyses.NPEAnalysis;
import analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.redundantcheck.analyses.analyzer.PercentageCounter;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.util.GlobalCleaner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import soot.Unit;
import soot.toolkits.graph.UnitGraph;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static analyses.analyzer.NPETool.*;
import static edu.redundantcheck.analyses.analyzer.AnalyzerTool.*;
import static edu.redundantcheck.analyses.analyzer.DfsTool.getNotVisitedNodes;

public class DfsAnalyzer extends AnalyzerInNPE { // DFS steady-state traverse
    private static final Logger LOGGER = LoggerFactory.getLogger(DfsAnalyzer.class);
    @Override
    public CombineResult analyzeNodes(List<Node> nodes) {
        GlobalCleaner.clean();
        List<Node> rootNodes = getRootNodes(nodes);
        unvisited(nodes);
        CombineResult result = new CombineResult();
        LOGGER.info("Start DFS Visit from root nodes, size: " + rootNodes.size());
        PercentageCounter pc = new PercentageCounter(rootNodes.size());
        for (Node root: rootNodes) {
            dfsVisit(root, result);
            pc.addCount();
            pc.logInfo();
        }
        List<Node> notVisitedNodes = getNotVisitedNodes(nodes);
        LOGGER.info("Start DFS Visit from nodes left, size: " + notVisitedNodes.size());
        PercentageCounter pcLeft = new PercentageCounter(notVisitedNodes.size());
        for (Node node: notVisitedNodes) {
            pcLeft.addCount();
            pcLeft.logInfo();
            if (node.isVisited) continue;
            dfsVisit(node, result);
        }

        LOGGER.info("Parameter conclusion reaches a steady state.");
        iterateNodes(nodes, result);
        LOGGER.info("npe detection completes!");
        return result;
    }

    private void iterateNodes(List<Node> nodes, CombineResult result) {
        LOGGER.info("Start to analyze result, size: " + nodes.size());
        PercentageCounter pc = new PercentageCounter(nodes.size());
        for (Node node: nodes) {
            pc.addCount();
            pc.logInfo();
            UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromNode(node);
            if (unitGraph == null) continue;
            NPEAnalysis npeAnalysis =
                    new NPEAnalysis(unitGraph, ParamConclusion.getConclusion(node),
                            node.getMethod().getParameterCount(), node.getMethod().getDeclaringClass().getShortName());
            addNpeInfo(npeAnalysis, node, result);
        }
    }

    private void dfsVisit(Node root, CombineResult result) {
        root.isVisited = true;
        List<UnitWrapperToNodePair> invokeStmtAndNodes = root.getUnitToNodePairList();
        if (invokeStmtAndNodes == null || invokeStmtAndNodes.size() == 0) return;

        ParamConclusion.BaseParamConclusion paramConclusion = ParamConclusion.getAndRetainConclusion(root);
        UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromNode(root);
        if (unitGraph == null) return;
        NPEAnalysis npeAnalysis = new NPEAnalysis(unitGraph, paramConclusion,
                root.getMethod().getParameterCount(), root.getMethod().getDeclaringClass().getShortName());
        Set<Unit> notReachableSet = npeAnalysis.getNotReachableSet();
        for (UnitWrapperToNodePair invokeStmtAndNode: invokeStmtAndNodes) {
            Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit;
            if (notReachableSet.contains(unit)) continue;
            boolean isUpdated = ParamConclusion.updateConclusion(invokeStmtAndNode, npeAnalysis);
            if (isUpdated) dfsVisit(invokeStmtAndNode.getToInvokedMethod(), result);

            addMethodMisuseInfo(root, invokeStmtAndNode, npeAnalysis, result);
        }
    }

}
