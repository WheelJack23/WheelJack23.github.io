package analyses;

import analyses.result.RiskLevel;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.UnknownHighRisk;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.reachable.NotReachableCollection;
import soot.SootField;
import soot.SootMethod;
import soot.Value;
import soot.jimple.*;

import java.util.List;
import java.util.Set;

// generate npe warnings
public class NPETool {
    public static void analyze(Stmt stmt, VarStatusInfo in, NPEAnalysis npeAnalysis) {
        NotReachableCollection notReachableCollection = npeAnalysis.getNotReachableCollection();
        if (notReachableCollection.contains(stmt)) return;
        // 1. InstanceField
        if (stmt.containsFieldRef()) {
            FieldRef fieldRef = stmt.getFieldRef();
            if (fieldRef instanceof InstanceFieldRef) {
                InstanceFieldRef instanceFieldRef = (InstanceFieldRef) fieldRef;
                // here we know that the receiver must point to an object
                Value base = instanceFieldRef.getBase();
                SootField field = instanceFieldRef.getField();
                String dereferencePart = npeAnalysis.getStackVarString(base) + "." + field.getName();
                handleBase(base,in, npeAnalysis, dereferencePart, stmt.getJavaSourceStartLineNumber());
            }
        }

        // 2. InstanceInvoke
        if (stmt.containsInvokeExpr()) {
            InvokeExpr invokeExpr = stmt.getInvokeExpr();
            if (containsSpecialInvoke(invokeExpr)) return;
            if (invokeExpr instanceof InstanceInvokeExpr) {
                InstanceInvokeExpr instanceInvokeExpr = (InstanceInvokeExpr) invokeExpr;
                Value base = instanceInvokeExpr.getBase();
                String baseStr = npeAnalysis.getStackVarString(base);
                    String dereferencePart = baseStr
                            + "." + instanceInvokeExpr.getMethod().getName()
                            + constructArgList(invokeExpr.getArgs(), npeAnalysis);
                    handleBase(base, in, npeAnalysis, dereferencePart, stmt.getJavaSourceStartLineNumber());
            }
        }
    }

    private static String constructArgList(List<Value> args, NPEAnalysis npeAnalysis) {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        if (args.size() > 1) {
            Value value = args.get(0);
            sb.append(npeAnalysis.getStackVarString(value));
        }
        for (int i = 1; i < args.size();i++) {
            Value value = args.get(i);
            sb.append(",").append(npeAnalysis.getStackVarString(value));
        }
        sb.append(")");
        return sb.toString();
    }

    private static boolean containsSpecialInvoke(InvokeExpr invokeExpr) {
        SootMethod method = invokeExpr.getMethod();
        String declaringClass = method.getDeclaringClass().getName();
        return declaringClass.contains("Throwable");
    }

    private static void handleBase(Value base, VarStatusInfo in,
                                   NPEAnalysis npeAnalysis, String dereferencePart, int lineNo) {
        Set<DereferenceNode> unknownDereferenceUnits = npeAnalysis.getUnknownDereferenceNodes();
        VarStatus status = in.getStatus(base, VarStatus.NULL);
        Null nullStatus = null;
        if (status.isNull()) nullStatus = (Null) status;
        if (status instanceof UnknownHighRisk) nullStatus = ((UnknownHighRisk) status).getNullValue();
        if (nullStatus != null) {
            RiskLevel riskLevel = RiskLevel.LOW;
            if (nullStatus.getNullType() == Null.NullType.FROM_ASSIGN) riskLevel = RiskLevel.HIGH;
            if (nullStatus.getNullType() == Null.NullType.FROM_RETURN) riskLevel = RiskLevel.MIDDLE;
            unknownDereferenceUnits.add(new DereferenceNode(npeAnalysis.getStackVarString(base),
                    riskLevel, dereferencePart, lineNo, nullStatus));
        }
    }

    public static class DereferenceNode {
        private String base;
        private RiskLevel riskLevel;
        private String dereferencePart;
        private int lineNo;
        private Null nullValue;

        public DereferenceNode(String base, RiskLevel riskLevel,
                               String dereferencePart, int lineNo,
                               Null nullValue) {
            this.base = base;
            this.riskLevel = riskLevel;
            this.dereferencePart = dereferencePart;
            this.lineNo = lineNo;
            this.nullValue = nullValue;
        }

        public Null getNullValue() {
            return nullValue;
        }

        public int getLineNo() {
            return lineNo;
        }

        public String getDereferencePart() {
            return dereferencePart;
        }

        public String getBase() {
            return base;
        }

        public void setBase(String base) {
            this.base = base;
        }

        public RiskLevel getRiskLevel() {
            return riskLevel;
        }

        public void setRiskLevel(RiskLevel riskLevel) {
            this.riskLevel = riskLevel;
        }
    }
}
