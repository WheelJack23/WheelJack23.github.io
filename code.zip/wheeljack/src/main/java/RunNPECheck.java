import analyses.NPEAnalyzer;
import analyses.result.CombineResult;
import edu.callgraph.global.Config;
import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.util.ProperUtil;
import edu.redundantcheck.util.RepoStatistics;
import edu.redundantcheck.util.ResultJson;
import edu.redundantcheck.util.ScanUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import util.DetectUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import static util.DetectUtil.generateUniqueTag;

public class RunNPECheck {
    private static boolean restart = false;
    private static boolean singleProjectMode = true;
    private static File directoryFile = null;

    private static String uniqueTag = "";

    // user only need to specify single or multi
    // by default, it will continue analyze
    public static void main(String[] args) {
        if (args.length == 0) {
            printHelp();
            return;
        }
        // NullnessConfig.SHOW_UNLOOP_DETAIL = true;
        Map<String, String> settings = getSettings(args);
        setDetectorConfig(settings);
        setSingleOrMultiple(settings);
        startDetecting();
    }

    private static void startDetecting() {
        if (singleProjectMode) {
            DetectUtil.runSingle(directoryFile, uniqueTag);
        }
        else {
            DetectUtil.runBatch(directoryFile, restart, uniqueTag);
        }
    }

    private static void setSingleOrMultiple(Map<String, String> settings) {
        if (settings.containsKey("multiple")) {
            directoryFile = new File(settings.get("multiple"));
            singleProjectMode = false;
        }
        else if (settings.containsKey("single")) {
            directoryFile = new File(settings.get("single"));
            singleProjectMode = true;
        }
        else {
            System.out.println("should specify single or multiple and provide directory path");
            printHelp();
            System.exit(1);
        }
        if (!directoryFile.exists() || !directoryFile.isDirectory()) {
            System.out.println("invalid directory path for single or multiple.");
            printHelp();
            System.exit(1);
        }

    }

    private static void setDetectorConfig(Map<String, String> settings) {
        if (settings.containsKey("fd")) {
            String fDepthStr = settings.get("fd");
            try {
                int fDepth = Integer.parseInt(fDepthStr);
                NullnessConfig.setFieldDepth(fDepth);
            } catch (NumberFormatException ignored) {
                System.out.println("error: wrong field-depth.");
                System.exit(1);
            }
        }
        if (settings.containsKey("id")) {
            String invocationDepthStr = settings.get("id");
            try {
                int invocationDepth = Integer.parseInt(invocationDepthStr);
                NullnessConfig.setInvocationDepth(invocationDepth);
            } catch (NumberFormatException ignored) {
                System.out.println("error: wrong invocation-depth.");
                System.exit(1);
            }
        }
        if (settings.containsKey("mr")) {
            String mr = settings.get("mr").trim();
            Map<String, VarStatus> scene2status = NullnessConfig.scene2status;
            if (!scene2status.containsKey(mr)) {
                throw new RuntimeException("illegal middle risk scene");
            }
            scene2status.put(mr, VarStatus.UNKNOWN_MID_RISK);
        }
        uniqueTag = generateUniqueTag();
    }


    private static void printHelp() {
        System.out.println("usage: java -jar NPEDetector-1.0-SNAPSHOT.jar [-options]");
        System.out.println("where options include:");
        System.out.println("--multiple=\"<project dataset path>\"  for a dataset");
        System.out.println("--single=\"<project path>\"  for a single project");
        System.out.println("-s to enable spark (by default cha)");
        System.out.println("-c to continue (default)");
        System.out.println("-r to restart");
        System.out.println("--id=<number>  for invocation depth setting");
        System.out.println("--fd=<number>  for field depth setting");
        System.out.println("--mr=<UNKNOWN_SCENE_NAME>  for an unknown scene to be middle risk");
        System.out.println("--prop=\"<properties file>\"  for call graph construction property and dataset list");
        System.out.println("eg.: java -jar NPEDetector-1.0-SNAPSHOT.jar --multiple=\"<project dataset path>\"");
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(RunNPECheck.class);
    private static Map<String, String> getSettings(String[] args) {
        Map<String, String> props = new HashMap<>();
        for (int i = 0; i < args.length; i ++) {
            String item = args[i];
            if ((!item.contains("=")) || (!item.contains("--"))) {
                if (item.equals("-r")) {
                    restart = true;
                    LOGGER.info("warning: restart detecting!");
                }
                if (item.equals("-s")) {
                    Config.SPARK_ENABLE = true;
                    LOGGER.info("warning: enable SPARK and it may be time consuming.");
                }
                continue;
            }
            item = item.replace("--", "");
            String[] parts = item.split("=");
            props.put(parts[0], parts[1]);
        }
        return props;
    }

}
