package util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class StartIndexUtil {
    public static int getStart(String uniqueTag) {
        File file = new File(getStartFilePath(uniqueTag));
        if (!file.exists()) {
            outputStart(0, uniqueTag);
            return 0;
        }
        try {
            Scanner input = new Scanner(file);
            String line = input.nextLine().trim();
            return Integer.parseInt(line);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public static void restart(String uniqueTag) {
        File file = new File(getStartFilePath(uniqueTag));
        if (file.exists()) {
            if (!file.delete()) {
                throw new RuntimeException("could not delete start.txt");
            }
        }
    }

    public static void outputStart(int start, String uniqueTag) {
        File file = new File(getStartFilePath(uniqueTag));
        try {
            PrintWriter out = new PrintWriter(file);
            out.println(start);
            out.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getStartFilePath(String uniqueTag) {
        return "./start_" + uniqueTag+".txt";
    }
}
