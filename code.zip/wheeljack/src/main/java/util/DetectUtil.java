package util;

import analyses.NPEAnalyzer;
import analyses.exception.EmptyNodeSetException;
import analyses.result.CombineResult;
import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.util.ResultJson;
import edu.redundantcheck.util.ScanUtil;
import edu.redundantcheck.util.Timer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

public class DetectUtil {
    private static String version = "v2.8.2";

    public static String getVersion() {
        return version;
    }

    public static void runSingle(File directoryFile) {
        runSingle(directoryFile, generateUniqueTag());
    }

    public static String generateUniqueTag() {
        Map<String, VarStatus> scene2status = NullnessConfig.scene2status;
        String middleName = "default";
        for (String scene: scene2status.keySet()) {
            if (scene2status.get(scene) == VarStatus.UNKNOWN_MID_RISK) {
                String[] parts = scene.split("_");
                StringBuilder sb = new StringBuilder();
                for (String part: parts) {
                    sb.append(part.toLowerCase().charAt(0));
                }
                middleName = sb.toString();
                break;
            }
        }
        return "f_" + NullnessConfig.getFieldDepth()
                + "_i_" + NullnessConfig.getInvocationDepth()+"_" + middleName;
    }

    private static File getOutputDir(String uniqueTag) {
        File reportsDir = new File("reports");
        if (!reportsDir.exists() || !reportsDir.isDirectory()) {
            reportsDir.delete();
            reportsDir.mkdir();
        }
        File historyDir = new File(reportsDir, "history");
        if (!historyDir.exists() || !historyDir.isDirectory()) {
            historyDir.delete();
            historyDir.mkdir();
        }
        if (uniqueTag.isEmpty()) uniqueTag = version;
        else uniqueTag = version + "_" + uniqueTag;
        File outputDir = new File(historyDir, uniqueTag);
        if (!outputDir.exists() || !outputDir.isDirectory()) {
            outputDir.delete();
            outputDir.mkdir();
        }
        return outputDir;
    }

    public static void runSingle(File directoryFile, String uniqueTag) {
        File outputDir = getOutputDir(uniqueTag);
        runSingle(directoryFile, outputDir);
    }

    public static void runSingle(File directoryFile, File outputDir) {
        System.out.println("Begin to analyze project " + directoryFile.getName());
        Timer.start();
        String[] methodNames = ScanUtil.scanEntryPointsMultiModule(directoryFile);
        CombineResult result = NPEAnalyzer.analyzeMultiModule(directoryFile.getAbsolutePath(), methodNames);
        double costTime = Timer.getSeconds();
        System.out.println("Time cost: " + costTime + " seconds.");
        outputResult(directoryFile.getName(), result, costTime, outputDir);
    }

    public static void runBatch(File directorFile, boolean restart, String uniqueTag) {
        if (restart) StartIndexUtil.restart(uniqueTag);
        List<String> projectNames = DatasetUtil.getProjectNames();
        File outputDir = getOutputDir(uniqueTag);
        for (int i = StartIndexUtil.getStart(uniqueTag); i < projectNames.size(); i++) {
            String projectName = projectNames.get(i);
            try {
                runSingle(new File(directorFile, projectName), outputDir);
                System.out.println("Analyze " + projectName + " successfully!");
                StartIndexUtil.outputStart(i+1, uniqueTag);
            } catch (EmptyNodeSetException e) {
                System.out.println("Analyze " + projectName + " failed.");
            }
        }
        outputRecall(outputDir);
    }

    public static void outputRecall(File outputDir) {
        PrintWriter out = null;
        try {
            out = new PrintWriter(new File(outputDir, version+".csv"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        // 一组一组输出结果
        List<String> projectNames = DatasetUtil.getProjectNames();
        for (String projectName : projectNames) {
            out.print(projectName + ",");
            outputDifference(projectName, out, outputDir);
            out.print("\n");
        }
        out.close();
    }

    public static void outputDifference(String projectName, PrintWriter out, File outputDir) {
        File outputFile = new File(outputDir, projectName + "-result.json");
        List<ConvertNPE.NPENode> npeList = ConvertNPE.getNPEList(projectName);
        RecallTool.outputRecall(outputFile.getAbsolutePath(), npeList, out);
    }

    public static void outputResult(String projectName, CombineResult result,
                                    double costTime, File outputDir) {
        File outputFile = new File(outputDir, projectName + "-result.json");
        try {
            PrintWriter writer = new PrintWriter(outputFile);
            ResultJson json = result.toJson();
            json.put("costTime", costTime);
            writer.println(json);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
