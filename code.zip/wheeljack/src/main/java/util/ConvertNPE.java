package util;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

// convert npe reports to nodes
public class ConvertNPE {
    // npe report path
    private static final String DEFAULT_PATH1 = "./npe-reports/";
    public static final String DEFAULT_PATH2 = "D:\\Codes\\upload-files\\npe-reports\\";
    private static File getReportDir() {
        File f1 = new File(DEFAULT_PATH1);
        File f2 = new File(DEFAULT_PATH2);
        if (!f1.exists() && !f2.exists()) throw new RuntimeException("npe reports do no exist.");
        if (f1.exists()) return f1;
        else return f2;
    }
    public static List<NPENode> getNPEList(String projectName) {
        File reportDir = getReportDir();
        File reportFile = new File(reportDir, projectName + ".txt");
//        System.out.println(rawReportsPath);
        List<NPENode> originalList = getNPEListFromPath(reportFile, getProjectStartIdx(projectName));
        List<NPENode> listWithoutTest = filterTest(originalList);
        Set<NPENode> set = new HashSet<>(listWithoutTest);
        List<NPENode> listWithoutDuplicates = new ArrayList<>();
        listWithoutDuplicates.addAll(set);
        return listWithoutDuplicates;
    }

    private static File getRepo2NumFile() {
        String defaultPath1 = "./repo2npenum.csv";
        String defaultPath2 = "src/test/resources/repo2npenum.csv";
        File f1 = new File(defaultPath1);
        File f2 = new File(defaultPath2);
        if (!f1.exists() && !f2.exists()) throw new RuntimeException("repo2npenum.csv does not exist.");
        if (f1.exists()) return f1;
        else return f2;
    }
    private static int getProjectStartIdx(String projectName) {
        try {
            Scanner input = new Scanner(getRepo2NumFile());
            int idx = 0;
            while (input.hasNext()) {
                String line = input.nextLine();
                if (line.contains(projectName)) return idx;
                int num = Integer.parseInt(line.split("\t")[1]);
                idx += num;
            }
            input.close();
            throw new RuntimeException();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    private static List<NPENode> filterTest(List<NPENode> nodes) {
        List<NPENode> result = new ArrayList<>();
        for (NPENode node: nodes) {
            if (!node.firstLineContainsTest()) {
                result.add(node);
            }
//            else {
//                System.out.println();
//            }
        }
        return result;
    }

    public static List<NPENode> getNPEListFromPath(File reportFile, int projectStartIdx) {
        Scanner input = null;
        try {
            input = new Scanner(reportFile);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        List<NPENode> nodes = new LinkedList<>();
        int nodeIdx = projectStartIdx;
        boolean addFlag = false;
        NPENode node = null;
        while (input.hasNext()) {
            String line = input.nextLine().trim();
            if (line.isEmpty()) {
                addFlag = false;
                continue;
            }
            if (!addFlag) {
                if (!line.contains("java.lang.NullPointerException")) {
                    continue;
                }
                addFlag = true;
                node = new NPENode(nodeIdx++);
                nodes.add(node);
                node.appendInfo(line);
            }
            else {
                node.appendInfo(line);
            }
        }
        input.close();
        return nodes;
    }

    public static class NPENode {
        List<InvokeLine> infos = new ArrayList<>();
        Set<InvokeLine> infoSet = new HashSet<>();
        Set<String> npeTypes = new HashSet<>();
        private int idx;
        public NPENode(int idx) {
            this.idx = idx;
        }

        public int getIdx() {
            return idx;
        }

        public boolean contains(String declaringClass, int lineNo) {
            return infoSet.contains(new InvokeLine(declaringClass, lineNo));
        }

        public Set<String> getNpeTypes() {
            return npeTypes;
        }

        public boolean firstLineContainsTest() {
            return infos.get(0).declaringClass.endsWith("Test");
        }

        public void appendInfo(String info) {
            if (info.contains("type:")) {
                String[] types = info.replace("type:", "").split("\\|");
                for (String type: types) {
                    if (!type.trim().isEmpty())npeTypes.add(type.trim());
                }
            }
            if (!info.contains("at ")) return;
            int idx = info.indexOf("at ");
            String invokePart = info.substring(idx+3);
            String[] parts = invokePart.split("\\(");
            String declaringClass = getDeclaringClass(parts[0]);
            int lineNo = getLineNo(parts[1]);
            InvokeLine invokeLine = new InvokeLine(declaringClass, lineNo);
            infos.add(invokeLine);
            infoSet.add(invokeLine);
        }
        private int getLineNo(String linePart) {
            int lineNo = 0;
            if (linePart.contains(".java:")) {
                int idx = linePart.indexOf(".java:");
                int bracketIdx = linePart.lastIndexOf(")");
                bracketIdx = bracketIdx == -1? linePart.length() :bracketIdx;
                String lineNoStr = linePart.substring(idx+6, bracketIdx);
                lineNo = Integer.parseInt(lineNoStr);
            }
            return lineNo;
        }
        private String getDeclaringClass(String declaringMethod) {
            int idx = declaringMethod.lastIndexOf(".");
            String declaringClass = declaringMethod.substring(0, idx);
            return declaringClass;
        }

        private class InvokeLine {
            private String declaringClass;
            private int lineNo;
            public InvokeLine(String declaringClass, int lineNo) {
                this.declaringClass = declaringClass;
                this.lineNo = lineNo;
            }

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;

                InvokeLine that = (InvokeLine) o;

                if (lineNo != that.lineNo) return false;
                return declaringClass.equals(that.declaringClass);
            }

            @Override
            public int hashCode() {
                int result = declaringClass.hashCode();
                result = 31 * result + lineNo;
                return result;
            }
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            NPENode npeNode = (NPENode) o;
            return Objects.equals(infos, npeNode.infos);
        }

        @Override
        public int hashCode() {
            return Objects.hash(infos);
        }
    }
}
