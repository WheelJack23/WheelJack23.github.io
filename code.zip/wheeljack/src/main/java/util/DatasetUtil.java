package util;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DatasetUtil {
    private static String DEFAULT_PATH1 = "./repos.txt";
    private static String DEFAULT_PATH2 = "src/main/resources/repos.txt";
    private static List<String> projectNames;
    public static List<String> getProjectNames() {
        if (projectNames == null) {
            File f1 = new File(DEFAULT_PATH1);
            File f2 = new File(DEFAULT_PATH2);
            if (!f1.exists() && !f2.exists()) {
                throw new RuntimeException("repos.txt does not exist.");
            }
            if (f1.exists()) {
                projectNames = getProjectNames(f1);
            }
            else {
                projectNames = getProjectNames(f2);
            }
        }
        return projectNames;
    }

    private static List<String> getProjectNames(File file) {
        List<String> projectNames = new ArrayList<>();
        Scanner input = null;
        try {
            input = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (input.hasNext()) {
            String line = input.nextLine();
            line = line.trim();
            if (!line.isEmpty()) projectNames.add(line);
        }
        input.close();
        return projectNames;
    }
}
