package util;

import analyses.result.CombineResult;
import analyses.result.MethodMisuseInfo;
import analyses.result.NPEInfo;
import analyses.result.RiskLevel;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import edu.callgraph.util.JsonUtil;
import edu.redundantcheck.util.ResultJson;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class RecallTool {
    private static final String separator = ",";
    public static void outputRecall(List<NPEInfo> npeInfos,
                                    List<ConvertNPE.NPENode> expectedNpeList,
                                    PrintWriter out,
                                    double costTime) {
        CombineResult result = new CombineResult();
        result.loadData(npeInfos);
        out.print(0);
        outputResultInfo(result, out);
        out.print(separator + expectedNpeList.size());

        List<NPEInfo> npeWarningsAll = new LinkedList<>(result.getNpeWarningsHighRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        npeWarningsAll.addAll(result.getNpeWarningsMiddleRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        npeWarningsAll.addAll(result.getNpeWarningsLowRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        out.print(separator + costTime);
    }

    public static void outputRecall(String actualResultPath, List<ConvertNPE.NPENode> expectedNpeList, PrintWriter out) {
        JSONObject actualResult = JsonUtil.readJsonFileAsObject(actualResultPath);
        double costTime = 100;
        if (actualResult.containsKey("costTime")) costTime = actualResult.getDouble("costTime");
        CombineResult result = new CombineResult();
        JSONObject dataResult = actualResult.getJSONObject("result");
        result.loadData(dataResult);
        out.print(actualResult.getInteger("nodeNum"));
        outputResultInfo(result, out);
        out.print(separator + expectedNpeList.size());

        List<NPEInfo> npeWarningsAll = new LinkedList<>(result.getNpeWarningsHighRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        npeWarningsAll.addAll(result.getNpeWarningsMiddleRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        npeWarningsAll.addAll(result.getNpeWarningsLowRisk());
        outputNpeCoveredResult(expectedNpeList, result, npeWarningsAll, out);
        out.print(separator + costTime);
    }
    private static void outputResultInfo(CombineResult result, PrintWriter out) {
        out.print(separator + result.getNpeErrors().size() +
                separator + result.getTotalNpeWarningNum() +
                separator + result.getNpeWarningsHighRisk().size() +
                separator + result.getNpeWarningsMiddleRisk().size() +
                separator + result.getNpeWarningsLowRisk().size() +
                separator + result.getMethodMisuseWarnings().size() +
                separator + result.getMethodMisuseErrors().size());
    }

    private static void outputNpeCoveredResult(List<ConvertNPE.NPENode> expectedNpeList, CombineResult result,
                                               List<NPEInfo> npeWarningsAll, PrintWriter out) {
        int numNpeCovered = getActualNpeNum(expectedNpeList, result.getNpeErrors(), npeWarningsAll,
                result.getMethodMisuseWarnings(), result.getMethodMisuseErrors());

        String description = "Not found";
        if (numNpeCovered > 0) {
            description = numNpeCovered == expectedNpeList.size() ? "All are found":"Part are found";
        }
        out.print(separator + numNpeCovered
                + separator + description);
    }

    private static int getActualNpeNum(List<ConvertNPE.NPENode> expectedNpeList,
                                       List<NPEInfo> npeErrors,
                                       List<NPEInfo> npeWarnings,
                                       List<MethodMisuseInfo> methodMisuseWarnings,
                                       List<MethodMisuseInfo> methodMisuseErrors) {
        int actualNpeNum = 0;
        for (ConvertNPE.NPENode node: expectedNpeList) {
            if (contains(npeErrors, node)) {
                actualNpeNum++;
                continue;
            }
            if (contains(npeWarnings, node)) {
                actualNpeNum++;
                continue;
            }
            if (methodMisuseInfosContains(methodMisuseWarnings, node)) {
                actualNpeNum++;
                continue;
            }
            if (methodMisuseInfosContains(methodMisuseErrors, node)) {
                actualNpeNum++;
            }
        }
        return actualNpeNum;
    }

    public static boolean methodMisuseInfosContains(List<MethodMisuseInfo> methodMisuseInfos, ConvertNPE.NPENode node) {
        for (int i = 0 ; i < methodMisuseInfos.size(); i++) {
            MethodMisuseInfo methodMisuseInfo = methodMisuseInfos.get(i);
            if (node.contains(methodMisuseInfo.getCalleeClass(), methodMisuseInfo.getCallLineNo())) return true;
        }
        return false;
    }

    private static List<NPEInfo> getHighRiskNPEInfo(JSONArray npeInfos) {
        List<NPEInfo> npeInfosHighRisk = new ArrayList<>();
        for (int i = 0 ; i < npeInfos.size(); i++) {
            JSONObject record = npeInfos.getJSONObject(i);
            String declaringClass = record.getString("declaringClass");
            int lineNo = record.getInteger("lineNo");
            if (record.getString("riskLevel").equals("HIGH")) {
                npeInfosHighRisk.add(new NPEInfo(declaringClass, lineNo, RiskLevel.HIGH));
            }
        }
        return npeInfosHighRisk;
    }

    private static List<NPEInfo> getLowRiskNPEInfo(JSONArray npeInfos) {
        List<NPEInfo> npeInfosLowRisk = new ArrayList<>();
        for (int i = 0 ; i < npeInfos.size(); i++) {
            JSONObject record = npeInfos.getJSONObject(i);
            String declaringClass = record.getString("declaringClass");
            int lineNo = record.getInteger("lineNo");
            if (record.getString("riskLevel").equals("LOW")) {
                npeInfosLowRisk.add(new NPEInfo(declaringClass, lineNo, RiskLevel.LOW));
            }
        }
        return npeInfosLowRisk;
    }

    public static boolean contains(JSONArray npeInfos, ConvertNPE.NPENode node) {
        for (int i = 0 ; i < npeInfos.size(); i++) {
            JSONObject record = npeInfos.getJSONObject(i);
            String declaringClass = record.getString("declaringClass");
            int lineNo = record.getInteger("lineNo");
            if (node.contains(declaringClass, lineNo)) return true;
        }
        return false;
    }

    public static boolean contains(List<NPEInfo> npeInfos, ConvertNPE.NPENode node) {
        for (int i = 0 ; i < npeInfos.size(); i++) {
            NPEInfo record = npeInfos.get(i);
            if (node.contains(record.getDeclaringClass(), record.getLineNo())) {
                return true;
            }
        }
        return false;
    }
}
