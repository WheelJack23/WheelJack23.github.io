# Redundant null check analysis
Shares nullness analysis and reachable analysis with WheelJack and is used 
for detection of redundant null checks.

## Shared logic with WheelJack is mainly in package `analyses`.

## !For anonymous reason, we delete test code.