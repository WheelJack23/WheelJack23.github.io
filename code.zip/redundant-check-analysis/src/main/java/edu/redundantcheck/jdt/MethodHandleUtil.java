package edu.redundantcheck.jdt;

import org.eclipse.jdt.core.dom.*;

import java.lang.reflect.Modifier;
import java.util.*;
// get JDT method information
public class MethodHandleUtil {

    // is public method
    public static boolean isPublic(MethodDeclaration method) {
        int modifiers = method.getModifiers();
        return (modifiers & Modifier.PUBLIC) != 0;
    }

    // is protected method
    public static boolean isProtected(MethodDeclaration method) {
        int modifiers = method.getModifiers();
        return (modifiers & Modifier.PROTECTED) != 0;
    }

    // is private method
    public static boolean isPrivate(MethodDeclaration method) {
        int modifiers = method.getModifiers();
        return (modifiers & Modifier.PRIVATE) != 0;
    }

    // Construct Method full name
    public static String constructMethodFullName(String packageName, String className, String methodName) {
        StringBuilder sb = new StringBuilder();
        if (!packageName.equals("")) sb.append(packageName).append(".");
        sb.append(className).append(".").append(methodName);
        return sb.toString();
    }


    public static String constructMethodFullName(CompilationUnit cu, AbstractTypeDeclaration typeDeclaration,
                                                 MethodDeclaration methodDeclaration) {
        String packageName = CompilationUnitTool.getPackageName(cu);
        String className = CompilationUnitTool.getClassName(typeDeclaration);
        String methodName = getMethodNameWithoutPackageAndClassName(methodDeclaration);
        return constructMethodFullName(packageName, className, methodName);
    }


    public static String getMethodNameWithoutPackageAndClassName(MethodDeclaration methodDeclaration){
        String methodSignature = methodDeclarationToString(methodDeclaration);
        methodSignature = removeBracket(methodSignature);
        return methodSignature;
    }


    public static String removeBracket(String s){
        Stack sta = new Stack();
        Map<Integer,Integer> pair = new HashMap<>();
        for(int i=0; i < s.length(); i ++){
            if(s.charAt(i) == '<'){
                sta.push(i);
            }
            if(s.charAt(i) == '>'){
                if(sta.size() >= 2){
                    sta.pop();
                    continue;
                }
                if(sta.size()==0){
                    continue;
                }
                pair.put((Integer)sta.peek(),i);
                sta.pop();
            }
        }
        StringBuilder sb = new StringBuilder();
        boolean isIgnore = false;
        int endIgnoreI = -1;
        for(int i = 0; i < s.length(); i ++){
            if(pair.containsKey(i)){
                isIgnore = true;
                endIgnoreI = pair.get(i);
            }
            if(i == endIgnoreI){
                isIgnore = false;
                continue;
            }
            if(isIgnore){
                continue;
            }
            sb.append(s.charAt(i));
        }
        return sb.toString();
    }

    public static String transParameterLongNameToShortName(String methodFullSignature){
        StringBuilder sb = new StringBuilder();
        if(methodFullSignature.endsWith(")")){
            methodFullSignature = methodFullSignature.substring(0, methodFullSignature.length() - 1);
        }
        String[] data = methodFullSignature.split("\\(");
        String methodFullName = data[0];
        sb.append(methodFullName);
        sb.append("(");
        if(data.length != 1) {
            String paramShortTemp = removeBracket(data[1]);
            String[] params = paramShortTemp.split(",");
            for (String param : params) {
                if (param.contains(".")) {
                    String[] paramData = param.split("\\.");
                    sb.append(paramData[paramData.length - 1]);
                    sb.append(",");
                }else{
                    sb.append(param);
                    sb.append(",");
                }
            }
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append(")");
        return sb.toString();
    }

    public static String methodDeclarationToString(MethodDeclaration methodDeclaration){
        StringBuilder sb = new StringBuilder();
        String methodName = methodDeclaration.getName().toString();
        sb.append(methodName);
        List params = methodDeclaration.parameters();
        Iterator iter2 = params.iterator();
        sb.append("(");
        while (iter2.hasNext()){
            SingleVariableDeclaration var = (SingleVariableDeclaration) iter2.next();
            String varString = var.getType().toString();
            int index = varString.lastIndexOf(".");
            sb.append(varString.substring(index + 1));
            int dimension = getDimension(var);
            sb.append(getDimensionStr(dimension));
            sb.append(",");
        }
        if(params.size() != 0){
            sb.deleteCharAt(sb.length()-1);
        }
        sb.append(")");
        return sb.toString();
    }

    private static int getDimension(SingleVariableDeclaration var) {
        int dimension = var.getExtraDimensions();
        if (dimension == 0 && var.toString().contains("...")) return 1;
        return dimension;
    }

    private static String getDimensionStr(int dimension) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0  ; i < dimension; i++) {
            sb.append("[]");
        }
        return sb.toString();
    }
}

