package edu.redundantcheck.jdt.handler;

import org.eclipse.jdt.core.dom.*;


// handle JDT then statement
public class ThenHandler extends Handler{

    public ThenHandler(CompilationUnit cu) {
        super(cu);
    }

    @Override
    public void handleBlock(Statement statement) {
        ranges = BodyHandler.handleStatements(cu, ((Block) statement).statements());
    }

    @Override
    public void handleIf(Statement statement) {
        ranges = IfStatementHandler.getConditionRangeFromIfStatement(cu, (IfStatement) statement);
    }

}
