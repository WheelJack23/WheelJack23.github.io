package edu.redundantcheck.jdt.handler;

import edu.redundantcheck.jdt.ConditionWithRange;
import edu.redundantcheck.util.RepoStatistics;
import org.eclipse.jdt.core.dom.*;

import java.util.ArrayList;
import java.util.List;

// handle if statement in JDT
public class IfStatementHandler {

    public static List<ConditionWithRange> getConditionRangeFromIfStatement(CompilationUnit cu, IfStatement ifStatement) {
        List<ConditionWithRange> conditionWithRanges = new ArrayList<>();
        boolean isNullCheck = RepoStatistics.isSingleNullCheck(ifStatement.getExpression());
        ConditionWithRange firstRanges = new ConditionWithRange(ifStatement);
        if (isNullCheck) conditionWithRanges.add(firstRanges);
        int ifStart = cu.getLineNumber(ifStatement.getStartPosition());
        int ifEnd = cu.getLineNumber(ifStatement.getStartPosition()
                + ifStatement.getLength() - 1);

        List<ConditionWithRange> elseRanges = handleElseStatement(cu, ifStatement.getElseStatement(),
                                                            firstRanges, ifStart, ifEnd, isNullCheck);
        conditionWithRanges.addAll(elseRanges);

        List<ConditionWithRange> thenRanges = handleThenStatement(cu, ifStatement.getThenStatement());
        conditionWithRanges.addAll(thenRanges);
        return conditionWithRanges;
    }

    public static List<ConditionWithRange> handleElseStatement(CompilationUnit cu,
                                                                Statement elseStatement,
                                                                ConditionWithRange firstRange, int ifStart, int ifEnd,
                                                                boolean isNullCheck) {
        ElseHandler handler = new ElseHandler(cu, firstRange, ifStart, ifEnd, isNullCheck);
        StatementCases.handle(elseStatement, handler);
        return handler.getRanges();
    }

    public static List<ConditionWithRange> handleThenStatement(CompilationUnit cu, Statement thenStatement) {
        ThenHandler handler = new ThenHandler(cu);
        StatementCases.handle(thenStatement, handler);
        return handler.getRanges();
    }
}
