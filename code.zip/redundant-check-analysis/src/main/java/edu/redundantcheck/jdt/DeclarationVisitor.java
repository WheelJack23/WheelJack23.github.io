package edu.redundantcheck.jdt;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.util.ArrayList;
import java.util.List;

// visit class and enum class declaration to get JDT condition blocks.
public class DeclarationVisitor extends ASTVisitor {

    private List<TypeDeclaration> typeDeclarations = new ArrayList<>();
    private List<EnumDeclaration> enumDeclarations = new ArrayList<>();

    public List<TypeDeclaration> getTypeDeclarations() {
        return typeDeclarations;
    }
    public List<EnumDeclaration> getEnumDeclarations() { return enumDeclarations; }

    @Override
    public boolean visit(TypeDeclaration typeDeclaration){
        if(typeDeclaration.isPackageMemberTypeDeclaration() ||
                typeDeclaration.isMemberTypeDeclaration()) {
            typeDeclarations.add(typeDeclaration);
        }
        return true;
    }

    @Override
    public boolean visit(EnumDeclaration enumDeclaration){
        if (enumDeclaration.isPackageMemberTypeDeclaration() || enumDeclaration.isMemberTypeDeclaration()) {
            enumDeclarations.add(enumDeclaration);
        }
        return true;
    }}
