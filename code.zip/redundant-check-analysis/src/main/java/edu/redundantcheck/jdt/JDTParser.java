package edu.redundantcheck.jdt;

import edu.redundantcheck.analyses.RedundantAnalyzer;
import edu.redundantcheck.jdt.handler.BodyHandler;
import org.eclipse.jdt.core.dom.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import soot.SootMethod;
import soot.Type;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

// get JDT condition block from a java file.
public class JDTParser {
    public static final Logger LOGGER = LoggerFactory.getLogger(JDTParser.class);

    public static List<ConditionWithRange> getConditionRangesFromPath(String path) {
        if (path == null) return new LinkedList<>();
        CompilationUnit cu = JDTParserFactory.getCompilationUnit(path);
        List<TypeDeclaration> typeDeclarations = CompilationUnitTool.getTypeDeclarations(cu);

        List<ConditionWithRange> rangeList = new LinkedList<>();
        for (TypeDeclaration typeDeclaration : typeDeclarations) {
            List<ConditionWithRange> result = getRangesFromTypeDeclaration(cu, typeDeclaration, null);
            rangeList.addAll(result);
        }

        List<ConditionWithRange> result = getRangesFromEnum(cu, null);
        rangeList.addAll(result);
        return rangeList;
    }

    public static List<ConditionWithRange> getConditionRangesInMethod(SootMethod method) {
        String path = "";
        path = RedundantAnalyzer.generatePathFromClassName(method);

        if (path == null) {
            return new ArrayList<>();
        }
        CompilationUnit cu = JDTParserFactory.getCompilationUnit(path);
        List<TypeDeclaration> typeDeclarations = CompilationUnitTool.getTypeDeclarations(cu);

        List<ConditionWithRange> rangeList = new LinkedList<>();
        for (TypeDeclaration typeDeclaration : typeDeclarations) {
            List<ConditionWithRange> result = getRangesFromTypeDeclaration(cu, typeDeclaration, method);
            rangeList.addAll(result);
        }

        List<ConditionWithRange> result = getRangesFromEnum(cu, method);
        rangeList.addAll(result);
        return rangeList;
    }

    private static List<ConditionWithRange> getRangesFromTypeDeclaration(CompilationUnit cu,
                                                                         TypeDeclaration typeDeclaration,
                                                                         SootMethod method) {
        List<ConditionWithRange> rangeList = new LinkedList<>();
        MethodDeclaration[] methodDeclarations = typeDeclaration.getMethods();

        for (MethodDeclaration methodDeclaration : methodDeclarations) {
            if (method != null) {
                if (!methodEqual(method, methodDeclaration, cu, typeDeclaration)) continue;
            }
            List<ConditionWithRange> result = getRangesFromMethod(cu, methodDeclaration);
            rangeList.addAll(result);
        }

        TypeDeclaration[] subTypes = typeDeclaration.getTypes();
        for (TypeDeclaration subType : subTypes) {
            List<ConditionWithRange> result = getRangesFromTypeDeclaration(cu, subType, method);
            rangeList.addAll(result);
        }

        return rangeList;
    }

    private static List<ConditionWithRange> getRangesFromEnum(CompilationUnit cu, SootMethod method) {
        List<ConditionWithRange> rangeList = new LinkedList<>();
        if (cu == null) return rangeList;
        List<Object> types = cu.types();
        for (Object obj : types) {
            if (obj instanceof EnumDeclaration) {
                EnumDeclaration enumDeclaration = (EnumDeclaration) obj;
                List bodyDeclarations = enumDeclaration.bodyDeclarations();
                for (Object o : bodyDeclarations) {
                    if (o instanceof MethodDeclaration) {
                        if (method != null) {
                            if (!methodEqual(method, (MethodDeclaration) o,cu, (AbstractTypeDeclaration) obj)) continue;
                        }
                        List<ConditionWithRange> result = getRangesFromMethod(cu, (MethodDeclaration) o);
                        rangeList.addAll(result);
                    }
                }
            }
        }
        return rangeList;
    }

    private static boolean methodEqual(SootMethod method, MethodDeclaration methodDeclaration, CompilationUnit cu,
                                       AbstractTypeDeclaration typeDeclaration) {
        String methodStr = MethodHandleUtil.constructMethodFullName(cu, typeDeclaration, methodDeclaration);
        methodStr = simplifyParam(methodStr);
        String nodeStr = getMethodSignatureFull(method);
        nodeStr = simplifyParam(nodeStr);
        return methodStr.equals(nodeStr);
    }

    public static String getMethodSignatureFull(SootMethod method) {
        List<Type> params = method.getParameterTypes();
        StringBuilder sb = new StringBuilder();
        if (params != null && params.size() != 0) {
            sb.append("(");
            Iterator var3 = params.iterator();

            while(var3.hasNext()) {
                Type t = (Type)var3.next();
                sb.append(t.toString());
                sb.append(",");
            }

            sb.deleteCharAt(sb.length() - 1);
            sb.append(")");
        } else {
            sb.append("()");
        }

        return method.getDeclaringClass().getName() + "." + method.getName() + sb.toString();
    }

    public static String simplifyParam(String methodStr) {
        StringBuilder front = new StringBuilder(methodStr.split("\\(")[0] + "(");
        String param = methodStr.split("\\(")[1];
        String[] params = param.split(",");
        if (param.length() == 1) return front.append(")").toString();
        for (int i = 0 ; i < params.length; i++) {
            String[] parts = params[i].split("\\.");
            params[i] = parts[parts.length - 1];
        }
        for (int i = 0 ;i < params.length - 1; i++) {
            front.append(params[i]).append(",");
        }
        front.append(params[params.length - 1]);
        return front.toString();
    }

    public static List<ConditionWithRange> getRangesFromMethod(CompilationUnit cu,
                                                                MethodDeclaration methodDeclaration) {
        List<ConditionWithRange> result = new LinkedList<>();
        Block methodBody = methodDeclaration.getBody();
        if (methodBody == null) {
            return result;
        }
        List<Object> statements = methodBody.statements();
        result = BodyHandler.handleStatements(cu, statements);
        return result;
    }
}
