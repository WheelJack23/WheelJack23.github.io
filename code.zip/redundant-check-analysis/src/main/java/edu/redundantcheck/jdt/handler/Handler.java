package edu.redundantcheck.jdt.handler;

import edu.redundantcheck.jdt.ConditionWithRange;
import edu.redundantcheck.jdt.JDTParser;
import edu.redundantcheck.util.RepoStatistics;
import org.eclipse.jdt.core.dom.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

// abstract class to handle different kind of JDT statement for redundant null check detection.
public abstract class Handler {
    private static final Logger LOGGER = LoggerFactory.getLogger(Handler.class);
    protected List<ConditionWithRange> ranges;
    protected CompilationUnit cu;

    public Handler(CompilationUnit cu) {
        this.cu = cu;
        ranges = new ArrayList<>();
    }

    public List<ConditionWithRange> getRanges() {
        return ranges;
    }

    public void handleNull(Statement statement) {

    }
    public abstract void handleBlock(Statement statement);
    public abstract void handleIf(Statement statement);
    public void handleOneLine(Statement statement) {
    }
    public void handleFor(Statement statement) {
        if (statement instanceof ForStatement) {
            ranges = ForHandler.getRangesFromForBody(cu, ((ForStatement) statement).getBody());
        }
        else if (statement instanceof EnhancedForStatement) {
            ranges = ForHandler.getRangesFromForBody(cu, ((EnhancedForStatement) statement).getBody());
        }
    }
    public void handleTry(Statement statement) {
        TryStatement tryStatement = (TryStatement) statement;
        // finally body
        Statement finalBody = tryStatement.getFinally();
        BodyHandler finalHandler = new BodyHandler(cu);
        StatementCases.handle(finalBody, finalHandler);
        List<ConditionWithRange> finalRanges = finalHandler.ranges;
        if (containsNullCheck(finalRanges)) return;
        // try body
        Statement tryBody = tryStatement.getBody();
        BodyHandler handler = new BodyHandler(cu);
        StatementCases.handle(tryBody, handler);
        ranges.addAll(handler.getRanges());
        // catch body
        List catchClauses = tryStatement.catchClauses();
        for (Object obj: catchClauses) {
            if (obj instanceof CatchClause) {
                CatchClause catchClause = (CatchClause) obj;
                Statement catchBody = catchClause.getBody();
                BodyHandler catchHandler = new BodyHandler(cu);
                StatementCases.handle(catchBody, catchHandler);
                ranges.addAll(catchHandler.ranges);
            }
            else {
                LOGGER.info("one condition missed.");
            }
        }
        ranges.addAll(finalRanges);
    }

    private boolean containsNullCheck(List<ConditionWithRange> ranges) {
        for (ConditionWithRange range: ranges) {
            Statement statement = range.getStatement();
            if (statement instanceof IfStatement) {
                IfStatement ifStatement = (IfStatement) statement;
                if (RepoStatistics.isNullCheck(ifStatement.getExpression())) return true;
            }
        }
        return false;
    }

    public void handleSwitch(Statement statement) {
        SwitchStatement switchStatement = (SwitchStatement) statement;
        List statements = switchStatement.statements();
        ranges.addAll(BodyHandler.handleStatements(cu, statements));
    }

    public void handleWhile(Statement statement) {
        WhileStatement whileStatement = (WhileStatement) statement;
        Statement body = whileStatement.getBody();
        BodyHandler handler = new BodyHandler(cu);
        StatementCases.handle(body, handler);
        ranges.addAll(handler.getRanges());
    }
    public void handleSync(Statement statement) {
        SynchronizedStatement syncStatement = (SynchronizedStatement) statement;
        Block block = syncStatement.getBody();
        ranges.addAll(BodyHandler.handleStatements(cu, block.statements()));
    }
    public void handleDoStatement(Statement statement) {
        DoStatement doStatement = (DoStatement) statement;
        Statement body = doStatement.getBody();
        BodyHandler handler = new BodyHandler(cu);
        StatementCases.handle(body, handler);
        ranges.addAll(handler.getRanges());
    }

    public void handleLabeledStatement(Statement statement) {
        LabeledStatement labeledStatement = (LabeledStatement) statement;
        Statement body = labeledStatement.getBody();
        BodyHandler handler = new BodyHandler(cu);
        StatementCases.handle(body, handler);
        ranges.addAll(handler.getRanges());
    }
    public void handleTypeStatement(Statement statement) {
        TypeDeclarationStatement typeStatement = (TypeDeclarationStatement) statement;
        AbstractTypeDeclaration typeDeclaration = typeStatement.getDeclaration();
        if (!(typeDeclaration instanceof TypeDeclaration)) {
            return;
        }
        ranges.addAll(getRangesFromTypeDeclaration((TypeDeclaration) typeDeclaration));
    }

    private List<ConditionWithRange> getRangesFromTypeDeclaration(TypeDeclaration concreteType) {
        List<ConditionWithRange> rangeList = new LinkedList<>();
        MethodDeclaration[] methodDeclarations = concreteType.getMethods();

        for (MethodDeclaration methodDeclaration: methodDeclarations) {
            List<ConditionWithRange> result = JDTParser.getRangesFromMethod(cu, methodDeclaration);
            rangeList.addAll(result);
        }

        TypeDeclaration[] subTypes = concreteType.getTypes();
        for (TypeDeclaration subType : subTypes) {
            List<ConditionWithRange> result = getRangesFromTypeDeclaration(subType);
            rangeList.addAll(result);
        }
        return rangeList;
    }
}
