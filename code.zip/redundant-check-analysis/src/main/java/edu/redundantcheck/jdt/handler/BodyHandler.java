package edu.redundantcheck.jdt.handler;

import edu.redundantcheck.jdt.ConditionWithRange;
import org.eclipse.jdt.core.dom.*;

import java.util.ArrayList;
import java.util.List;

// handle different statement to get condition blocks for redundant null check.
public class BodyHandler extends Handler {
    public BodyHandler(CompilationUnit cu) {
        super(cu);
    }

    public static List<ConditionWithRange> handleStatements(CompilationUnit cu, List<Object> statements) {
        List<ConditionWithRange> result = new ArrayList<>();
        for (Object obj : statements) {
            BodyHandler handler = new BodyHandler(cu);
            StatementCases.handle((Statement) obj, handler);
            result.addAll(handler.getRanges());
        }
        return result;
    }

    @Override
    public void handleBlock(Statement statement) {
        List<ConditionWithRange> result = BodyHandler.handleStatements(cu, ((Block)statement).statements());
        ranges.addAll(result);
    }

    @Override
    public void handleIf(Statement statement) {
        IfStatement ifStatement = (IfStatement) statement;
        List<ConditionWithRange> conditionWithRanges = IfStatementHandler.getConditionRangeFromIfStatement(cu, ifStatement);
        ranges.addAll(conditionWithRanges);
    }
}
