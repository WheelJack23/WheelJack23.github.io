package edu.redundantcheck.jdt.handler;

import edu.redundantcheck.jdt.ConditionWithRange;
import org.eclipse.jdt.core.dom.*;

import java.util.List;

// handle for statement
public class ForHandler extends Handler{
    public ForHandler(CompilationUnit cu) {
        super(cu);
    }

    public static List<ConditionWithRange> getRangesFromForBody(CompilationUnit cu, Statement body) {
        ForHandler handler = new ForHandler(cu);
        StatementCases.handle(body, handler);
        return handler.getRanges();
    }


    @Override
    public void handleBlock(Statement statement) {
        List<Object> statements = (List<Object>) ((Block) statement).statements();
        ranges.addAll(BodyHandler.handleStatements(cu, statements));
    }

    @Override
    public void handleIf(Statement statement) {
        ranges.addAll(IfStatementHandler.getConditionRangeFromIfStatement(cu, (IfStatement) statement));
    }
}
