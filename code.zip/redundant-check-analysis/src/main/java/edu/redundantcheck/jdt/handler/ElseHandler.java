package edu.redundantcheck.jdt.handler;

import edu.redundantcheck.jdt.ConditionWithRange;
import org.eclipse.jdt.core.dom.*;

import java.util.ArrayList;
import java.util.List;

// handle else statement in JDT
public class ElseHandler extends Handler{
    private ConditionWithRange firstRange;
    private int ifStart;
    private int ifEnd;
    private boolean isNullCheck;

    public ElseHandler(CompilationUnit cu, ConditionWithRange firstRange, int ifStart, int ifEnd, boolean isNullCheck) {
        super(cu);
        this.firstRange = firstRange;
        this.ifStart = ifStart;
        this.ifEnd = ifEnd;
        this.isNullCheck = isNullCheck;
    }

    @Override
    public void handleNull(Statement statement) {// 没有else分支的情况。
        firstRange.setRange(ifStart, ifEnd);
    }

    @Override
    public void handleBlock(Statement statement) {
        addElseBlock(statement);
        List<ConditionWithRange> innerRanges = BodyHandler.handleStatements(cu, ((Block) statement).statements());
        ranges.addAll(innerRanges);
    }

    @Override
    public void handleIf(Statement statement) {
        IfStatement elseIfStatement = (IfStatement) statement;
        ranges = new ArrayList<>();
        ConditionWithRange elseIfRange = new ConditionWithRange(elseIfStatement);
        if (isNullCheck) ranges.add(elseIfRange);
        int elseIfStart = cu.getLineNumber(elseIfStatement.getStartPosition());
        int elseIfEnd = cu.getLineNumber(elseIfStatement.getStartPosition()
                + elseIfStatement.getLength() - 1);

        List<ConditionWithRange> elseRanges = IfStatementHandler.handleElseStatement(cu, elseIfStatement.getElseStatement(),
                elseIfRange, elseIfStart, elseIfEnd, isNullCheck);
        ranges.addAll(elseRanges);

        List<ConditionWithRange> thenRanges = IfStatementHandler.handleThenStatement(cu, elseIfStatement.getThenStatement());
        ranges.addAll(thenRanges);
        if (isNullCheck) firstRange.setRange(ifStart,  elseIfStart - 1);
    }

    @Override
    public void handleOneLine(Statement statement) {// 一行语句。
        addElseBlock(statement);
    }
    private void addElseBlock(Statement statement) {
        ConditionWithRange blockLeft = new ConditionWithRange(statement);
        int blockStart = cu.getLineNumber(statement.getStartPosition());
        firstRange.setRange(ifStart, blockStart - 1);
        blockLeft.setRange(blockStart, ifEnd);
        if (isNullCheck) ranges.add(blockLeft);
    }

    @Override
    public void handleFor(Statement statement) {
        addElseBlock(statement);
        super.handleFor(statement);
    }

    @Override
    public void handleTry(Statement statement) {
        addElseBlock(statement);
        super.handleTry(statement);
    }

    @Override
    public void handleSwitch(Statement statement) {
        addElseBlock(statement);
        super.handleSwitch(statement);
    }

    @Override
    public void handleWhile(Statement statement) {
        addElseBlock(statement);
        super.handleWhile(statement);
    }

    @Override
    public void handleSync(Statement statement) {
        addElseBlock(statement);
        super.handleSync(statement);
    }

    @Override
    public void handleDoStatement(Statement statement) {
        addElseBlock(statement);
        super.handleDoStatement(statement);
    }

    @Override
    public void handleLabeledStatement(Statement statement) {
        addElseBlock(statement);
        super.handleLabeledStatement(statement);
    }

    @Override
    public void handleTypeStatement(Statement statement) {
        addElseBlock(statement);
        super.handleTypeStatement(statement);
    }
}
