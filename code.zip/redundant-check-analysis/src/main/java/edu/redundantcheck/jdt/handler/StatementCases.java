package edu.redundantcheck.jdt.handler;

import org.eclipse.jdt.core.dom.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// dispatch JDT statement to different handlers.
public class StatementCases {
    private static final Logger LOGGER = LoggerFactory.getLogger(StatementCases.class);

    public static void handle(Statement statement, Handler handler) {
        if (statement == null) {
            handler.handleNull(null);
        }
        else if (statement instanceof Block) {
            handler.handleBlock(statement);
        }
        else if (statement instanceof IfStatement) {
            handler.handleIf(statement);
        }
        else if (isOneLine(statement)) {
            handler.handleOneLine(statement);
        }
        else if (isForStatement(statement)) {
            handler.handleFor(statement);
        }
        else if (statement instanceof TryStatement) {
            handler.handleTry(statement);
        }
        else if (statement instanceof SwitchStatement) {
            handler.handleSwitch(statement);
        }
        else if (statement instanceof WhileStatement) {
            handler.handleWhile(statement);
        }
        else if (statement instanceof SynchronizedStatement) {
            handler.handleSync(statement);
        }
        else if (statement instanceof DoStatement) {
            handler.handleDoStatement(statement);
        }
        else if (statement instanceof LabeledStatement) {
            handler.handleLabeledStatement(statement);
        }
        else if (statement instanceof TypeDeclarationStatement) {
            handler.handleTypeStatement(statement);
        }
        else {
            LOGGER.info("one condition missed.");
        }
    }

    private static boolean isOneLine(Statement statement) {
        return (statement instanceof ExpressionStatement) || (statement instanceof ReturnStatement)
                || (statement instanceof ThrowStatement) || (statement instanceof ContinueStatement)
                || (statement instanceof BreakStatement) || (statement instanceof EmptyStatement)
                || (statement instanceof VariableDeclarationStatement) || (statement instanceof SwitchCase)
                || (statement instanceof ConstructorInvocation) || (statement instanceof SuperConstructorInvocation)
                || (statement instanceof AssertStatement);
    }

    private static boolean isForStatement(Statement statement) {
        return (statement instanceof ForStatement) || (statement instanceof EnhancedForStatement);
    }
}
