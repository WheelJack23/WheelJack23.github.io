package edu.redundantcheck.jdt;

import org.eclipse.jdt.core.dom.*;

import java.util.List;

// JDT compilation unit tool
public class CompilationUnitTool {
    public static List<TypeDeclaration> getTypeDeclarations(CompilationUnit cu) {
        DeclarationVisitor typeDeclarationVisitor = new DeclarationVisitor();
        cu.accept(typeDeclarationVisitor);
        return typeDeclarationVisitor.getTypeDeclarations();
    }
    public static List<EnumDeclaration> getEnumDeclarations(CompilationUnit cu) {
        DeclarationVisitor enumDeclarationVisitor = new DeclarationVisitor();
        cu.accept(enumDeclarationVisitor);
        return enumDeclarationVisitor.getEnumDeclarations();
    }

    public static String getPackageName(CompilationUnit cu) {
        PackageDeclaration packageDeclaration = cu.getPackage();
        if (packageDeclaration == null) return "";
        Name name = packageDeclaration.getName();
        return name.toString();
    }

    public static String getClassName(AbstractTypeDeclaration typeDeclaration) {
        if (!typeDeclaration.isPackageMemberTypeDeclaration() && !typeDeclaration.isMemberTypeDeclaration()) {
            Name name = typeDeclaration.getName();
            if (name == null) return null;
            return name.toString();
        }
        StringBuilder name = new StringBuilder();
        while (true) {
            String className = typeDeclaration.getName().toString();
            name.insert(0, className + "$");
            if (typeDeclaration.isPackageMemberTypeDeclaration()) {
                name = new StringBuilder(name.substring(0, name.length() - 1));
                break;
            }
            if (!(typeDeclaration.getParent() instanceof AbstractTypeDeclaration))
                return null;
            typeDeclaration = (AbstractTypeDeclaration) typeDeclaration.getParent();
        }
        return name.toString();
    }
    public static String getClassName(EnumDeclaration enumDeclaration) {
        if (!(enumDeclaration.isPackageMemberTypeDeclaration() || enumDeclaration.isMemberTypeDeclaration())) {
            Name name = enumDeclaration.getName();
            if (name == null) return null;
            return name.toString();
        }
        EnumDeclaration ed = enumDeclaration;
        String className = ed.getName().toString();
        if (ed.isPackageMemberTypeDeclaration()) {
            return className;
        }else {
            if (!(ed.getParent() instanceof TypeDeclaration))
                return null;
            String parentName = ((TypeDeclaration) ed.getParent()).getName().toString();
            StringBuilder name = new StringBuilder();
            name.insert(0,parentName + "$" + className);
            return name.toString();
        }
    }
}