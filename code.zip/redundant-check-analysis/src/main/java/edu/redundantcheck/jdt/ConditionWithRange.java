package edu.redundantcheck.jdt;

import org.eclipse.jdt.core.dom.Statement;

import java.util.Arrays;

// condition block with line number range.
public class ConditionWithRange {
    private Statement statement;
    private int[] range;
    public ConditionWithRange(Statement statement) {
        this.statement = statement;
        this.range = new int[2];
    }

    public void setRange(int start , int end) {
        range[0] = start;
        range[1] = end;
    }

    public int getStart() {
        return range[0];
    }

    public int getEnd() {
        return range[1];
    }

    public Statement getStatement() {
        return statement;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConditionWithRange range1 = (ConditionWithRange) o;

        if (!statement.equals(range1.statement)) return false;
        return Arrays.equals(range, range1.range);
    }

    @Override
    public int hashCode() {
        int result = statement.hashCode();
        result = 31 * result + Arrays.hashCode(range);
        return result;
    }
}
