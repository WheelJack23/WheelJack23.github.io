package edu.redundantcheck.util;

import java.io.File;

// java file util.
public class FileUtils {
    public static File getFileInDirectory(File directory, String name) {
        File[] files = directory.listFiles();
        for (File file: files) {
            if (file.getName().equals(name)) return file;
        }
        return null;
    }

    public static boolean isJavaFile(File file) {
        return endWith(file.getName(), ".java");
    }

    // judge whether s ends with pattern
    public static boolean endWith(String s, String pattern) {
        int lastIdx = s.lastIndexOf(pattern);
        if (lastIdx == -1) return false;
        return lastIdx + pattern.length() == s.length();
    }

    public static String findJavaFilePathFromSrcDirectory(File srcDirectory, String declaringClass) {
        if (declaringClass.contains("$")) declaringClass = declaringClass.split("\\$")[0];
        if (!srcDirectory.exists() || srcDirectory.isFile())
            throw new RuntimeException(srcDirectory.getAbsolutePath() + " is not a valid directory.");
        if (srcDirectory.listFiles() == null)
            throw new RuntimeException(srcDirectory.getAbsolutePath() + " is empty");
        for (File childFile: srcDirectory.listFiles()) {
            if (childFile.isFile()) {
                if (isJavaFile(childFile)) {
                    String fileName = childFile.getName();
                    String className = fileName.substring(0, fileName.length() - 5);
                    if (className.equals(declaringClass)) return childFile.getAbsolutePath();
                }
            }
            else {
                String directoryName = childFile.getName();
                if (declaringClass.startsWith(directoryName + ".")) {
                    declaringClass = declaringClass.substring(directoryName.length() + 1);
                    return findJavaFilePathFromSrcDirectory(childFile, declaringClass);
                }
            }
        }
        throw new RuntimeException(declaringClass + " is not found in directory " + srcDirectory.getAbsolutePath());
    }
}
