package edu.redundantcheck.util;
import edu.redundantcheck.jdt.ConditionWithRange;
import edu.redundantcheck.jdt.JDTParser;
import org.eclipse.jdt.core.dom.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

// Repo information for a project
public class RepoStatistics {
    public static RepoInfo getRepoInfo(File repoDir) {
        String name = repoDir.getName();
        List<File> javaFiles = getJavaFiles(repoDir);
        RepoInfo repoInfo = new RepoInfo();
        for (File javaFile: javaFiles) {
            List<ConditionWithRange> ranges =
                    JDTParser.getConditionRangesFromPath(javaFile.getAbsolutePath());
            repoInfo.conditionBlockNum += ranges.size();
            repoInfo.nullCheckNum += getNullCheckNum(ranges, false);
            repoInfo.singleNullCheckNum += getNullCheckNum(ranges, true);
        }
        return repoInfo;
    }

    public static void outputRepoInfo(String repoName, int conditionBlockNum, int nullCheckNum, int singleNullCheckNum) {
        String path = "./files/" + repoName + "-info.json";
        try {
            PrintWriter writer = new PrintWriter(new File(path));
            ResultJson json = new ResultJson();
            json.put("conditionBlockNum", conditionBlockNum);
            json.put("nullCheckNum", nullCheckNum);
            json.put("singleNullCheckNum", singleNullCheckNum);
            writer.println(json);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static List<File> getJavaFiles(File dir) {
        List<File> list = new ArrayList<>();
        File[] children = dir.listFiles();
        if (children == null) return list;
        for (File child: children) {
            if (child.isDirectory()) {
                list.addAll(getJavaFiles(child));
                continue;
            }
            if (child.getName().endsWith(".java")) {
                String path = child.getAbsolutePath();
                if (path.contains("\\src\\main\\java") ||
                    path.contains("/src/main/java")) list.add(child);
            }
        }
        return list;
    }

    private static int getNullCheckNum(List<ConditionWithRange> ranges, boolean countSingle) {
        int sum = 0;
        for (ConditionWithRange range: ranges) {
            Statement statement = range.getStatement();
            if (statement instanceof IfStatement) {
                IfStatement ifStatement = (IfStatement) statement;
                Expression expression = ifStatement.getExpression();
                boolean result =
                        countSingle? isSingleNullCheck(expression):isNullCheck(expression);
                if (result) sum++;
            }
        }
        return sum;
    }

    public static boolean isNullCheck(Expression expression) {
        if (expression instanceof InfixExpression) {
            InfixExpression infixExpression = (InfixExpression) expression;
            InfixExpression.Operator operator = infixExpression.getOperator();
            String opStr = operator.toString();
            if (opStr.equals("==") || opStr.equals("!=")) {
                Expression left = infixExpression.getLeftOperand();
                if (left instanceof NullLiteral) return true;
                Expression right = infixExpression.getRightOperand();
                if (right instanceof NullLiteral) return true;
            }
            else if (isCombinedOperator(opStr)) {
                Expression left = infixExpression.getLeftOperand();
                if (isNullCheck(left)) return true;
                Expression right = infixExpression.getRightOperand();
                if (isNullCheck(right)) return true;
            }
        }
        else if (expression instanceof ParenthesizedExpression) {
            ParenthesizedExpression parenthesizedExpression = (ParenthesizedExpression) expression;
            Expression innerExpr = parenthesizedExpression.getExpression();
            return isNullCheck(innerExpr);
        }
        return false;
    }


    public static boolean isSingleNullCheck(Expression expression) {
        // a == null
        if (expression instanceof InfixExpression) {
            InfixExpression infixExpression = (InfixExpression) expression;
            InfixExpression.Operator operator = infixExpression.getOperator();
            String opStr = operator.toString();
            if (opStr.equals("==") || opStr.equals("!=")) {
                Expression left = infixExpression.getLeftOperand();
                if (left instanceof NullLiteral) return true;
                Expression right = infixExpression.getRightOperand();
                if (right instanceof NullLiteral) return true;
            }
        }
        else if (expression instanceof ParenthesizedExpression) {
            ParenthesizedExpression parenthesizedExpression = (ParenthesizedExpression) expression;
            Expression innerExpr = parenthesizedExpression.getExpression();
            return isSingleNullCheck(innerExpr);
        }
        return false;
    }

    private static boolean isCombinedOperator(String op) {
        return op.equals("&") || op.equals("|") || op.equals("&&") || op.equals("||");
    }

    public static class RepoInfo {
        public int conditionBlockNum;
        public int nullCheckNum;
        public int singleNullCheckNum;
    }
}
