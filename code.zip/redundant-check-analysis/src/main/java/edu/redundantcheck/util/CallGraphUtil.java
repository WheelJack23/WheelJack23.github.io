package edu.redundantcheck.util;

import com.alibaba.fastjson.JSONArray;
import edu.callgraph.CallGraphMain;
import edu.callgraph.global.Global;
import edu.callgraph.impurity.bean.Node;

import java.io.IOException;
import java.util.*;

// generate call graph
public class CallGraphUtil {
    public static String javaDocPath = ProperUtil.getProperties().getProperty("javaDocPath");
    public static String logFilePath = ProperUtil.getProperties().getProperty("logFilePath");
    public static String rtJarPath = ProperUtil.getProperties().getProperty("rtJarPath");

    private static List<Node> toNodeList(Set<Node> nodeSet) {
        List<Node> nodeList = new ArrayList<>(nodeSet);
        nodeList.sort(Comparator.comparing(Node::getMethodSignatureFull));
        return nodeList;
    }
    public static List<Node> generateCallGraph(String inputJarPath, String[] methodNames) {
        Global.nodeSet.clear();
        CallGraphMain callGraphMain = getCallGraphMain();
        JSONArray j = new JSONArray();
        for (String methodName: methodNames) j.add(methodName);
        callGraphMain.generateCallGraphByClass(j, inputJarPath);
        return toNodeList(Global.nodeSet);
    }

    public static List<Node> generateCallGraphForSingleWar(String inputWarPath, String[] methodNames) {
        Global.nodeSet.clear();
        CallGraphMain callGraphMain = getCallGraphMain();
        JSONArray j = new JSONArray();
        for (String methodName: methodNames) j.add(methodName);
        try {
            callGraphMain.generateCallGraphForSingleWarByClass(j, inputWarPath);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("IO Exception when dealing with war.");
        }
        return toNodeList(Global.nodeSet);
    }

    public static List<Node> generateCallGraphForMultiModule(String projectPath, String[] methodNames) {
        Global.nodeSet.clear();
        CallGraphMain callGraphMain = getCallGraphMain();
        callGraphMain.generateCallGraphForMultiModuleByClass(methodNames, projectPath);
        return toNodeList(Global.nodeSet);
    }

    private static CallGraphMain getCallGraphMain() {
        CallGraphMain callGraphMain = new CallGraphMain(
                javaDocPath,
                logFilePath,
                rtJarPath);
        return callGraphMain;
    }
}
