package edu.redundantcheck.util;

import java.io.*;
import java.util.Properties;

// read call graph properties.
public class ProperUtil {
    private static String DEFAULT_PATH1 = "./callgraph.properties";
    private static String DEFAULT_PATH2 = "src/main/resources/callgraph.properties";
    private static Properties properties;

    public static Properties getProperties() {
        if (properties == null) {
            File f1 = new File(DEFAULT_PATH1);
            File f2 = new File(DEFAULT_PATH2);
            if (!f1.exists() && !f2.exists()) {
                throw new RuntimeException("callgraph.properties does not exist.");
            }
            if (f1.exists()) properties = getProp(DEFAULT_PATH1);
            else properties = getProp(DEFAULT_PATH2);
        }
        return properties;
    }


    private static Properties getProp(String path) {
        Properties prop = new Properties();
        try {
            InputStream in = new BufferedInputStream(new FileInputStream(path));
            prop.load(in);
            in.close();
            return prop;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return prop;
    }
}
