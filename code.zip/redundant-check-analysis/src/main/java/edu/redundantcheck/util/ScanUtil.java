package edu.redundantcheck.util;

import edu.redundantcheck.jdt.CompilationUnitTool;
import edu.redundantcheck.jdt.JDTParserFactory;
import edu.redundantcheck.jdt.MethodHandleUtil;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

// scan all java file to get public and protected method.
public class ScanUtil {
    public static String[] scanEntryPointsSingleModule(String srcPath) {
        List<String> entryPoints = new ArrayList<>();
        List<File> files = getJavaFilesInSrc(new File(srcPath));
        for (File file: files) {
            entryPoints.addAll(getEntryPointsInJavaFile(file));
        }
        return entryPoints.toArray(new String[0]);
    }

    public static List<String> getEntryPointsInJavaFile(File file) {
        CompilationUnit compilationUnit = JDTParserFactory.getCompilationUnit(file);
        return getEntryPointsInCU(compilationUnit);
    }
    private static List<String> getEntryPointsInCU(CompilationUnit cu) {
        List<String> entryPoints = new LinkedList<>();
        List<TypeDeclaration> classDeclarations = CompilationUnitTool.getTypeDeclarations(cu);
        List<EnumDeclaration> enumDeclarations = CompilationUnitTool.getEnumDeclarations(cu);
        String packageName = CompilationUnitTool.getPackageName(cu);
        for (TypeDeclaration typeDeclaration : classDeclarations) {
            String className = CompilationUnitTool.getClassName(typeDeclaration);
            if (className == null) {
                continue;
            }
            MethodDeclaration[] methods = typeDeclaration.getMethods();
            for (MethodDeclaration method: methods) {
                String methodName = MethodHandleUtil.getMethodNameWithoutPackageAndClassName(method);
                String methodFullName = MethodHandleUtil.constructMethodFullName(packageName,
                        className, methodName);
                if (!MethodHandleUtil.isPrivate(method)) {
                    entryPoints.add(methodFullName);
                }
            }
        }
        for (EnumDeclaration enumDeclaration : enumDeclarations) {
            String className = CompilationUnitTool.getClassName(enumDeclaration);
            if (className == null) continue;
            List bodyDeclarations = enumDeclaration.bodyDeclarations();
            for (Object obj : bodyDeclarations) {
                if (obj instanceof MethodDeclaration) {
                    String methodName = MethodHandleUtil.getMethodNameWithoutPackageAndClassName((MethodDeclaration) obj);
                    String methodFullName = MethodHandleUtil.constructMethodFullName(packageName,
                            className, methodName);
                    if (!MethodHandleUtil.isPrivate((MethodDeclaration) obj)) {
                        entryPoints.add(methodFullName);
                    }
                }
            }
        }
        return entryPoints;
    }

    public static String[] scanEntryPointsMultiModule(File projectFile) {
        List<String> entryPoints = new ArrayList<>();
        List<File> files = getJavaFilesInSrc(projectFile);
        for (File file: files) {
            CompilationUnit compilationUnit = JDTParserFactory.getCompilationUnit(file);
            entryPoints.addAll(getEntryPointsInCU(compilationUnit));
        }
        return entryPoints.toArray(new String[0]);
    }
    public static String[] scanEntryPointsMultiModule(String projectPath) {
        return scanEntryPointsMultiModule(new File(projectPath));
    }

    public static List<File> getJavaFiles(File directory) {
        List<File> javaFiles = new LinkedList<>();
        File[] files = directory.listFiles();
        for (File file: files) {
            if (file.isFile()) {
                if (FileUtils.isJavaFile(file)) {
                    javaFiles.add(file);
                }
            }
            else { // isDirectory
                List<File> filesInDirectory = getJavaFiles(file);
                javaFiles.addAll(filesInDirectory);
            }
        }
        return javaFiles;
    }

    public static List<File> getJavaFilesInSrc(File dir) {
        List<File> files = new LinkedList<>();
        File[] directories = dir.listFiles();
        if (directories == null) {
            return files;
        }
        for (File directory: directories) {
            if (directory.isDirectory()) {
                List<File> filesInDir = getJavaFilesInSrc(directory);
                files.addAll(filesInDir);
            }
            else {
                if (directory.getAbsolutePath().endsWith(".java") &&
                        !directory.getAbsolutePath().contains(File.separator + "target" + File.separator)
//                        && !directory.getAbsolutePath().contains(File.separator + "test" + File.separator)
//                        && !directory.getAbsolutePath().contains(File.separator + "tests" + File.separator)
                ) {
                    files.add(directory);
                }
            }
        }
        return files;
    }
}
