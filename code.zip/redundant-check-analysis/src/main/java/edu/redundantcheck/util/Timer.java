package edu.redundantcheck.util;

// record time
public class Timer {
    private static long beginTime = -1;
    public static void start() {
        beginTime = System.currentTimeMillis();
    }
    public static double getSeconds() {
        if (beginTime == -1) throw new RuntimeException("Illegal use of timer.");
        long endTime = System.currentTimeMillis();
        double costTime = (endTime - beginTime) / 1000.0;
        beginTime = -1;
        return costTime;
    }
}
