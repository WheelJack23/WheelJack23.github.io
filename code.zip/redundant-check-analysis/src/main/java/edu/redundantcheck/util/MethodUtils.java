package edu.redundantcheck.util;

import edu.callgraph.global.Global;
import edu.callgraph.impurity.bean.Node;
import soot.SootMethod;

import java.util.HashSet;
import java.util.Set;

// Get soot method basic information
public class MethodUtils {
    private static Set<SootMethod> methods = new HashSet<>();

    private static void prepareSet() {
        if (methods.size() == Global.nodeSet.size()) return;
        methods.clear();
        for (Node node: Global.nodeSet) {
            methods.add(node.getMethod());
        }
    }

    public static boolean graphContainsMethod(SootMethod method) {
        prepareSet();
        return methods.contains(method);
    }

    public static String getMethodSignature(SootMethod method) {
        String className = method.getDeclaringClass().getName();
        String methodName = method.getName();
        return className.isEmpty() ? methodName:className+"."+methodName;
    }
}
