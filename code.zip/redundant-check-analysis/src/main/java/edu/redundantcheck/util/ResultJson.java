package edu.redundantcheck.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

// format result to json
public class ResultJson extends JSONObject {
    @Override
    public String toString() {
        return toJSONString(this, SerializerFeature.PrettyFormat,
                SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty,SerializerFeature.WriteDateUseDateFormat);
    }

    public static String toJson(Object obj) {
        return JSONObject.toJSONString(obj, SerializerFeature.PrettyFormat,
                SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty,
                SerializerFeature.WriteDateUseDateFormat);
    }
}
