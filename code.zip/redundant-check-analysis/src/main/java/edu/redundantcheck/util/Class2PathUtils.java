package edu.redundantcheck.util;

import edu.redundantcheck.jdt.CompilationUnitTool;
import edu.redundantcheck.jdt.JDTParserFactory;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// a map from class name to java file path.
public class Class2PathUtils {
    private static Map<String, String> class2path = new HashMap<>();

    public static String getPath(String className) {
        return class2path.get(className);
    }

    public static void initData(String projectPath) {
        class2path.clear();
        File file = new File(projectPath);
        List<File> javaFiles = ScanUtil.getJavaFilesInSrc(file);
        for (File javaFile: javaFiles) {
            addClassInJava(javaFile);
        }
    }

    public static void addClassInJava(File javaFile) {
        CompilationUnit cu = JDTParserFactory.getCompilationUnit(javaFile);
        if (cu == null) return;
        String packageName = CompilationUnitTool.getPackageName(cu);
        List<TypeDeclaration> classDeclarations = CompilationUnitTool.getTypeDeclarations(cu);
        for (TypeDeclaration typeDeclaration : classDeclarations) {
            handleTypeDeclaration(typeDeclaration, packageName, javaFile);
        }
        List<Object> types = cu.types();
        for (Object obj : types) {
            if (obj instanceof EnumDeclaration) handleEnumType((EnumDeclaration) obj, packageName, javaFile);
        }
    }

    public static void handleTypeDeclaration(TypeDeclaration typeDeclaration, String packageName, File javaFile) {
        String className = CompilationUnitTool.getClassName(typeDeclaration);
        className = constructClassNameWithPackage(packageName, className);
        class2path.put(className, javaFile.getAbsolutePath());

        TypeDeclaration[] childTypes = typeDeclaration.getTypes();
        if (childTypes == null) return;
        for (TypeDeclaration childType : childTypes) {
            handleTypeDeclaration(childType, packageName, javaFile);
        }

        List types = typeDeclaration.bodyDeclarations();
        handleBodyDeclarations(types, packageName, javaFile);
    }

    public static void handleEnumType(EnumDeclaration enumDeclaration, String packageName, File javaFile) {
        String enumName = CompilationUnitTool.getClassName(enumDeclaration);
        enumName = constructClassNameWithPackage(packageName, enumName);
        class2path.put(enumName, javaFile.getAbsolutePath());
        List types = enumDeclaration.bodyDeclarations();
        handleBodyDeclarations(types, packageName, javaFile);
    }

    public static void handleBodyDeclarations(List bodyDeclarations, String packageName, File javaFile) {
        for (Object obj : bodyDeclarations) {
            if (obj instanceof TypeDeclaration) handleTypeDeclaration((TypeDeclaration) obj, packageName, javaFile);
            else if (obj instanceof EnumDeclaration) handleEnumType((EnumDeclaration) obj, packageName, javaFile);
        }
    }

    private static String constructClassNameWithPackage(String packageName, String className) {
        if (packageName.equals("")) return className;
        else {
            StringBuilder sb = new StringBuilder();
            sb.append(packageName).append(".").append(className);
            return sb.toString();
        }
    }
}
