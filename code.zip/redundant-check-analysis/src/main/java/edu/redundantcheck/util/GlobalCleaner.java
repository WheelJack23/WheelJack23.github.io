package edu.redundantcheck.util;

import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.ParamConclusion;

// clean cache information from last detection.
public class GlobalCleaner {
    public static void clean() {
        ParamConclusion.clear();
        UnitGraphTool.clean();
    }
}
