package edu.redundantcheck;

import edu.redundantcheck.analyses.RedundantAnalyzer;
import edu.redundantcheck.analyses.result.CombineResult;
import edu.redundantcheck.util.RepoStatistics;
import edu.redundantcheck.util.ResultJson;
import edu.redundantcheck.util.ScanUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

// This is for redundant null check analysis
public class RunRedundantCheck {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("usage: java -jar RedundantCheckAnalysis-1.0-SNAPSHOT.jar <project-path>");
            return;
        }
        String projectPath = args[0];
        File projectFile = new File(projectPath);
        if (!projectFile.exists()) {
            System.out.println("invalid project path: " + projectPath);
            return;
        }
        RepoStatistics.RepoInfo repoInfo = RepoStatistics.getRepoInfo(projectFile);
        String[] methodNames = ScanUtil.scanEntryPointsMultiModule(projectPath);
        CombineResult result = RedundantAnalyzer.analyzeMultiModule(projectPath, methodNames);
        outputResult(projectFile.getName(), repoInfo, result, 0.0);
    }

    public static void outputResult(String projectName,
                                    RepoStatistics.RepoInfo repoInfo,
                                    CombineResult result, double costTime) {
        File filesDir = new File("./files");
        if (!filesDir.exists()) filesDir.mkdir();
        String path = "./files/" + projectName + "-result.json";
        try {
            PrintWriter writer = new PrintWriter(new File(path));
            ResultJson json = new ResultJson();
            json.put("result", result);
            json.put("certainReachableBlocksNum", result.getCertainReachableBlocks().size());
            json.put("unreachableBlocksNum", result.getUnreachableBlocks().size());
            json.put("repoInfo", repoInfo);
            json.put("costTime", costTime);
            writer.println(json);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
