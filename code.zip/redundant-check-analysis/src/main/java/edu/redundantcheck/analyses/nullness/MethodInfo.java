package edu.redundantcheck.analyses.nullness;

import edu.callgraph.impurity.bean.Node;
import soot.SootMethod;
import soot.Type;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;
import soot.tagkit.VisibilityParameterAnnotationTag;

import java.util.ArrayList;
import java.util.List;

// get method annotations
public class MethodInfo {
    public enum ParamStatus {
        Nullable, NonNull, None;
    }

    public static List<ParamStatus> getAnnotatedParamStatusList(Node node) {
        SootMethod method = node.getMethod();
        List<VisibilityAnnotationTag> annotationTags = getAnnotationTags(node);
        List<ParamStatus> paramStatusList = new ArrayList<>();
        for (int i = 0 ; i < method.getParameterCount(); i++) {
            ParamStatus status = ParamStatus.None;
            if (annotationTags != null) {
                VisibilityAnnotationTag tag = annotationTags.get(i);
                if (tag != null) status = toStatus(tag);
            }
            paramStatusList.add(status);
        }
        return paramStatusList;
    }

    public static ParamStatus getAnnotatedReturnStatus(Node node) {
        return getAnnotatedReturnStatus(node.getMethod());
    }

    public static ParamStatus getAnnotatedReturnStatus(SootMethod method) {
        List<Tag> tags = method.getTags();
        for (Tag tag: tags) {
            if (tag instanceof VisibilityAnnotationTag) {
                List<AnnotationTag> annotations = ((VisibilityAnnotationTag) tag).getAnnotations();
                for (AnnotationTag annotation: annotations) {
                    if (isNonNull(annotation)) return ParamStatus.NonNull;
                    if (isNullable(annotation)) return ParamStatus.Nullable;
                }
            }
        }
        return ParamStatus.None;
    }

    private static ParamStatus toStatus(VisibilityAnnotationTag tag) {
        List<AnnotationTag> annotations = tag.getAnnotations();
        for (AnnotationTag annotation: annotations) {
            if (isNonNull(annotation)) {
                return ParamStatus.NonNull;
            }
            else if (isNullable(annotation)) {
                return ParamStatus.Nullable;
            }
        }
        return ParamStatus.None;
    }
    private static boolean isNullable(AnnotationTag annotation) {
        String annotationStr = annotation.getType().toLowerCase();
        return annotationStr.contains("nullable") || annotationStr.contains("checkfornull");
    }

    private static boolean isNonNull(AnnotationTag annotation) {
        String annotationStr = annotation.getType().toLowerCase();
        return annotationStr.contains("notnull") || annotationStr.contains("nonnull");
    }

    private static List<VisibilityAnnotationTag> getAnnotationTags(Node node) {
        List<Tag> tags = node.getMethod().getTags();
        for (Tag tag: tags) {
            if (tag instanceof VisibilityParameterAnnotationTag) {
                return ((VisibilityParameterAnnotationTag) tag).getVisibilityAnnotations();
            }
        }
        return null;
    }

}
