package edu.redundantcheck.analyses.status;

import edu.redundantcheck.analyses.nullness.NullnessConfig;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

// Status includes constant and instance status
public class VarStatus {
    public enum Status {
        NULL, UNKNOWN_DEFAULT, NON_NULL, UNKNOWN_LOW_RISK, UNKNOWN_MID_RISK, UNKNOWN_HIGH_RISK
    }
    public static Null NULL; // 01
    public static VarStatus UNKNOWN_DEFAULT; // 00
    public static VarStatus UNKNOWN_HIGH_RISK; // 11
    public static VarStatus UNKNOWN_LOW_RISK;
    public static VarStatus UNKNOWN_MID_RISK;
    public static VarStatus NON_NULL;
    static {
        NULL = new Null("DEFAULT", -1);
        UNKNOWN_HIGH_RISK = new UnknownHighRisk(NULL);
        UNKNOWN_HIGH_RISK.field2status = new HashMap<>();
        UNKNOWN_DEFAULT = new VarStatus();
        UNKNOWN_DEFAULT.nullStatus = Status.UNKNOWN_DEFAULT;
        UNKNOWN_DEFAULT.isConstant = true;
        UNKNOWN_DEFAULT.field2status = new HashMap<>();
        UNKNOWN_LOW_RISK = new VarStatus();
        UNKNOWN_LOW_RISK.nullStatus = Status.UNKNOWN_LOW_RISK;
        UNKNOWN_LOW_RISK.isConstant = true;
        UNKNOWN_LOW_RISK.field2status = new HashMap<>();
        UNKNOWN_MID_RISK = new VarStatus();
        UNKNOWN_MID_RISK.nullStatus = Status.UNKNOWN_MID_RISK;
        UNKNOWN_MID_RISK.isConstant = true;
        UNKNOWN_MID_RISK.field2status = new HashMap<>();
        NON_NULL = new VarStatus();
        NON_NULL.field2status = new HashMap<>();
        NON_NULL.nullStatus = Status.NON_NULL;
        NON_NULL.isConstant = true;
    }
    private static Map<VarStatus, VarStatus> status2clone = new HashMap<>();
    private static Map<VarStatusPair, VarStatus> twoStatuses2merge = new HashMap<>();

    protected Map<String, VarStatus> field2status;
    public Status nullStatus;
    protected boolean isConstant;
    protected int paramIdx;
    public VarStatus() {
        this.paramIdx = -1;
    }

    public int getParamIdx() {
        if (isConstants(this)) return -1;
        return paramIdx;
    }

    public void setParamIdx(int paramIdx) {
        this.paramIdx = paramIdx;
    }

    public static VarStatus getNonNullInstance() {
        VarStatus nonNullStatus = new VarStatus();
        nonNullStatus.field2status = new HashMap<>();
        nonNullStatus.nullStatus = Status.NON_NULL;
        nonNullStatus.isConstant = false;
        return nonNullStatus;
    }
    public static VarStatus getUnknownInstance(VarStatus unknownStatus) {
        if (unknownStatus.nullStatus == Status.UNKNOWN_HIGH_RISK) {
            return UnknownHighRisk.getInstance((UnknownHighRisk) unknownStatus);
        }
        return getUnknownInstance(unknownStatus.nullStatus);
    }

    public static VarStatus getUnknownInstance(Status riskLevel) {
        VarStatus unknown = new VarStatus();
        unknown.nullStatus = riskLevel;
        unknown.isConstant = false;
        return unknown;
    }
    private static VarStatus getUnknownConstant(Status riskLevel) {
        if (riskLevel == Status.UNKNOWN_MID_RISK) return UNKNOWN_MID_RISK;
        else return UNKNOWN_LOW_RISK;
    }

    public static VarStatus getUnknownConstant(VarStatus unknownStatus) {
        if (unknownStatus.nullStatus == Status.UNKNOWN_HIGH_RISK) return unknownStatus;
        return getUnknownConstant(unknownStatus.nullStatus);
    }

    public static VarStatus appendTraceWithMap(VarStatus oldStatus, Null.Trace trace,
                                        Map<VarStatus, VarStatus> old2new) {
        if (old2new.containsKey(oldStatus)) return old2new.get(oldStatus);
        if (oldStatus instanceof Null) {// copy on write
            VarStatus newStatus = ((Null) oldStatus).appendTrace(trace);
            old2new.put(oldStatus, newStatus);
            return newStatus;
        }
        if (oldStatus instanceof UnknownHighRisk) {// copy on write
            VarStatus newStatus = ((UnknownHighRisk) oldStatus).appendTrace(trace);
            old2new.put(oldStatus, newStatus);
            return newStatus;
        }
        if (VarStatus.isNonNullInstance(oldStatus)) {// return copy one.
            VarStatus newStatus = getNonNullInstance();
            old2new.put(oldStatus, newStatus);
            for (String field: oldStatus.field2status.keySet()) {
                newStatus.setFieldStatus(field, VarStatus.appendTraceWithMap(oldStatus.getFieldStatus(field), trace, old2new));
            }
            return newStatus;
        }
        // NON_NULL, UNKNOWN or Unknown Instance except high risk
        return oldStatus;
    }

    public static VarStatus appendTrace(VarStatus status, Null.Trace trace) {
        return appendTraceWithMap(status, trace, new HashMap<>());
    }

    public static boolean isUnknownRisky(VarStatus status) {
        if (status == null) return false;
        return status.nullStatus != Status.NON_NULL && status.nullStatus != Status.NULL;
    }
    public static boolean isUnknownInstance(VarStatus status) {
        return !isConstants(status) && isUnknownRisky(status);
    }

    public static boolean isNonNull(VarStatus status) {
        if (status == null) return false;
        return status.nullStatus == Status.NON_NULL;
    }

    public static boolean isNonNullInstance(VarStatus status) {
        return isNonNull(status) && status != NON_NULL;
    }
    public boolean isNull() {
        return nullStatus == Status.NULL;
    }
    public boolean isUnknownHighRisk() {
        return nullStatus == Status.UNKNOWN_HIGH_RISK;
    }

    public static boolean isConstants(VarStatus status) {
        if (status == null) return false;
        return status.isConstant;
    }

    public static VarStatus mergeUnknown(VarStatus unknown1, VarStatus unknown2) {
        if (unknown1 == unknown2) return unknown1;
        if (isConstants(unknown1) && isConstants(unknown2)) {
            return maxUnknownConstant(unknown1, unknown2);
        }
        return maxUnknownConstant(unknown1, unknown2);
    }

    private static VarStatus maxUnknownConstant(VarStatus in1, VarStatus in2) {
        if (in1.isHighestRiskStatus() && in2.isHighestRiskStatus()) {
            Null null1 = ((UnknownHighRisk)in1).getNullValue();
            Null null2 = ((UnknownHighRisk)in2).getNullValue();
            return new UnknownHighRisk(mergeNull(null1, null2));
        }
        if (in1.isUnknownHighRisk()) return UnknownHighRisk.getConstant((UnknownHighRisk) in1);
        if (in2.isUnknownHighRisk()) return UnknownHighRisk.getConstant((UnknownHighRisk) in2);
        if (in1.nullStatus == Status.UNKNOWN_MID_RISK || in2.nullStatus == Status.UNKNOWN_MID_RISK) return UNKNOWN_MID_RISK;
        return UNKNOWN_LOW_RISK;
    }
    private static Status maxUnknownStatus(Status s1, Status s2) {
        if (s1 == Status.UNKNOWN_HIGH_RISK || s2 == Status.UNKNOWN_HIGH_RISK) return Status.UNKNOWN_HIGH_RISK;
        if (s1 == Status.UNKNOWN_MID_RISK || s2 == Status.UNKNOWN_MID_RISK) return Status.UNKNOWN_MID_RISK;
        return Status.UNKNOWN_LOW_RISK;
    }
    public static VarStatus highestRisk(VarStatus nullValue) {
//        if (!(nullValue instanceof Null)) {
//            System.out.println();
//        }
        return new UnknownHighRisk((Null) nullValue);
    }

    public boolean isHighestRiskStatus() {
        return nullStatus == Status.UNKNOWN_HIGH_RISK;
    }

    public static VarStatus mergeNoDepth(VarStatus in1, VarStatus in2) {// constant 4x4
        if (in1 == UNKNOWN_DEFAULT) {
            return in2;
        }
        else if (in2 == UNKNOWN_DEFAULT) {
            return in1;
        }
        else if (in1.isNull()) {
            if (in2 == NON_NULL) return highestRisk(in1);
            if (in2.isNull()) return mergeNull((Null) in1, (Null) in2);
//            if (isUnknownRisky(in2))
            return highestRisk(in1);
        }
        else if (isUnknownRisky(in1)) {
            if (in2 == NON_NULL) return in1;
            if (in2.isNull()) return highestRisk(in2);
//            if (isUnknownRisky(in2))
            return maxUnknownConstant(in1, in2);
        }
        else { // NON_NULL
            if (isUnknownRisky(in2)) return in2;
            if (in2.isNull()) return highestRisk(in2);
            // in2 == NON_NULL
            return NON_NULL;
        }
    }

    public static Null mergeNull(Null n1, Null n2) {
        if (n1.getParamIdx() == -1) {
            return n2;
        }
        if (n2.getParamIdx() == -1) {
            return n1;
        }
        return Null.NullType.merge(n1, n2);
    }

    public static VarStatus mergeInstances(VarStatus in1, VarStatus in2) {
        if (in1 == null) {
            return in2 == null ? VarStatus.UNKNOWN_DEFAULT:in2.cloneStatus();
        }
        if (in2 == null) {
            return in1.cloneStatus();
        }
        VarStatus out = getTwoStatusesMerged(in1, in2);
        if (out != null) return out;
        if (VarStatus.isUnknownInstance(in1) || VarStatus.isUnknownInstance(in2)) {
            if (in1.isUnknownHighRisk()) {
                out = VarStatus.getUnknownInstance(in1);
            }
            else if (in2.isUnknownHighRisk()) {
                out = VarStatus.getUnknownInstance(in2);
            }
            else {
                Status maxUnknown = maxUnknownStatus(in1.nullStatus, in2.nullStatus);
                out = VarStatus.getUnknownInstance(maxUnknown);
            }
            if (in1.paramIdx == in2.paramIdx) out.paramIdx = in1.paramIdx;
            twoStatuses2merge.put(new VarStatusPair(in1, in2), out);
            return out;
        }
        out = VarStatus.getNonNullInstance();
        if (in1.paramIdx == in2.paramIdx) out.paramIdx = in1.paramIdx;
        twoStatuses2merge.put(new VarStatusPair(in1, in2), out);
        for (String name1: in1.field2status.keySet()) {
            if (in2.field2status.containsKey(name1)) {
                out.field2status.put(name1, merge(in1.getFieldStatus(name1), in2.getFieldStatus(name1)));
            }
            else {
                out.field2status.put(name1, UNKNOWN_LOW_RISK);
            }
        }
        for (String name2: in2.field2status.keySet()) {
            if (in1.field2status.containsKey(name2)) {
                out.field2status.put(name2, merge(in1.getFieldStatus(name2), in2.getFieldStatus(name2)));
            }
            else {
                out.field2status.put(name2, UNKNOWN_LOW_RISK);
            }
        }
        return out;
    }

    private static VarStatus getTwoStatusesMerged(VarStatus in1, VarStatus in2) {
        VarStatusPair key = new VarStatusPair(in1, in2);
        return twoStatuses2merge.get(key);
    }

    public static class VarStatusPair {
        private VarStatus in1;
        private VarStatus in2;
        public VarStatusPair(VarStatus in1, VarStatus in2) {
            this.in1 = in1;
            this.in2 = in2;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            VarStatusPair that = (VarStatusPair) o;

            if (in1 != that.in1) {
                return in1 == that.in2 && in2 == that.in1;
            }
            return in2 == that.in2;
        }

        @Override
        public int hashCode() {
            int hash1 = in1 != null ? in1.hashCode() : 0;
            int hash2 = in2 != null ? in2.hashCode() : 0;
            return 31 * (hash1 + hash2);
        }
    }

    public static VarStatus mergeConstantNonNullInstance(VarStatus in1, VarStatus in2) {
        if (isConstants(in2)) {
            VarStatus tmp = in1;
            in1 = in2;
            in2 = tmp;
        }
        // in1 is constant, in2 is non_null instance
        // 4 x 1
        if (in1 == UNKNOWN_DEFAULT) {
            return in2.cloneStatus();
        }
        if (in1.isNull()) {
            VarStatus riskStatus = highestRisk(in1);
            if (in1.getParamIdx() == in2.getParamIdx()) {
                riskStatus.setParamIdx(in1.paramIdx);
            }
            return riskStatus;
        }
        if (isUnknownRisky(in1)) return in1;
        else {
            return VarStatus.getNonNullInstance();
        }
    }

    public static VarStatus merge(VarStatus in1, VarStatus in2) {
        if (isConstants(in1) && isConstants(in2)) {
            return mergeNoDepth(in1, in2);
        }
        if (isUnknownRisky(in1) && isUnknownRisky(in2)) {
            return mergeUnknown(in1, in2);
        }
        if (isConstants(in1) || isConstants(in2)) {
            return mergeConstantNonNullInstance(in1, in2);
        }
        return mergeInstances(in1, in2);
    }

    public void replaceField(VarStatus outer) {
        for (String field: outer.field2status.keySet()) {
            field2status.put(field, outer.field2status.get(field));
        }
    }

    public void replace(VarStatus origin, VarStatus newStatus, Set<VarStatus> visitedNonNulls) {
        for (String key: field2status.keySet()) {
            VarStatus valueStatus = field2status.get(key);
            if (valueStatus == origin) {
                field2status.put(key, newStatus);
            }
            else {
                if (isNonNullInstance(valueStatus)&&!visitedNonNulls.contains(valueStatus)) {
                    visitedNonNulls.add(valueStatus);
                    valueStatus.replace(origin, newStatus, visitedNonNulls);
                }
            }
        }
    }

    public VarStatus cloneStatus() {
        return cloneStatus(NullnessConfig.getFieldDepth());
    }

    public VarStatus cloneStatusWithNegativeParamIdx() {
        return cloneStatusWithNegativeParamIdx(NullnessConfig.getFieldDepth());
    }

    private VarStatus cloneStatusWithNegativeParamIdx(int fieldDepth) {
        if (status2clone.containsKey(this)) return status2clone.get(this);
        if (isNull()) {
            if (paramIdx != -1) {
                Null nullValue = ((Null)this).hardCopy();
                nullValue.setParamIdx(-1);
                status2clone.put(this, nullValue);
                return nullValue;
            }
            return this;
        }
        if (isConstants(this)) return this;
        if (isUnknownRisky(this)) {// unknown instance
            VarStatus unknownValue = getUnknownInstance(this);
            unknownValue.setParamIdx(-1);
            status2clone.put(this, unknownValue);
            return unknownValue;
        }
        if (fieldDepth == 0) return getFieldDepth0Clone(this);
        // NON_NULL instance
        VarStatus cl = getNonNullInstance();
        status2clone.put(this, cl);
        for (String name: field2status.keySet()) {
            cl.setFieldStatus(name, field2status.get(name).cloneStatusWithNegativeParamIdx(fieldDepth-1));
        }
        return cl;
    }

    private VarStatus cloneStatus(int fieldDepth) {
        if (isConstants(this)) return this;
        if (isUnknownRisky(this)) return this;
        if (isNull()) return this;
        if (fieldDepth == 0) {
            return getFieldDepth0Clone(this);
        }
        // NON_NULL instance
        if (status2clone.containsKey(this)) return status2clone.get(this);
        VarStatus cl = getNonNullInstance();
        cl.setParamIdx(paramIdx);
        status2clone.put(this, cl);
        for (String name: field2status.keySet()) {
            cl.setFieldStatus(name, field2status.get(name).cloneStatus(fieldDepth-1));
        }
        return cl;
    }

    private VarStatus getFieldDepth0Clone(VarStatus status) {
        if (VarStatus.isNonNull(status)) return NON_NULL;
        return NullnessConfig.getFieldDefaultRisk();
    }

    public static void assertNegativeParam(VarStatus status) {
        assertNegativeParam(status, new HashSet<>());
    }

    public static void assertNegativeParam(VarStatus status, Set<VarStatus> visited) {
        if (status == null) return;
        if (visited.contains(status)) return;
        visited.add(status);
        if (status.paramIdx != -1) throw new RuntimeException();
        if (VarStatus.isNonNullInstance(status)) {
            for (String field: status.getField2status().keySet()) {
                assertNegativeParam(status.getFieldStatus(field), visited);
            }
        }
    }

    public static void assertNegativeParamInner(VarStatus status) {
        if (VarStatus.isNonNullInstance(status)) {
            for (String field: status.getField2status().keySet()) {
                assertNegativeParam(status.getFieldStatus(field));
            }
        }
    }

    public void setFieldStatus(String name, VarStatus value) {
        field2status.put(name, value);
    }

    public void setField2Unknown(VarStatus unknown) {
        for (String field: field2status.keySet()) {
            field2status.put(field, unknown);
        }
    }

    public VarStatus getFieldStatus(String name) {
        VarStatus info = field2status.get(name);
        if (info == null) {
            return NullnessConfig.getFieldDefaultRisk();
        }
        return info;
    }

    public Map<String, VarStatus> getField2status() {
        return field2status;
    }

    public static void cleanCloneMergeInfo() {
        status2clone.clear();
        twoStatuses2merge.clear();
    }


    public void clear() {
        field2status.clear();
    }
}
