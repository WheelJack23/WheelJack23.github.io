package edu.redundantcheck.analyses.nullness;

import edu.callgraph.global.Global;
import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.SootMethod;
import soot.Value;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.toolkits.callgraph.Edge;

import java.util.*;

// handle special methods
public class InvokeMethodUtil {
    private static Map<String, Set<String>> className2exitMethods;
    private static Map<String, Set<String>> className2nonNullMethods;
    private static Set<String> nonNullMethods;
    private static Set<String> utilNonNullMethods =
            new HashSet<>(Arrays.asList("iterator", "stream", "filter", "values", "sorted",
                    "map", "keySet", "valueSet", "entrySet"));
    static {
        initClassName2nonNullMethods();
    }
    private static void initClassName2nonNullMethods() {
        ClassLoader cl = InvokeMethodUtil.class.getClassLoader();
        className2nonNullMethods = InvokeExprHandler.getClassName2methods(cl.getResourceAsStream("class2nonnullmethods.txt"));
        nonNullMethods = InvokeExprHandler.getMethods(cl.getResourceAsStream("class2nonnullmethods.txt"));
        className2exitMethods = InvokeExprHandler.getClassName2methods(cl.getResourceAsStream("class2exitmethods.txt"));
    }

    private static boolean isNonNullMethod(SootMethod method) {
        String methodName = method.getName();
        // * toString
        if (nonNullMethods.contains(methodName)) return true;

        // * java.util.* iterator
        String declaringClass = method.getDeclaringClass().toString();
        if (declaringClass.startsWith("java.util.") && utilNonNullMethods.contains(methodName)) return true;

        // * others
        Set<String> classNonNullMethods = className2nonNullMethods.get(declaringClass);
        if (classNonNullMethods != null && classNonNullMethods.contains(methodName)) return true;
        return false;
    }


    public static boolean isExitMethod(InvokeExpr invokeExpr) {
        SootMethod method = invokeExpr.getMethod();
        String methodName = method.getName();
        Set<String> classExitMethods = className2exitMethods.get(method.getDeclaringClass().toString());
        if (classExitMethods != null && classExitMethods.contains(methodName)) {
            return true;
        }
        return false;
    }


    private static boolean isOverrideMethod(Stmt s) {
        return getInvokeMethodNum(s) > 1;
    }

    public static int getInvokeMethodNum(Stmt s) {
        int num = 0;
        Iterator<Edge> iterator = Global.callGraph.edgesOutOf(s);
        while (iterator.hasNext()) {
            Edge edge = iterator.next();
            num++;
        }
        return num;
    }

    private static boolean isInstanceMethod(InvokeExpr invokeExpr) {
        SootMethod method = invokeExpr.getMethod();
        return method.getName().equals("isInstance")&& invokeExpr.getArgs().size() == 1;
    }

    private static void handleIsInstanceMethod(Value leftValue, InvokeExpr invokeExpr,
                                               DataflowAnalysis dataflowAnalysis) {
        List<Value> args = invokeExpr.getArgs();
        dataflowAnalysis.getInstanceOfMap().put(leftValue, args.get(0));
    }
    private static boolean isEmptyMethod(InvokeExpr invokeExpr) {
        SootMethod method = invokeExpr.getMethod();
        return method.getName().equals("isEmpty")&& invokeExpr.getArgs().size() == 1;
    }
    private static void handleIsEmptyMethod(Value leftValue, InvokeExpr invokeExpr, DataflowAnalysis dataflowAnalysis) {
        List<Value> args = invokeExpr.getArgs();
        dataflowAnalysis.getIsEmptyMap().put(leftValue, args.get(0));
    }
    private static boolean isAssertNotNullMethod(InvokeExpr invokeExpr) {
        SootMethod method = invokeExpr.getMethod();
        return method.getName().equals("assertNotNull")&& invokeExpr.getArgs().size() == 1;
    }
    private static void handleAssertNotNullMethod(InvokeExpr invokeExpr, VarStatusInfo out) {
        List<Value> args = invokeExpr.getArgs();
        out.setRawStatus(args.get(0), VarStatus.NON_NULL);
    }

    public static boolean tryHandleSpecialMethod(InvokeExpr invokeExpr, Value leftValue,
                                                 DataflowAnalysis dataflowAnalysis, VarStatusInfo out, Stmt s) {
        SootMethod method = invokeExpr.getMethod();
        if (isInstanceMethod(invokeExpr)) {
            handleIsInstanceMethod(leftValue, invokeExpr,dataflowAnalysis);
            return true;
        }
        if (isEmptyMethod(invokeExpr)) {
            handleIsEmptyMethod(leftValue, invokeExpr, dataflowAnalysis);
            return true;
        }
        if (isNonNullMethod(method)) {
            if (leftValue != null) out.setRawStatus(leftValue, VarStatus.NON_NULL);
            return true;
        }
        if (isAssertNotNullMethod(invokeExpr)) {
            handleAssertNotNullMethod(invokeExpr, out);
            return true;
        }
        if (isOverrideMethod(s)) {
            if (leftValue != null) out.setRawStatus(leftValue, NullnessConfig.SUBCLASS_METHOD_DEFAULT_RISK_LEVEL);
            return true;
        }
        return false;
    }
}
