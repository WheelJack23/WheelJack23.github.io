package edu.redundantcheck.analyses.analyzer;

import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.redundantcheck.analyses.result.CombineResult;
import edu.redundantcheck.analyses.RedundantAnalysis;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.redundantcheck.util.GlobalCleaner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import soot.Unit;
import soot.toolkits.graph.UnitGraph;

import java.util.*;

public class DfsAnalyzer extends Analyzer { // DFS steady-state traversal
    private static final Logger LOGGER = LoggerFactory.getLogger(DfsAnalyzer.class);
    private static final Map<Node, RedundantAnalysis> node2analysis = new HashMap<>();
    @Override
    public CombineResult analyzeNodes(List<Node> nodes) {
        GlobalCleaner.clean();
        node2analysis.clear();
        // 1. get root node
        List<Node> rootNodes = AnalyzerTool.getRootNodes(nodes);
        AnalyzerTool.unvisited(nodes);
        // 2. Starting from root, the steady state DFS traversal is performed on each node
        CombineResult result = new CombineResult();
        LOGGER.info("Start DFS Visit from root nodes, size: " + rootNodes.size());
        PercentageCounter pc = new PercentageCounter(rootNodes.size());
        for (Node root: rootNodes) {
            dfsVisit(root);
            pc.addCount();
            pc.logInfo();
        }
        // 3. Check for non-private method nodes that have not been visited and start traversing from them.
        List<Node> notVisitedNodes = DfsTool.getNotVisitedNodes(nodes);
        LOGGER.info("Start DFS Visit from nodes left, size: " + notVisitedNodes.size());
        PercentageCounter pcLeft = new PercentageCounter(notVisitedNodes.size());
        for (Node node: notVisitedNodes) {
            pcLeft.addCount();
            pcLeft.logInfo();
            if (node.isVisited) continue; // It turns out to be an unvisited node, but later it is marked by
            // another node, so there is no need to visit it again, because the steady state has been reached.
            dfsVisit(node);
        }

        LOGGER.info("Parameter conclusion reaches a steady state.");
        // 4. According to ParamConclusion, the analysis is carried out
        iterateNodes(result);
        LOGGER.info("Redundant check analysis completes!");
        return result;
    }

    public static void iterateNodes(CombineResult result) {
        LOGGER.info("Start to analyze result, size: " + node2analysis.size());
        PercentageCounter pc = new PercentageCounter(node2analysis.size());
        for (Node node: node2analysis.keySet()) {
            pc.addCount();
            pc.logInfo();
            RedundantAnalysis analysis = node2analysis.get(node);
            if (analysis == null) return;
            AnalyzerTool.addResult(analysis, node, result);
        }
    }

    private void dfsVisit(Node root) {
        root.isVisited = true;
        // 1. Obtain ParamConclusion to obtain the input state of the child node.
        ParamConclusion.BaseParamConclusion baseParamConclusion = ParamConclusion.getAndRetainConclusion(root);
        // 2. If the input status of the child node is updated, access the child node, otherwise stop access.
        UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromNode(root);
        if (unitGraph == null) return;
        RedundantAnalysis dataflowAnalysis = node2analysis.get(root);
        if (dataflowAnalysis == null) {
            dataflowAnalysis = new RedundantAnalysis(unitGraph, baseParamConclusion,
                    root.getMethod().getParameterCount(), root.getMethod().getDeclaringClass().getShortName());
            node2analysis.put(root, dataflowAnalysis);
        }
        else {
            dataflowAnalysis.redoAnalysis(baseParamConclusion);
        }
        // If no child node is called, return directly.
        List<UnitWrapperToNodePair> invokeStmtAndNodes = root.getUnitToNodePairList();
        if (invokeStmtAndNodes == null || invokeStmtAndNodes.size() == 0) return;
        // Update the Analysis of the child node
        Set<Unit> notReachableSet = dataflowAnalysis.getNotReachableSet();
        for (UnitWrapperToNodePair invokeStmtAndNode: invokeStmtAndNodes) {
            Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit; // Soot native unit.
            if (notReachableSet.contains(unit)) continue;
            boolean isUpdated = ParamConclusion.updateConclusion(invokeStmtAndNode, dataflowAnalysis);
            if (isUpdated) dfsVisit(invokeStmtAndNode.getToInvokedMethod());
        }
    }
}
