package edu.redundantcheck.analyses.reachable;

import soot.Unit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// a collection for unreachable units
public class NotReachableCollection {
    private List<Set<Unit>> unitSets = new ArrayList<>();
    public NotReachableCollection() {

    }
    public void clear() {
        unitSets.clear();
    }

    public void addNotReachable(Unit unit) {
        if (!contains(unit)) {
            Set<Unit> set = new HashSet<>();
            set.add(unit);
            unitSets.add(set);
        }
    }

    public void addNotReachableSuccessor(Unit successor, Unit parent) {
        for (Set<Unit> set: unitSets) {
            if (set.contains(parent)) {
                set.add(successor);
                return;
            }
        }
    }

    public Set<Unit> removeBlock(Unit unit) {
        Set<Unit> removeResult = null;
        for (Set<Unit> set: unitSets) {
            if (set.contains(unit)) {
                removeResult = set;
                break;
            }
        }
        if (removeResult != null) {
            unitSets.remove(removeResult);
            return removeResult;
        }
        return null;
    }

    public void removeUnit(Unit unit) {
        for (Set<Unit> set: unitSets) {
            if (set.contains(unit)) {
                set.remove(unit);
                return;
            }
        }
    }

    public boolean contains(Unit unit) {
        for (Set<Unit> set: unitSets) {
            if (set.contains(unit)) return true;
        }
        return false;
    }

    public Set<Unit> getNotReachableSet() {
        Set<Unit> set = new HashSet<>();
        for (Set<Unit> unitSet: unitSets) {
            set.addAll(unitSet);
        }
        return set;
    }
}
