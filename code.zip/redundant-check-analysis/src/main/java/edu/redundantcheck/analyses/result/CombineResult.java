package edu.redundantcheck.analyses.result;

import java.util.LinkedList;
import java.util.List;

// Result for redundant null check.
public class CombineResult {
    private List<ConditionBlock> certainReachableBlocks;
    private List<ConditionBlock> unreachableBlocks;

    public CombineResult() {
        this.certainReachableBlocks = new LinkedList<>();
        this.unreachableBlocks = new LinkedList<>();
    }

    public List<ConditionBlock> getCertainReachableBlocks() {
        return certainReachableBlocks;
    }

    public void setCertainReachableBlocks(List<ConditionBlock> certainReachableBlocks) {
        this.certainReachableBlocks = certainReachableBlocks;
    }

    public List<ConditionBlock> getUnreachableBlocks() {
        return unreachableBlocks;
    }

    public void setUnreachableBlocks(List<ConditionBlock> unreachableBlocks) {
        this.unreachableBlocks = unreachableBlocks;
    }
}
