package edu.redundantcheck.analyses.analyzer;

import edu.redundantcheck.analyses.result.CombineResult;
import edu.redundantcheck.analyses.RedundantAnalysis;
import edu.callgraph.impurity.bean.Node;
import edu.redundantcheck.util.GlobalCleaner;

import java.util.List;
import java.util.concurrent.*;

// traverse nodes in a topo order
public class TopoAnalyzer extends Analyzer {
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override
    public CombineResult analyzeNodes(List<Node> nodeList) {
        GlobalCleaner.clean();
        CombineResult result = new CombineResult();
        GraphIterator graphIterator = new GraphIterator(nodeList);
        while (graphIterator.hasNext()) {
            Node node = graphIterator.next();
            System.out.println("start to analyze " + node.getMethodSignatureFull());
            RedundantAnalysis analysis = execute(node, result);

            if (analysis != null) AnalyzerTool.updateCalleeParamConclusion(node, analysis);
        }
        executor.shutdown();
        return result;
    }

    private RedundantAnalysis execute(Node node, CombineResult result) {
        Task task = new Task(node, result);
        Future<RedundantAnalysis> future = executor.submit(task);
        try {
            return future.get(30, TimeUnit.SECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            // task will be cancelled in finally block
        } finally {
            future.cancel(true);
        }
        return null;
    }

    private class Task implements Callable<RedundantAnalysis> {
        private Node node;
        private CombineResult result;

        public Task(Node node, CombineResult result) {
            this.node = node;
            this.result = result;
        }
        @Override
        public RedundantAnalysis call() throws Exception {
            return AnalyzerTool.analyzeNode(node, result);
        }
    }
}
