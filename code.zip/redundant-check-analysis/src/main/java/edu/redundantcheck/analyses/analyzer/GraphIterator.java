package edu.redundantcheck.analyses.analyzer;

import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.callgraph.global.Global;
import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

// Performs topological sorting and traverses through the topological order
public class GraphIterator implements Iterator<Node> {
    private static Logger LOGGER = LoggerFactory.getLogger(GraphIterator.class);
    private List<Node> sortedNodes;
    private int currentPos = 0;
    public GraphIterator(List<Node> nodes) {
        if (!NullnessConfig.SHOW_UNLOOP_DETAIL) {
            LOGGER.info("set NullnessConfig.SHOW_UNLOOP_DETAIL to show unloop entry details.");
        }
        // Collect the root node of the tree and unloop it
        List<Node> rootNodes = AnalyzerTool.getRootNodes(nodes);
        unloop(rootNodes);

        // Recalculate the input degree and sort it
        Map<Node, Integer> indegrees = AnalyzerTool.getIndegrees(nodes);
        rootNodes = AnalyzerTool.getRootNodes(nodes);
        Queue<Node> queue = new LinkedList<>(rootNodes);
        sortedNodes = new ArrayList<>();
        topoAdd(indegrees, queue);

        while (indegrees.size() > 0) {
            List<Node> nodeList = new ArrayList<>(indegrees.keySet());
            nodeList.sort(Comparator.comparing(Node::getMethodSignatureFull));// sorting
            Node tmpRoot = getMinInDegreePublicNode(indegrees, nodeList);
            if (tmpRoot == null) tmpRoot = getMinInDegreeProtectedNode(indegrees, nodeList);
            if (tmpRoot == null) break; // All are private nodes.
            indegrees.put(tmpRoot, 0);
            ParamConclusion.setConclusionUnknown(tmpRoot, NullnessConfig.getLoopEntryDefaultRisk());
            queue.add(tmpRoot);
            topoAdd(indegrees, queue);
        }
        LOGGER.info("Topological sorting finished.");
    }

    private Node getMinInDegreePublicNode(Map<Node, Integer> indegrees, List<Node> nodeList) {
        Node tmpRoot = null;
        int minIndegree = Integer.MAX_VALUE;// Take any node with the smallest degree as the new Root
        for (Node node: nodeList) {
            int indegree = indegrees.getOrDefault(node, 0);
            if (indegree < minIndegree && node.getMethod().isPublic() && inLoop(node)) {// Node should be non-private
                minIndegree = indegree;
                tmpRoot = node;
            }
        }
        return tmpRoot;
    }

    private boolean inLoop(Node node) {
        AnalyzerTool.unvisited(Global.nodeSet);
        Queue<Node> queue = new LinkedList<>();
        queue.add(node);
        while (!queue.isEmpty()) {
            Node tmp = queue.poll();
            tmp.isVisited = true;
            List<AbstractNode> children = tmp.getChildren();
            if (children == null || children.size() == 0) {
                continue;
            }
            for (AbstractNode child: children) {
                if (child == node) return true;
                if (!child.isVisited) queue.add((Node) child);
            }
        }
        return false;
    }

    private Node getMinInDegreeProtectedNode(Map<Node, Integer> indegrees, List<Node> nodeList) {
        Node tmpRoot = null;
        int minIndegree = Integer.MAX_VALUE;
        for (Node node: nodeList) {
            int indegree = indegrees.getOrDefault(node, 0);
            if (indegree < minIndegree && node.getMethod().isProtected() && inLoop(node)) {
                minIndegree = indegree;
                tmpRoot = node;
            }
        }
        return tmpRoot;
    }

    private void topoAdd(Map<Node, Integer> indegrees, Queue<Node> queue) {// Nodes are added in topological order
        // The traversal starts from the node whose indegree is 0 and updates the indegree of the next node
        while (!queue.isEmpty()) {
            Node parent = queue.poll();
            sortedNodes.add(parent);
            indegrees.remove(parent);
            // Update the input degree of the next node
            if (parent.getChildren() == null) continue;
            for (AbstractNode child: parent.getChildren()) {
                Node c = (Node) child;
                Integer indegree = indegrees.getOrDefault(c, 0) - 1;
                if (indegree == -1) { // Note points to the original root node
                    continue;
                }
                indegrees.put(c, indegree);
                if (indegree == 0) {
                    queue.add(c);
                }
            }
        }
    }

    // Unloop based on the root node
    // If a loop is found, remove the edge and set the calling context to UNKNOWN for the entry of the loop
    private void unloop(List<Node> rootNodes) {
        for (Node rootNode: rootNodes) {
            dfs(rootNode, new HashMap<>());
        }
    }

    // Perform depth-first traversal and unloop operations
    private void dfs(Node rootNode, Map<Node, Color> colorMap) {
        // The current node is gray
        colorMap.put(rootNode, Color.GRAY);
        List<AbstractNode> children = rootNode.getChildren();
        if (children == null || children.size() == 0) {
            colorMap.put(rootNode, Color.BLACK);
            return;
        }
        List<Node> removeNodes = new LinkedList<>();
        for (AbstractNode abstractNode: children) {
            Node child = (Node) abstractNode;
            Color childColor = colorMap.get(child);
            if (childColor == null || childColor == Color.WHITE) {// could visit
                dfs(child, colorMap);
            }
            else if (childColor == Color.GRAY) { // find loop
                removeNodes.add(child); // unloop
                ParamConclusion.setConclusionUnknown(child, NullnessConfig.getLoopEntryDefaultRisk()); // set UNKNOWN
            }
            // else color is black, no need to visit.
        }
        children.removeAll(removeNodes);// unloop
        colorMap.put(rootNode, Color.BLACK); // finish visit.
    }

    private enum Color{
        WHITE, GRAY, BLACK; // white, not visited; gray, visiting; black, visited.
    }

    @Override
    public boolean hasNext() {
        return currentPos < sortedNodes.size();
    }

    @Override
    public Node next() {
        return sortedNodes.get(currentPos++);
    }
}
