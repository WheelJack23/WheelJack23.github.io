package edu.redundantcheck.analyses;

import edu.redundantcheck.analyses.analyzer.Analyzer;
import edu.redundantcheck.analyses.analyzer.TopoAnalyzer;
import edu.redundantcheck.analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;
import edu.redundantcheck.util.CallGraphUtil;
import edu.redundantcheck.util.Class2PathUtils;
import soot.SootMethod;

import java.util.*;

// analyzing process for redundant null checks.
public class RedundantAnalyzer {
    public static CombineResult analyze(String inputJarPath, String[] methodNames, String inputSrcPath) {
        Class2PathUtils.initData(inputSrcPath);
        List<Node> nodeList = CallGraphUtil.generateCallGraph(inputJarPath, methodNames);
        return analyzeNodes(nodeList);
    }
    public static CombineResult analyzeSingleWar(String inputWarPath, String[] methodNames, String inputSrcPath) {
        Class2PathUtils.initData(inputSrcPath);
        List<Node> nodeList = CallGraphUtil.generateCallGraphForSingleWar(inputWarPath, methodNames);
        return analyzeNodes(nodeList);
    }
    public static CombineResult analyzeMultiModule(String projectPath, String[] methodNames) {
        Class2PathUtils.initData(projectPath);
        List<Node> nodeList = CallGraphUtil.generateCallGraphForMultiModule(projectPath, methodNames);
        return analyzeNodes(nodeList);
    }

    public static CombineResult analyzeMultiModule(String projectPath, String[] methodNames, Analyzer analyzer) {
        Class2PathUtils.initData(projectPath);
        List<Node> nodeList = CallGraphUtil.generateCallGraphForMultiModule(projectPath, methodNames);
        return analyzer.analyzeNodes(nodeList);
    }
    private static CombineResult analyzeNodes(List<Node> nodeList) {
        Analyzer analyzer = new TopoAnalyzer();
//        DfsAnalyzer analyzer = new DfsAnalyzer();
        return analyzer.analyzeNodes(nodeList);
    }

    private static boolean lineNoBelowOrEq(int lineA, int lineB) {
        return lineA >= lineB;
    }

    public static String generatePathFromClassName(SootMethod method) {
        String declaringClass = method.getDeclaringClass().getName();
        return Class2PathUtils.getPath(declaringClass);
    }


}
