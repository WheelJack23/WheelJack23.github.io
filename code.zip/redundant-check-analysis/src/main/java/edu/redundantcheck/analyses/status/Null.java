package edu.redundantcheck.analyses.status;

import java.util.ArrayList;
import java.util.List;

// Null information includes where it is generated and the traces about where it is passed and returned.
public class Null extends VarStatus{
    private String declaringClass;
    private int lineNo;

    private NullType nullType;

    private List<Trace> traces;

    public Null(String declaringClass, int lineNo) {
        super();
        this.declaringClass = declaringClass;
        this.lineNo = lineNo;
        this.nullStatus = Status.NULL;
        this.field2status = null;
        this.isConstant = true;
        this.nullType = NullType.FROM_ASSIGN;
    }
    public Null(String declaringClass, int lineNo, NullType type) {
        super();
        this.declaringClass = declaringClass;
        this.lineNo = lineNo;
        this.nullStatus = Status.NULL;
        this.field2status = null;
        this.isConstant = true;
        this.nullType = type;
    }

    public Null hardCopy() {
        Null nullValue = new Null(declaringClass, lineNo, nullType);
        if (traces != null) nullValue.traces = new ArrayList<>(traces);
        return nullValue;
    }

    public int getLineNo() {
        return lineNo;
    }

    public String getDeclaringClass() {
        return declaringClass;
    }

    public NullType getNullType() {
        return nullType;
    }

    public void setNullType(NullType nullType) {
        this.nullType = nullType;
    }

    // copy on write
    public Null appendTrace(Trace trace) {
        Null nullValue = new Null(declaringClass, lineNo, nullType);
        nullValue.traces = new ArrayList<>();
        if (traces != null) {
            nullValue.traces.addAll(traces);
        }
        nullValue.traces.add(trace);
        return nullValue;
    }

    @Override
    public String toString() {
        return "{" +
                "declaringClass='" + declaringClass + '\'' +
                ", lineNo=" + lineNo +
                ", type=" + nullType +
                ",traces=" + (traces == null?"none":traces.toString()) +
                '}';
    }
    public static class Trace {
        public static final String RETURN = "RETURN_FROM";
        public static final String PASS = "PASS_AT";
        private String declaringClass;
        private int lineNo;
        private String type;
        public Trace(String type, String declaringClass, int lineNo) {
            this.declaringClass = declaringClass;
            this.type = type;
            this.lineNo = lineNo;
        }

        public String getDeclaringClass() {
            return declaringClass;
        }

        public int getLineNo() {
            return lineNo;
        }

        public String getType() {
            return type;
        }

        @Override
        public String toString() {
            return type + "_" + declaringClass + "_" + lineNo;
        }
    }

    public enum NullType {
        FROM_ASSIGN("FROM_ASSIGN", 1), FROM_NULL_CHECK("FROM_NULL_CHECK", 3),
        FROM_ANNOTATION("FROM_ANNOTATION",4),
        FROM_RETURN("FROM_RETURN", 2);
        private String typeString;
        private int rank;
        NullType(String typeString, int rank) {
            this.typeString = typeString;
            this.rank = rank;
        }

        @Override
        public String toString() {
            return typeString;
        }

        public static Null merge(Null n1, Null n2) {
            if (n1.nullType.rank < n2.nullType.rank) return n1;
            return n2;
        }
    }
}
