package edu.redundantcheck.analyses.nullness;

import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.InvocationAnalysis;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.UnknownHighRisk;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.util.MethodUtils;
import soot.*;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;

import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

import static edu.redundantcheck.analyses.nullness.InvokeMethodUtil.tryHandleSpecialMethod;
import static edu.redundantcheck.analyses.nullness.InvokeMethodUtil.isExitMethod;

// handle invocation
public class InvokeExprHandler {
    public static Map<String, Set<String>> getClassName2methods(InputStream inputStream) {
        List<String> lines = getLines(inputStream);
        Map<String, Set<String>> class2Sets = new HashMap<>();
        for (String line : lines) {
            String[] lineParts = line.split(":");
            String className = lineParts[0];
            if (className.equals("*")) continue;
            String method = lineParts[1];
            if (!class2Sets.containsKey(className)) class2Sets.put(className, new HashSet<>());
            class2Sets.get(className).add(method);
        }
        return class2Sets;
    }

    public static Set<String> getMethods(InputStream inputStream) {
        List<String> lines = getLines(inputStream);
        Set<String> set = new HashSet<>();
        for (String line : lines) {
            String[] lineParts = line.split(":");
            String className = lineParts[0];
            if (className.equals("*")) set.add(lineParts[1].trim());
        }
        return set;
    }

    private static List<String> getLines(InputStream inputStream) {
        List<String> lines = new LinkedList<>();
        Scanner input = new Scanner(inputStream);
        while (input.hasNext()) {
            String line = input.nextLine().trim();
            if (!line.isEmpty()) lines.add(line);
        }
        return lines;
    }


    public static void setBaseNonNull(InvokeExpr invokeExpr, VarStatusInfo out,
                                      DataflowAnalysis analysisInfo) {
        if (invokeExpr instanceof InstanceInvokeExpr) {
            out.setNonNull(getInvokeBase(invokeExpr), analysisInfo);
        }
    }

    private static Value getInvokeBase(InvokeExpr invokeExpr) {
        if (invokeExpr instanceof InstanceInvokeExpr) {
            InstanceInvokeExpr instanceInvokeExpr = (InstanceInvokeExpr) invokeExpr;
            return instanceInvokeExpr.getBase();
        }
        return null;
    }

    private static Value getLeftValue(Stmt s) {
        List<ValueBox> leftValueBoxes = s.getDefBoxes();
        List<Value> leftValues = leftValueBoxes.stream().map(ValueBox::getValue).collect(Collectors.toList());
        if (leftValues.size() == 1) return leftValues.get(0);
        return null;
    }

    public static void handle(Stmt s, VarStatusInfo out, int returnDepth, DataflowAnalysis dataflowAnalysis) {
        InvokeExpr invokeExpr = s.getInvokeExpr();
        if (isExitMethod(invokeExpr)) {// will be handled by Reachable Util.
            dataflowAnalysis.currentStmtContainsDeadInvocation = true;
            return;
        }
        setBaseNonNull(invokeExpr, out, dataflowAnalysis);
        handleReturn(invokeExpr, out, s, returnDepth, dataflowAnalysis);
    }

    public static void handleReturn(InvokeExpr invokeExpr, VarStatusInfo out, Stmt s,
                                    int returnDepth, DataflowAnalysis dataflowAnalysis) {
        Value leftValue = getLeftValue(s);
        Value base = getInvokeBase(invokeExpr);
        SootMethod method = invokeExpr.getMethod();
        if (tryHandleSpecialMethod(invokeExpr, leftValue, dataflowAnalysis, out, s)) return;
        UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromMethod(method);
        if (returnDepth == 0 || unitGraph == null) { // returnDepth == 0, stop invocation analysis.
            List<Value> arguments = invokeExpr.getArgs();
            InvokeHelper.stopInvocationAnalysis(leftValue, out, method, base, arguments);
            return;
        }
        int lineNo = s.getJavaSourceStartLineNumber();
        setStatusAfterReturn(out, leftValue, base, invokeExpr, returnDepth, method, dataflowAnalysis, lineNo);
    }

    private static void setStatusAfterReturn(VarStatusInfo out, Value leftValue, Value base,
                                             InvokeExpr invokeExpr, int returnDepth, SootMethod method,
                                             DataflowAnalysis dataflowAnalysis, int lineNo) {
        List<Value> arguments = invokeExpr.getArgs();
        BaseArgsStatus baseArgsClone = getBaseArgsClone(base, out, method,
                dataflowAnalysis.declaringClass, lineNo, arguments);
        VarStatus baseStatusClone = baseArgsClone.base;
        List<VarStatus> argStatusList = baseArgsClone.argStatusList;
        InvocationAnalysis invocationAnalysis =
                    runInvocationAnalysis(method, argStatusList, returnDepth, baseStatusClone);
        if (invocationAnalysis.isDeadInvocation()) {
            dataflowAnalysis.currentStmtContainsDeadInvocation = true;
            return;
        }
        Null.Trace trace = new Null.Trace(Null.Trace.RETURN, dataflowAnalysis.declaringClass, lineNo);
        invocationAnalysis.appendTraceToReturn(trace);
        setBaseStatusAfterInvocation(base, out, invocationAnalysis);
        setArgsStatus(arguments, out, invocationAnalysis.getArgumentsReturn(), dataflowAnalysis, lineNo);
        // note: left value should be set last because replacement of status could happens.
        setLeftStatusAfterInvocation(invocationAnalysis, method, leftValue, out);
    }

    private static void setArgsStatus(List<Value> arguments, VarStatusInfo out, List<VarStatus> argsStatusReturn,
                                      DataflowAnalysis dataflowAnalysis, int lineNo) {
        Null nullValue = new Null(dataflowAnalysis.declaringClass, lineNo);
        for (int i = 0 ; i < arguments.size();i++) {
            VarStatus newStatus = argsStatusReturn.get(i);
            // if no information provided, simply make no changes.
            if (newStatus == VarStatus.UNKNOWN_DEFAULT) continue;
            Value val = arguments.get(i);
            VarStatus originStatus = out.getStatus(val, nullValue);
            if (VarStatus.isNonNull(originStatus)
                    && VarStatus.isNonNull(newStatus)) {
                if (VarStatus.isConstants(originStatus)) {
                    out.setRawStatus(val, newStatus);
                }
                else {// instance status
                    originStatus.replaceField(newStatus);
                }

            }
            else if (VarStatus.isUnknownRisky(originStatus)) {
                if (VarStatus.isConstants(originStatus)) {
                    out.setRawStatus(val, newStatus);
                }
                else {
                    out.replace(originStatus, newStatus);
                }
            }
            // else (originStatus.isNull()) continue;
        }
    }

    private static void setLeftStatusAfterInvocation(InvocationAnalysis invocationAnalysis,
                                                     SootMethod method,
                                                     Value leftValue, VarStatusInfo out) {
        if (leftValue != null) {
            VarStatus actualReturnStatus = invocationAnalysis.getReturnStatus();
            // Trust Annotation.
            MethodInfo.ParamStatus annotatedReturnStatus = MethodInfo.getAnnotatedReturnStatus(method);
            if (annotatedReturnStatus != MethodInfo.ParamStatus.None) {
                if (annotatedReturnStatus == MethodInfo.ParamStatus.NonNull) {
                    if (VarStatus.isUnknownRisky(actualReturnStatus) &&
                            !actualReturnStatus.isUnknownHighRisk()) {
                        // if method annotation is NonNull and unknown status is not high risk.
                        // set leftValue status NON_NULL.
                        if (VarStatus.isConstants(actualReturnStatus)) {
                            out.setRawStatus(leftValue, VarStatus.NON_NULL);
                        }
                        else {// instance
                            VarStatus nonNullInstance = VarStatus.getNonNullInstance();
                            out.setRawStatus(leftValue, nonNullInstance);
                            out.replace(actualReturnStatus, nonNullInstance);
                        }
                        return;
                    }
                }
                if (annotatedReturnStatus == MethodInfo.ParamStatus.Nullable) {
                    // make sure if return unknown, unknown should be high risk.
                    if (VarStatus.isUnknownRisky(actualReturnStatus)
                            && !actualReturnStatus.isHighestRiskStatus()) {
                        if (VarStatus.isConstants(actualReturnStatus)) {
                            out.setRawStatus(leftValue, VarStatus.UNKNOWN_HIGH_RISK);
                        }
                        else {
                            Null nullStatus = new Null(method.getDeclaringClass().getShortName(),
                                    -1, Null.NullType.FROM_ANNOTATION);
                            VarStatus unknownHigh = UnknownHighRisk.getInstance(nullStatus);
                            out.setRawStatus(leftValue, unknownHigh);
                            out.replace(actualReturnStatus, unknownHigh);
                        }
                        return;
                    }
                }
            }
            out.setCloneStatus(leftValue, actualReturnStatus);
        }
    }

    private static void setBaseStatusAfterInvocation(Value base, VarStatusInfo out,
                                                     InvocationAnalysis invocationAnalysis) {
        if (base != null) {
            VarStatus baseStatus = out.getStatus(base, VarStatus.NULL);
            VarStatus baseStatusBeforeReturn = invocationAnalysis.getBaseStatusReturn();
            if (VarStatus.isConstants(baseStatus) || VarStatus.isConstants(baseStatusBeforeReturn)) {
                out.setRawStatus(base, baseStatusBeforeReturn);
            } else {
                baseStatus.replaceField(baseStatusBeforeReturn);
            }
        }
    }

    private static InvocationAnalysis runInvocationAnalysis(SootMethod method, List<VarStatus> argStatusList,
                                                            int returnDepth, VarStatus baseStatusClone) {
        UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromMethod(method);
        return new InvocationAnalysis(unitGraph,
                argStatusList, returnDepth - 1, baseStatusClone,
                MethodUtils.getMethodSignature(method), method.getDeclaringClass().getShortName());
    }

    private static BaseArgsStatus getBaseArgsClone(Value base, VarStatusInfo out,
                                                   SootMethod method, String declaringClass, int lineNo,
                                                   List<Value> arguments) {
        BaseArgsStatus baseArgsClone = new BaseArgsStatus();
        VarStatus baseStatusClone = null;
        VarStatus.cleanCloneMergeInfo();
        if (base != null) {
            VarStatus baseStatus = out.getStatus(base, VarStatus.NULL);
            baseStatusClone = baseStatus.cloneStatusWithNegativeParamIdx();
        }
        baseArgsClone.base = baseStatusClone;

        List<VarStatus> argsStatus = new ArrayList<>();
        for (int i = 0 ; i < arguments.size(); i++) {
            Value v = arguments.get(i);
            VarStatus status = out.getStatus(v,lineNo, declaringClass).cloneStatusWithNegativeParamIdx();
            if (VarStatus.isUnknownRisky(status)) {
                if (VarStatus.isConstants(status)) {
                    status = VarStatus.getUnknownInstance(status);
                }
                status.setParamIdx(i);
            }
            else if (VarStatus.isNonNull(status)) {
                if (VarStatus.isConstants(status)) {
                    status = VarStatus.getNonNullInstance();
                }
                status.setParamIdx(i);
            }
            else if (status.isNull()) {
                status = ((Null)status).hardCopy();
                status.setParamIdx(-1);
            }
            argsStatus.add(status);
        }
        VarStatus.cleanCloneMergeInfo();
        baseArgsClone.argStatusList = argsStatus;
        return baseArgsClone;
    }

    private static class BaseArgsStatus {
        private VarStatus base;
        private List<VarStatus> argStatusList;

        public VarStatus getBase() {
            return base;
        }

        public void setBase(VarStatus base) {
            this.base = base;
        }

        public List<VarStatus> getArgStatusList() {
            return argStatusList;
        }

        public void setArgStatusList(List<VarStatus> argStatusList) {
            this.argStatusList = argStatusList;
        }
    }

}
