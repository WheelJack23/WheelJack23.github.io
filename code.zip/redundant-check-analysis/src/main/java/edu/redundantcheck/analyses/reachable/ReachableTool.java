package edu.redundantcheck.analyses.reachable;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.nullness.InvokeMethodUtil;
import soot.Local;
import soot.Unit;
import soot.Value;
import soot.jimple.*;
import soot.jimple.internal.*;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;

import java.util.List;
import java.util.Set;

// apply reachable analysis here
public class ReachableTool {
    private static Set<Unit> reachableSet;
    private static Set<Unit> certainReachableSet;
    private static NotReachableCollection notReachableCollection;
    private static Stmt currentStmt;
    private static List<VarStatusInfo> fallOutInfos;
    private static List<VarStatusInfo> branchOutInfos;
    public static void analyzeReachable(Stmt stmt, UnitGraph unitGraph, VarStatusInfo in, DataflowAnalysis analysis,
                                        List<VarStatusInfo> fallOuts, List<VarStatusInfo> branchOuts) {
        reachableSet = analysis.getReachableSet();
        certainReachableSet = analysis.getCertainReachableSet();
        notReachableCollection = analysis.getNotReachableCollection();
        fallOutInfos = fallOuts;
        branchOutInfos = branchOuts;
        currentStmt = stmt;

        Chain<Unit> sl = unitGraph.getBody().getUnits();
        Unit successorUnit = (Unit)sl.getSuccOf(stmt);
        if (stmt instanceof JIfStmt) {
            JIfStmt ifStmt = (JIfStmt) stmt;
            analyzeReachableIfStmt(ifStmt, in, successorUnit);
        }
        else if (stmt instanceof GotoStmt) {
            GotoStmt gotoStmt = (GotoStmt) stmt;
            analyzeReachableGotoStmt(gotoStmt, successorUnit);
        }
        else if (stmt instanceof ReturnStmt || stmt instanceof ReturnVoidStmt) {
            addNotReachableUnit(successorUnit);
        }
        else if (analysis.currentStmtContainsDeadInvocation ||
                (stmt.containsInvokeExpr() && InvokeMethodUtil.isExitMethod(stmt.getInvokeExpr()))) {
            setNotReachableSuccessor(successorUnit);
            return;
        }
        else if (stmt instanceof JLookupSwitchStmt || stmt instanceof TableSwitchStmt) {
            List<Unit> switchSuccessors = ((ExceptionalUnitGraph)unitGraph).getUnexceptionalSuccsOf(stmt);
            if (!notReachableCollection.contains(stmt)) {
                for (Unit unit: switchSuccessors) addReachableUnit(unit);
            } else {
                for (Unit unit: switchSuccessors) addNotReachableSuccessor(unit, stmt);
            }
        }
        else if (isSequentialStmt(stmt)) {
            if (notReachableCollection.contains(stmt)) {
                addNotReachableSuccessor(successorUnit, stmt);
            }
            else {
                addReachableUnit(successorUnit);
            }
        }
        else if (stmt instanceof ThrowStmt) {
            addNotReachableUnit(successorUnit);
        }
        else {
            if (notReachableCollection.contains(stmt)) {
                addNotReachableSuccessor(successorUnit, stmt);
            }
            else {
                addReachableUnit(successorUnit);
            }
        }

        List<Unit> exceptionSuccessor = ((ExceptionalUnitGraph)unitGraph).getExceptionalSuccsOf(stmt);
        if (!notReachableCollection.contains(stmt)) {
            for (Unit unit: exceptionSuccessor) addReachableUnit(unit);
        }
        else {
            for (Unit unit: exceptionSuccessor) {
                addNotReachableSuccessor(unit, stmt);
            }
        }
    }

    private static boolean isSequentialStmt(Stmt stmt) {
        if (stmt == null) return true;
        return stmt instanceof DefinitionStmt || stmt instanceof JInvokeStmt || stmt instanceof NopStmt || stmt instanceof MonitorStmt;
    }

    private static void analyzeReachableGotoStmt(GotoStmt gotoStmt, Unit successor) {
        Unit target = gotoStmt.getTarget();
        addNotReachableUnit(successor);
        if (notReachableCollection.contains(gotoStmt)) {
            addNotReachableSuccessor(target, gotoStmt);
        }
        else {
            addReachableUnit(target);
        }
    }


    private static void analyzeReachableIfStmt(JIfStmt ifStmt, VarStatusInfo in, Unit successor) {
        Unit target = ifStmt.getTarget();
        if (notReachableCollection.contains(ifStmt)) {
            addNotReachableSuccessor(target, ifStmt);
            addNotReachableSuccessor(successor, ifStmt);
            return;
        }
        Value condition = ifStmt.getCondition();
        if (condition instanceof JEqExpr || condition instanceof JNeExpr) {
            // a==b or a!=b
            AbstractBinopExpr eqExpr = (AbstractBinopExpr) condition;
            analyzeReachableEqNeq(eqExpr, target, successor, in);
        }
        else {
            setReachableTarget(target);
            setReachableSuccessor(successor);

        }
    }

    private static void analyzeReachableEqNeq(AbstractBinopExpr eqExpr,
                                              Unit target, Unit successor,
                                              VarStatusInfo in) {
        ConditionStatus conditionStatus = evalCondition(eqExpr, in);
        if (conditionStatus == ConditionStatus.TRUE) {
            setNotReachableSuccessor(successor);
            setCertainReachableTarget(target);
        }
        else if (conditionStatus == ConditionStatus.FALSE) {
            setNotReachableTarget(target);
            setCertainReachableSuccessor(successor);
        }
        else {
            setReachableTarget(target);
            setReachableSuccessor(successor);
        }
    }

    private static void setNotReachableSuccessor(Unit successor) {
        setFallOutDead();
        addNotReachableUnit(successor);
    }

    private static void setNotReachableTarget(Unit target) {
        setBranchOutDead();
        addNotReachableUnit(target);
    }

    private static void setCertainReachableTarget(Unit target) {
        setBranchOutAlive();
        addCertainReachable(target);
    }

    private static void setCertainReachableSuccessor(Unit successor) {
        setFallOutAlive();
        addCertainReachable(successor);
    }

    private static void setReachableTarget(Unit target) {
        setBranchOutAlive();
        addReachableUnit(target);
    }

    private static void setReachableSuccessor(Unit successor) {
        setFallOutAlive();
        addReachableUnit(successor);
    }

    private static void setBranchOutDead() {
        setAliveness(branchOutInfos, false);
    }

    private static void setFallOutAlive() {
        setAliveness(fallOutInfos, true);
    }
    private static void setFallOutDead() {
        setAliveness(fallOutInfos, false);
    }


    private static void setBranchOutAlive() {
        setAliveness(branchOutInfos, true);
    }
    private static void setAliveness(List<VarStatusInfo> infos, boolean aliveness) {
        for (VarStatusInfo info: infos) info.setAlive(aliveness);
    }

    private static ConditionStatus evalCondition(AbstractBinopExpr eqExpr,
                                                 VarStatusInfo in) {
        Value left = eqExpr.getOp1();
        Value right = eqExpr.getOp2();

        if (left == NullConstant.v() && right == NullConstant.v()) {
            return eqExpr instanceof JEqExpr ? ConditionStatus.TRUE:ConditionStatus.FALSE;
        }

        Value val = null;
        if (left == NullConstant.v()) {
            if (right != NullConstant.v()) {
                val = right;
            }
        } else if (right == NullConstant.v()) {
            if (left != NullConstant.v()) {
                val = left;
            }
        }
        if (val == null || !(val instanceof Local)) return ConditionStatus.UNKNOWN;

        VarStatus status = in.getStatus(val, VarStatus.NULL);
        if (VarStatus.isUnknownRisky(status)
                || status == VarStatus.UNKNOWN_DEFAULT)
            return ConditionStatus.UNKNOWN;
        if (VarStatus.isNonNull(status)) {
            return eqExpr instanceof JEqExpr? ConditionStatus.FALSE: ConditionStatus.TRUE;
        }
        if (status.isNull()) {
            return eqExpr instanceof JEqExpr? ConditionStatus.TRUE:ConditionStatus.FALSE;
        }
        return null;
    }

    public enum ConditionStatus {
        TRUE, FALSE, UNKNOWN
    }

    private static void addReachableUnit(Unit unit) {
        if (unit == null) return;
        if (notReachableCollection.contains(unit)) {
            if (currentStmt instanceof IfStmt) {
                Set<Unit> set = notReachableCollection.removeBlock(unit);
                reachableSet.add(unit);
            }
            else {
                notReachableCollection.removeUnit(unit);
                reachableSet.add(unit);
            }
        }
        else if (certainReachableSet.contains(unit)) {
            if (currentStmt instanceof IfStmt) {
                certainReachableSet.remove(unit);
                reachableSet.add(unit);
            }
            else {
            }
        }
        else if (reachableSet.contains(unit))
            return;
        else {
            reachableSet.add(unit);
        }
    }

    private static void addNotReachableUnit(Unit unit) {
        if (unit == null) return;
        if (notReachableCollection.contains(unit)) {
            return;
        }
        else if (certainReachableSet.contains(unit)) {
            if (currentStmt instanceof IfStmt) {
                certainReachableSet.remove(unit);
                reachableSet.add(unit);
            }
            else {
            }
        }
        else if (reachableSet.contains(unit)) {
            return;
        }
        else {
            notReachableCollection.addNotReachable(unit);
        }
    }

    private static void addNotReachableSuccessor(Unit successor, Unit parent) {
        if (successor == null) return;
        if (notReachableCollection.contains(successor)) {
            return;
        }
        else if (certainReachableSet.contains(successor)) {
            if (currentStmt instanceof IfStmt) {
                certainReachableSet.remove(successor);
                reachableSet.add(successor);
            }
            else {
            }
        }
        else if (reachableSet.contains(successor)) {
            return;
        }
        else {
            notReachableCollection.addNotReachableSuccessor(successor, parent);
        }
    }

    private static void addCertainReachable(Unit unit) {
        if (unit == null) return;
        if (notReachableCollection.contains(unit)) {
            Set<Unit> set = notReachableCollection.removeBlock(unit);
            reachableSet.addAll(set);
        }
        else if (certainReachableSet.contains(unit)) {
            return;
        }
        else if (reachableSet.contains(unit)) {
            return;
        }
        else {
            certainReachableSet.add(unit);
        }
    }
}
