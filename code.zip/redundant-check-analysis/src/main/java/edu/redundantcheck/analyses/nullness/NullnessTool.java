package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.jimple.*;
import soot.jimple.internal.JIfStmt;

import java.util.List;

// apply transfer function here.
public class NullnessTool {
    public static void flowThrough(Stmt s, VarStatusInfo in,
                                   List<VarStatusInfo> fallOut, List<VarStatusInfo> branchOuts,
                                   int returnDepth, DataflowAnalysis analysisInfo) {
        VarStatusInfo out = in.cloneInfo();
        VarStatusInfo outBranch = in.cloneInfo();

        if (s instanceof JIfStmt) {
            JIfStmt ifStmt = (JIfStmt) s;
            IfStmtHandler.handle(ifStmt, out, outBranch, analysisInfo);
        }
        // in case of a monitor statement, we know that if it succeeds, we have a non-null value
        else if (s instanceof MonitorStmt) {
            MonitorStmt monitorStmt = (MonitorStmt) s;
            MonitorStmtHandler.handle(monitorStmt, out, analysisInfo);
        }

        // if we have an array ref, set the base to non-null
        if (s.containsArrayRef()) {
            ArrayRef arrayRef = s.getArrayRef();
            ArrayRefHandler.handle(arrayRef, out, analysisInfo);
        }
        // for field refs, set the receiver object to non-null, if there is one
        if (s.containsFieldRef()) {
            FieldRef fieldRef = s.getFieldRef();
            FieldRefHandler.handle(fieldRef, out, analysisInfo);
        }
        // for invoke expr, set the receiver object to non-null, if there is one
        if (s.containsInvokeExpr()) {
            InvokeExprHandler.handle(s, out,returnDepth,analysisInfo);
        }else if (s instanceof DefinitionStmt) {
            DefinitionStmt defStmt = (DefinitionStmt) s;
            DefinitionStmtHandler.handle(defStmt, out, analysisInfo);
        }

        // now copy the computed info to all successors
        for (VarStatusInfo varStatusInfo : fallOut) {
            copy(out, varStatusInfo);
        }
        for (VarStatusInfo branchOut : branchOuts) {
            copy(outBranch, branchOut);
        }
    }

    protected static void copy(VarStatusInfo s, VarStatusInfo d) {
        d.clear();
        d.copy(s);
    }
}
