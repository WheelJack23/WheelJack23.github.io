package edu.redundantcheck.analyses;

import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.nullness.NullnessTool;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.reachable.ReachableTool;
import soot.Unit;
import soot.jimple.Stmt;
import soot.toolkits.graph.UnitGraph;

import java.util.*;

// Intra-procedural analysis for redundant null checks.
public class RedundantAnalysis extends DataflowAnalysis {
    public RedundantAnalysis(UnitGraph graph, ParamConclusion.BaseParamConclusion baseParamConclusion,
                             int paramCount, String declaringClass) {
        super(graph, baseParamConclusion, paramCount, declaringClass);
        doAnalysis();
    }

    @Override
    protected void flowThrough(VarStatusInfo in, Unit unit,
                               List<VarStatusInfo> fallOuts, List<VarStatusInfo> branchOuts) {
        prepareFlowThrough();
        if (notReachableCollection.contains(unit)) {
            handleUnreachableUnit(in, unit, fallOuts, branchOuts);
            return;
        }
        Stmt s = (Stmt) unit;
        NullnessTool.flowThrough(s, in, fallOuts, branchOuts, NullnessConfig.getInvocationDepth(), this);

        ReachableTool.analyzeReachable(s, (UnitGraph) this.graph, in,this, fallOuts, branchOuts);
    }
    public void redoAnalysis(ParamConclusion.BaseParamConclusion baseParamConclusion) {
        if (baseParamConclusion != null) {
            this.paramConclusion = baseParamConclusion.getParamConclusion();
            this.baseStatus = baseParamConclusion.getBaseConclusion();
        }
        super.clear();
        doAnalysis();
    }

}
