package edu.redundantcheck.analyses;

import edu.redundantcheck.analyses.nullness.NullnessConfig;
import edu.redundantcheck.analyses.nullness.NullnessTool;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.reachable.ReachableTool;
import soot.*;
import soot.jimple.*;
import soot.toolkits.graph.UnitGraph;

import java.util.*;

// Invocation analysis
public class InvocationAnalysis extends DataflowAnalysis {
    private VarStatus returnStatus;
    private int returnDepth;
    private VarStatus baseStatusReturn;
    private String methodName;
    private boolean isDeadInvocation;

    private List<VarStatus> argumentsReturn;

    public boolean isDeadInvocation() {
        return isDeadInvocation;
    }

    public InvocationAnalysis(UnitGraph unitGraph, List<VarStatus> argStatusList,
                              int returnDepth, VarStatus baseStatus,
                              String methodName, String declaringClass) {
        super(unitGraph, argStatusList, baseStatus, declaringClass);
        returnStatus = null;
        this.returnDepth = returnDepth;
        this.methodName = methodName;
        this.isDeadInvocation = true;
        argumentsReturn = new ArrayList<>();
        for (int i = 0 ; i < argStatusList.size();i++) {
            argumentsReturn.add(VarStatus.UNKNOWN_DEFAULT);
        }
        doAnalysis();
    }

    private void assertAfter() {
        VarStatus.assertNegativeParam(baseStatusReturn);
        VarStatus.assertNegativeParam(returnStatus);
        for (VarStatus status: argumentsReturn) {
            VarStatus.assertNegativeParam(status);
        }
    }

    public VarStatus getBaseStatusReturn() {
        if (VarStatus.isConstants(baseStatusReturn)) return VarStatus.NON_NULL;
        return baseStatusReturn == null? VarStatus.NON_NULL: baseStatusReturn;
    }

    public List<VarStatus> getArgumentsReturn() {
        return argumentsReturn;
    }

    public void appendTraceToReturn(Null.Trace trace)
    {
        Map<VarStatus, VarStatus> old2new = new HashMap<>();
        baseStatusReturn = VarStatus.appendTraceWithMap(getBaseStatusReturn(), trace, old2new);
        returnStatus = getReturnStatus();
        if (old2new.containsKey(returnStatus)) {
            returnStatus = old2new.get(returnStatus);
        }
        else {
            returnStatus = VarStatus.appendTrace(returnStatus, trace);
        }
        cleanParamIdx();
        // assertAfter();
    }
    private void cleanParamIdx() {
        VarStatus.cleanCloneMergeInfo();
        baseStatusReturn = baseStatusReturn.cloneStatusWithNegativeParamIdx();
        returnStatus = returnStatus.cloneStatusWithNegativeParamIdx();
        for (int i = 0; i < argumentsReturn.size(); i++) {
            VarStatus argStatus = argumentsReturn.get(i);
            argStatus = argStatus.cloneStatusWithNegativeParamIdx();
            argumentsReturn.set(i, argStatus);
        }
        VarStatus.cleanCloneMergeInfo();
    }

    @Override
    protected void flowThrough(VarStatusInfo in, Unit unit,
                               List<VarStatusInfo> fallOuts,
                               List<VarStatusInfo> branchOuts
                               ) {
        prepareFlowThrough();
        if (notReachableCollection.contains(unit)) {
            handleUnreachableUnit(in, unit, fallOuts, branchOuts);
            return;
        }
        Stmt s = (Stmt) unit;
        NullnessTool.flowThrough(s, in, fallOuts, branchOuts, returnDepth, this);

        ReachableTool.analyzeReachable(s, (UnitGraph) this.graph, in,this, fallOuts, branchOuts);

        if (s instanceof ReturnStmt) {
            ReturnStmt returnStmt = (ReturnStmt) s;
            Value val = returnStmt.getOp();
            updateReturnStatus(in, val, s);
        }
        if ( s instanceof ReturnStmt || s instanceof ReturnVoidStmt) {
            this.isDeadInvocation = false; // contains reachable return.
            if (thisLocal != null) updateThisStatus(in, s);
            updateArgumentsReturn(in);
        }
    }

    private void updateArgumentsReturn(VarStatusInfo in) {
        // iterate VarStatusInfo, mergeStatus with paramIdx != -1
        VarStatus.cleanCloneMergeInfo();
        Set<VarStatus> visited = new HashSet<>();
        for (VarStatus status: in.getAllStatuses()) {
            try {
                updateArgumentsReturn(status, visited);
            } catch (Exception ignored) {
                System.out.println();
            }
        }
        VarStatus.cleanCloneMergeInfo();
    }

    private void updateArgumentsReturn(VarStatus status, Set<VarStatus> visited) {
        if (visited.contains(status)) return;
        visited.add(status);
        if (status.getParamIdx() != -1) {
            int idx = status.getParamIdx();
            VarStatus merge = VarStatus.merge(argumentsReturn.get(idx), status);
            argumentsReturn.set(idx, merge);
        }
        if (VarStatus.isNonNullInstance(status)) {
            for (String field: status.getField2status().keySet()) {
                updateArgumentsReturn(status.getFieldStatus(field), visited);
            }
        }
    }

   private void updateThisStatus(VarStatusInfo in, Stmt s) {
       if (notReachableCollection.contains(s)) return;
       VarStatus status = in.getStatus(thisLocal, VarStatus.NULL);
       baseStatusReturn = getUpdatedStatus(baseStatusReturn, status);
   }
   private VarStatus getUpdatedStatus(VarStatus originStatus, VarStatus newStatus) {
        VarStatus result = null;
       if (originStatus == null) {
           result = newStatus;
       }
       else if (originStatus.isNull()) {
           if (newStatus == VarStatus.UNKNOWN_DEFAULT) {
               result = originStatus;
           }
           else if (VarStatus.isUnknownRisky(newStatus)
                    || VarStatus.isNonNull(newStatus)) {
               result = VarStatus.highestRisk(originStatus);
           }
           else {// newStatus == NULL
               result = originStatus;
           }
       }
       else if (VarStatus.isUnknownRisky(originStatus)) {
           if (VarStatus.isUnknownRisky(newStatus)) {
               result = VarStatus.mergeUnknown(originStatus, newStatus);
           }
           else if (VarStatus.isNonNull(newStatus) || newStatus == VarStatus.UNKNOWN_DEFAULT) {
               result = originStatus;
           }
           else {// newStatus == NULL
               result = VarStatus.highestRisk(newStatus);
           }
       }
       else if (VarStatus.isNonNull(originStatus)) {
           if (VarStatus.isUnknownRisky(newStatus)) {
               result = newStatus;
           }
           else if (newStatus == VarStatus.UNKNOWN_DEFAULT) {
               result = originStatus;
           }
           else if (newStatus.isNull()) {
               result = VarStatus.highestRisk(newStatus);
           }
           else {// newStatus is also non_null
               VarStatus.cleanCloneMergeInfo();
               result = VarStatus.merge(originStatus, newStatus);
               VarStatus.cleanCloneMergeInfo();
           }
       }
       return result;
   }

    private void updateReturnStatus(VarStatusInfo in, Value val, Stmt s) {
        if (notReachableCollection.contains(s)) return;
        VarStatus status = in.getStatus(val, s.getJavaSourceStartLineNumber(), declaringClass);
        if (status != null && status.isNull()) {
            ((Null)status).setNullType(Null.NullType.FROM_RETURN);
        }
        returnStatus = getUpdatedStatus(returnStatus, status);
    }

    public VarStatus getReturnStatus() {
        if (returnStatus == VarStatus.UNKNOWN_DEFAULT) {
            returnStatus = NullnessConfig.getReturnValueDefaultRisk();
            return returnStatus;
        }
        returnStatus = returnStatus == null? NullnessConfig.getReturnValueDefaultRisk() : returnStatus;
        return returnStatus;
    }
}
