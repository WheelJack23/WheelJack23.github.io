package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.jimple.MonitorStmt;

// synchronize(variable)
public class MonitorStmtHandler {
    public static void handle(MonitorStmt monitorStmt,
                              VarStatusInfo out, DataflowAnalysis analysisInfo) {
        out.setAllFieldLowRisk();
        out.setNonNull(monitorStmt.getOp(), analysisInfo);
    }
}
