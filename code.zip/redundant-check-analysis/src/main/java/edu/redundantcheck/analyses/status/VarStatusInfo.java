package edu.redundantcheck.analyses.status;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.nullness.InvokeExprHandler;
import soot.SootFieldRef;
import soot.Value;
import soot.jimple.*;
import soot.jimple.internal.JInstanceFieldRef;

import java.util.*;

// a map from variable to its status
public class VarStatusInfo {
    private Map<Value, VarStatus> value2status = new HashMap<>();
    private static Map<String, Set<String>> className2nonNullFields;
    private boolean alive = true;
    static {
        className2nonNullFields = InvokeExprHandler.getClassName2methods(InvokeExprHandler.class.getClassLoader().getResourceAsStream("class2nonnullfields.txt"));
    }
    public VarStatusInfo() {
        alive = true;
    }

    public Collection<VarStatus> getAllStatuses() {
        return value2status.values();
    }

    public void setDead() {
        alive = false;
    }
    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public boolean isAlive() {
        return alive;
    }

    public VarStatusInfo cloneInfo() {
        VarStatusInfo cl = new VarStatusInfo();
        cl.copyContent(this);
        cl.alive = this.alive;
        return cl;
    }

    public void copy(VarStatusInfo sourceInfo) {
        this.alive = sourceInfo.alive;
        this.copyContent(sourceInfo);
    }

    private void copyContent(VarStatusInfo sourceInfo) {
        Map<Value, VarStatus> otherValue2status = sourceInfo.value2status;
        for (Value key: otherValue2status.keySet()) {
            VarStatus status = otherValue2status.get(key);
            if (VarStatus.isConstants(status)) value2status.put(key, status);
        }
        if (value2status.size() == otherValue2status.size()) return;
        VarStatus.cleanCloneMergeInfo();
        Map<VarStatus, Set<Value>> status2values = getStatus2values(otherValue2status);
        for (VarStatus status: status2values.keySet()) {
            Set<Value> values = status2values.get(status);
            VarStatus statusClone = status.cloneStatus();
            for (Value value: values) value2status.put(value, statusClone);
        }
        VarStatus.cleanCloneMergeInfo();
    }

    private static Map<VarStatus, Set<Value>> getStatus2values(Map<Value, VarStatus> value2status) {
        Map<VarStatus, Set<Value>> status2values = new HashMap<>();
        for (Value key: value2status.keySet()) {
            VarStatus status = value2status.get(key);
            if (VarStatus.isConstants(status)) continue;
            if (!status2values.containsKey(status)) status2values.put(status, new HashSet<>());
            status2values.get(status).add(key);
        }
        return status2values;
    }

    public VarStatus getStatus(Value value, Null nullValue) {
        if (value instanceof StaticFieldRef) value = new MyStaticField((StaticFieldRef) value);
        if (value == NullConstant.v()) {
            return nullValue;
        }
        if (value instanceof JInstanceFieldRef) {// hint: important, no instance field value in value2status map.
            return getInstanceFieldStatus((JInstanceFieldRef) value);
        }
        if (!value2status.containsKey(value)) {// status == null
            if (isNonNullExpr(value)) return VarStatus.NON_NULL;
            return VarStatus.UNKNOWN_DEFAULT;
        }

        VarStatus status = value2status.get(value);
        if (!VarStatus.isNonNull(status) && isNonNullExpr(value)) {
            return VarStatus.NON_NULL;
        }
        return status;
    }

    public VarStatus getStatus(Value value, int lineNo, String declaringClass) {
        return getStatus(value, new Null(declaringClass, lineNo));
    }

    private VarStatus getInstanceFieldStatus(JInstanceFieldRef value) {
        Value base = value.getBase();
        VarStatus baseStatus = getStatus(base, VarStatus.NULL);
        if (VarStatus.isNonNullInstance(baseStatus)) {
            String fieldName = value.getField().getName();
            return baseStatus.getFieldStatus(fieldName);
        }
        return VarStatus.UNKNOWN_LOW_RISK;
    }

    public void setAllFieldLowRisk() {
        for (Value value: value2status.keySet()) {
            if (value instanceof StaticFieldRef) {
                value2status.put(value, VarStatus.UNKNOWN_LOW_RISK);
                continue;
            }
            VarStatus status = value2status.get(value);
            if (VarStatus.isNonNullInstance(status)) {
                status.clear();
            }
        }
    }
    public void setRawStatus(Value value, VarStatus status) {
        if (value instanceof StaticFieldRef) value = new MyStaticField((StaticFieldRef) value);
        if (value instanceof JInstanceFieldRef) {
            setInstanceFieldRawStatus((JInstanceFieldRef) value, status);
            return;
        }
        value2status.put(value, status);
    }

    public void setInstanceFieldRawStatus(JInstanceFieldRef instanceFieldRef, VarStatus status) {
        Value base = instanceFieldRef.getBase();
        VarStatus baseStatus = getStatus(base, VarStatus.NULL);
        if (VarStatus.isConstants(baseStatus)) {
            baseStatus = VarStatus.getNonNullInstance();
            setRawStatus(base, baseStatus);
        }
        String fieldName = instanceFieldRef.getField().getName();
        if (status == VarStatus.NON_NULL) {// setNonNull
            VarStatus fieldStatus = baseStatus.getFieldStatus(fieldName);
            if (!VarStatus.isNonNull(fieldStatus)){
                baseStatus.setFieldStatus(fieldName, VarStatus.NON_NULL);
            }
        }
        else {
            baseStatus.setFieldStatus(fieldName, status);
        }
    }

    public void setCloneStatus(Value value, VarStatus status) {
        if (value instanceof StaticFieldRef) value = new MyStaticField((StaticFieldRef) value);
        VarStatus.cleanCloneMergeInfo();
        value2status.put(value, status.cloneStatus());
        VarStatus.cleanCloneMergeInfo();
    }

    public void setNull(Value value, DataflowAnalysis analysisInfo, Null nullStatus) {
        if (value instanceof StaticFieldRef) value = new MyStaticField((StaticFieldRef) value);
        VarStatus originStatus = getStatus(value, VarStatus.NULL);
        if (VarStatus.isUnknownInstance(originStatus)) {
            replace(originStatus, nullStatus);
            return;
        }
        setNull(value, nullStatus);
    }

    private void setNull(Value value, VarStatus nullStatus) {
        if (value instanceof JInstanceFieldRef) {
            JInstanceFieldRef instanceFieldRef = (JInstanceFieldRef) value;
            setInstanceFieldRawStatus(instanceFieldRef, nullStatus);
            return;
        }
        setRawStatus(value, nullStatus);
    }

    /**
     * 1. a.field ==> a == NON_NULL
     * 2. a[1] ===> a == NON_NULL
     * 3. a instanceOf Object ==> a == NON_NULL
     * 4. if (a != null) ===> a == NON_NULL
     * 5. a.method1() ==> a == NON_NULL
     * 6. synchronized (a) {} ==> a == NON_NULL
     */
    public void setNonNull(Value value, DataflowAnalysis analysisInfo) {
        if (value instanceof StaticFieldRef) value = new MyStaticField((StaticFieldRef) value);
        VarStatus originalStatus = getStatus(value, VarStatus.NULL);
        if (VarStatus.isUnknownInstance(originalStatus)) {
            VarStatus nonNullInstance = VarStatus.getNonNullInstance();
            nonNullInstance.setParamIdx(originalStatus.paramIdx);
            replace(originalStatus, nonNullInstance);
            return;
        }
        if (VarStatus.isNonNull(originalStatus)) return;
        setNonNull(value);
    }
    private void setNonNull(Value value) {
        if (value instanceof JInstanceFieldRef) {
            JInstanceFieldRef instanceFieldRef = (JInstanceFieldRef) value;
            setInstanceFieldRawStatus(instanceFieldRef, VarStatus.NON_NULL);
            return;
        }
        VarStatus originStatus = this.getStatus(value, VarStatus.NULL);
        if (!VarStatus.isNonNull(originStatus)) setRawStatus(value, VarStatus.NON_NULL);
    }

    public void replace(VarStatus origin, VarStatus newStatus) {
        Set<VarStatus> visitedNonNulls = new HashSet<>();
        for (Value key: value2status.keySet()) {
            VarStatus valueStatus = value2status.get(key);
            if (valueStatus == origin) {
                value2status.put(key, newStatus);
            }
            else {
                if (VarStatus.isNonNullInstance(valueStatus) &&
                     !visitedNonNulls.contains(valueStatus)) {
                    visitedNonNulls.add(valueStatus);
                    valueStatus.replace(origin, newStatus, visitedNonNulls);
                }
            }
        }
    }

    public void clear() {
        value2status.clear();
    }

    public void merge(VarStatusInfo statusInfo) {
        if (!statusInfo.alive) return;
        if (value2status.isEmpty()) {
            copyContent(statusInfo);
            return;
        }
        Map<Value, VarStatus> otherValue2status = statusInfo.value2status;
        Set<Value> values = new HashSet<>();
        values.addAll(value2status.keySet());
        values.addAll(otherValue2status.keySet());
        Map<VarStatus, Set<Value>> status2values = new HashMap<>();
        Map<VarStatus, Set<Value>> otherStatus2values = new HashMap<>();
        Set<Value> processedValues = new HashSet<>();
        VarStatus.cleanCloneMergeInfo();
        mergeConstantUnknown(values, value2status,
                otherValue2status, processedValues, status2values, otherStatus2values);
        mergeNonNullInstanceStatus(values, value2status,
                otherValue2status, processedValues, status2values, otherStatus2values);
        VarStatus.cleanCloneMergeInfo();
    }

    private void mergeNonNullInstanceStatus(Set<Value> values, Map<Value, VarStatus> value2status,
                                            Map<Value, VarStatus> otherValue2status, Set<Value> processedValues,
                                            Map<VarStatus, Set<Value>> status2values,
                                            Map<VarStatus, Set<Value>> otherStatus2values) {
        for (Value value: values) {
            if (processedValues.contains(value)) continue;
            VarStatus originStatus = value2status.get(value);
            VarStatus otherStatus = otherValue2status.get(value);
            if (originStatus == null) {
                Set<Value> otherValuesWithSameStatus = otherStatus2values.get(otherStatus);
                processedValues.addAll(otherValuesWithSameStatus);
                for (Value otherValue: otherValuesWithSameStatus) {
                    value2status.put(otherValue, otherStatus.cloneStatus());
                }
                continue;
            }
            if (otherStatus == null) {
                Set<Value> valuesWithSameStatus = status2values.get(value2status.get(value));
                processedValues.addAll(valuesWithSameStatus);
                for (Value thisValue: valuesWithSameStatus) {
                    value2status.put(thisValue, originStatus.cloneStatus());
                }
                continue;
            }
            Set<Value> valuesWithSameStatus = status2values.get(value2status.get(value));
            Set<Value> otherValuesWithSameStatus = otherStatus2values.get(otherValue2status.get(value));
            processedValues.addAll(valuesWithSameStatus);
            processedValues.addAll(otherValuesWithSameStatus);

            Set<Value> interSet = new HashSet<>(valuesWithSameStatus);
            interSet.retainAll(otherValuesWithSameStatus);
            VarStatus mergeStatus = VarStatus.mergeInstances(originStatus, otherStatus);
            for (Value valueInInterSet: interSet) {
                value2status.put(valueInInterSet, mergeStatus);
            }
            valuesWithSameStatus.removeAll(interSet);
            for (Value valueRemained: valuesWithSameStatus) {
                VarStatus valueRemainedStatus =
                        VarStatus.mergeInstances(value2status.get(valueRemained), otherValue2status.get(valueRemained));
                value2status.put(valueRemained, valueRemainedStatus);
            }
            otherValuesWithSameStatus.removeAll(interSet);
            for (Value valueRemained: otherValuesWithSameStatus) {
                VarStatus valueRemainedStatus =
                        VarStatus.mergeInstances(value2status.get(valueRemained), otherValue2status.get(valueRemained));
                value2status.put(valueRemained, valueRemainedStatus);
            }
        }
    }

    private void mergeConstantUnknown(Set<Value> values, Map<Value, VarStatus> value2status,
                                      Map<Value, VarStatus> otherValue2status, Set<Value> processedValues,
                                      Map<VarStatus, Set<Value>> status2values,
                                      Map<VarStatus, Set<Value>> otherStatus2values) {
        // handle constants
        for (Value value: values) {
            VarStatus originStatus = value2status.get(value);
            VarStatus otherStatus = otherValue2status.get(value);
            if (originStatus == null && VarStatus.isConstants(otherStatus)) {
                value2status.put(value, otherStatus);
                processedValues.add(value);
                continue;
            }
            if (otherStatus == null && VarStatus.isConstants(originStatus)) {
                value2status.put(value, originStatus);
                processedValues.add(value);
                continue;
            }
            if (VarStatus.isUnknownRisky(originStatus) && VarStatus.isUnknownRisky(otherStatus)) {
                value2status.put(value, VarStatus.mergeUnknown(originStatus, otherStatus));
                processedValues.add(value);
                continue;
            }
            if (VarStatus.isUnknownInstance(originStatus) || VarStatus.isUnknownInstance(otherStatus)) {
                VarStatus unknown = originStatus;
                VarStatus notUnknown = otherStatus;
                if (VarStatus.isUnknownInstance(otherStatus)) {
                    VarStatus tmp = unknown;
                    unknown = notUnknown;
                    notUnknown = tmp;
                }
                VarStatus mergeResult = null; // notUnknown == NULL
                if (VarStatus.isNonNull(notUnknown)) {// notUnknown is non-null.
                    mergeResult = VarStatus.getUnknownConstant(unknown);
                }
                else if (notUnknown == null) {
                    mergeResult = unknown;
                }
                else {// notUnknown is null
                    mergeResult = VarStatus.highestRisk(notUnknown);
                }
                value2status.put(value, mergeResult);
                processedValues.add(value);
                continue;
            }
            if (VarStatus.isConstants(originStatus) && VarStatus.isConstants(otherStatus)) {
                value2status.put(value, VarStatus.mergeNoDepth(originStatus, otherStatus));
                processedValues.add(value);
                continue;
            }
            if (VarStatus.isConstants(originStatus) || VarStatus.isConstants(otherStatus)) {
                value2status.put(value, VarStatus.mergeConstantNonNullInstance(originStatus, otherStatus));
                processedValues.add(value);
                continue;
            }
            if (originStatus != null) addValue(status2values, originStatus, value);
            if (otherStatus != null) addValue(otherStatus2values, otherStatus, value);
        }
    }

    private void addValue(Map<VarStatus, Set<Value>> status2values, VarStatus status, Value value) {
        if (!status2values.containsKey(status)) status2values.put(status, new HashSet<>());
        status2values.get(status).add(value);
    }

    public static boolean isNonNullExpr(Value value) {
        return (value instanceof NewArrayExpr
                || value instanceof NewMultiArrayExpr || value instanceof ThisRef || value instanceof StringConstant
                || value instanceof ClassConstant || value instanceof CaughtExceptionRef || isNonNullStaticField(value));
    }

    private static boolean isNonNullStaticField(Value value) {
        if (value instanceof StaticFieldRef) {
            SootFieldRef fieldRef = ((StaticFieldRef) value).getFieldRef();
            String className = fieldRef.declaringClass().toString();
            if (className.equals("java.util.Locale")) return true; // like, FRENCH, GERMAN
            Set<String> nonNullFields = className2nonNullFields.get(className);
            if (nonNullFields == null) return false;
            String fieldName = fieldRef.name();
            return nonNullFields.contains(fieldName);
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VarStatusInfo that = (VarStatusInfo) o;
        if (value2status.size() != that.value2status.size()) return false;
        for (Value key: value2status.keySet()) {
            VarStatus status = value2status.get(key);
            VarStatus thatStatus = that.value2status.get(key);
            if (status == null || thatStatus == null) return false;
            if (status.nullStatus != thatStatus.nullStatus) return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return value2status != null ? value2status.hashCode() : 0;
    }

    public static class MyStaticField extends StaticFieldRef {
        public MyStaticField(SootFieldRef fieldRef) {
            super(fieldRef);
        }

        public MyStaticField(StaticFieldRef ref) {
            this(ref.getFieldRef());
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof StaticFieldRef)) return false;
            StaticFieldRef ref = (StaticFieldRef) obj;
            return getField().getDeclaringClass().toString().equals(ref.getField().getDeclaringClass().toString())
                    && getField().getName().equals(ref.getField().getName());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getField().getDeclaringClass().toString(), getField().getName());
        }
    }
}
