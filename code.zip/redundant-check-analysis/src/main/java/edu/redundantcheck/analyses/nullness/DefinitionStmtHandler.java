package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JArrayRef;
import soot.jimple.internal.JCastExpr;
import soot.jimple.internal.JInstanceFieldRef;
import soot.shimple.PhiExpr;

import java.util.List;
import java.util.Map;

public class DefinitionStmtHandler {
    // handle Definition Statement
    public static void handle(DefinitionStmt defStmt, VarStatusInfo out, DataflowAnalysis analysis) {
        List<VarStatus> paramConclusion = analysis.getParamConclusion();
        Map<Value, Value> instanceOfMap = analysis.getInstanceOfMap();
        Value left = defStmt.getLeftOp();
        Value right = defStmt.getRightOp();
        if (right instanceof InstanceOfExpr) {
            InstanceOfExpr instanceOfExpr = (InstanceOfExpr) right;
            Value base = instanceOfExpr.getOp();
            instanceOfMap.put(left, base);
        }
        if (left.getType() instanceof RefLikeType) {
            // unbox casted value
            if (right instanceof JCastExpr) {
                JCastExpr castExpr = (JCastExpr) right;
                right = castExpr.getOp();
            }

            // if we have a definition (assignment) statement to a ref-like type, handle it,
            if (right instanceof ParameterRef) {
                handleParamAssignment(left, right, out, paramConclusion);
            } else if (field2local(left, right)
                    || local2field(left, right)
                    || local2local(left, right)
                    || local2static(left, right)) {
                assignmentBinding(left, right, out);
            } else if (static2local(left, right)) {
                VarStatus status = null;
                if (isEnumType((StaticFieldRef) right)) {
                    status = VarStatus.NON_NULL;
                    out.setRawStatus(left, status);
                    return;
                }
                assignmentBinding(left, right, out);
            } else if (left instanceof Local && right instanceof ThisRef) {
                VarStatus baseStatus = analysis.getBaseStatus();
                if (baseStatus != null) out.setRawStatus(left, baseStatus);
                else out.setRawStatus(left, VarStatus.NON_NULL);
            } else if (left instanceof Local && right instanceof NewExpr) {
                out.setRawStatus(left, VarStatus.getNonNullInstance());
            } else if (VarStatusInfo.isNonNullExpr(right)) {
                out.setRawStatus(left, VarStatus.NON_NULL);
            } else if (right == NullConstant.v()) {
                // if we assign null, well, it's null
                out.setRawStatus(left, new Null(analysis.declaringClass, defStmt.getJavaSourceStartLineNumber()));
            } else if (left instanceof Local && right instanceof PhiExpr) {
                handlePhiExpr(out, left, (PhiExpr) right);
            } else if (isArrayRefCase(left, right)) {
                out.setRawStatus(left, NullnessConfig.getArrayEleDefaultRisk());
            } else {
                out.setRawStatus(left, VarStatus.UNKNOWN_LOW_RISK);
            }
        }
    }

    private static void assignmentBinding(Value left, Value right, VarStatusInfo out) {// especially for unknown instance binding
        VarStatus status = out.getStatus(right, VarStatus.NULL);
        if (status == VarStatus.UNKNOWN_DEFAULT) {
            if (right instanceof StaticFieldRef) {
                status = NullnessConfig.getStaticFieldDefaultRisk();
            } else {
                status = VarStatus.UNKNOWN_LOW_RISK;
            }
        }
        if (VarStatus.isConstants(status) &&
                VarStatus.isUnknownRisky(status)) {
            status = VarStatus.getUnknownInstance(status);
            out.setRawStatus(right, status);// unknown instance binding
        }
        out.setRawStatus(left, status);
    }

    // case: a.field1 = $stack
    private static void handleAssign2InstanceField(Value left, Value right, VarStatusInfo out) {
        JInstanceFieldRef instanceFieldRef = (JInstanceFieldRef) left;
        Value instance = instanceFieldRef.getBase();
        VarStatus instanceStatus = out.getStatus(instance, VarStatus.NULL);
        if (VarStatus.isConstants(instanceStatus)) {
            instanceStatus = VarStatus.getNonNullInstance();
            out.setRawStatus(instance, instanceStatus);
        }
        String fieldName = instanceFieldRef.getField().getName();
        instanceStatus.setFieldStatus(fieldName, out.getStatus(right, VarStatus.NULL));
    }

    // case: $stack1 = @param1
    private static void handleParamAssignment(Value left, Value right, VarStatusInfo out,
                                              List<VarStatus> paramConclusion) {
        if (paramConclusion != null) {
            ParameterRef parameterRef = (ParameterRef) right;
            int parameterIdx = parameterRef.getIndex();
            VarStatus status = paramConclusion.get(parameterIdx);
            if (status == VarStatus.UNKNOWN_DEFAULT) {
                status = NullnessConfig.getMethodParamDefaultRisk();
            }
            out.setRawStatus(left, status);
        } else {
            VarStatus status = NullnessConfig.getMethodParamDefaultRisk();
            out.setRawStatus(left, status);
        }
    }


    private static boolean isArrayRefCase(Value left, Value right) {
        return (left instanceof Local && right instanceof ArrayRef);
    }


    private static boolean local2local(Value left, Value right) {
        return left instanceof Local && right instanceof Local;
    }

    // local = static field
    private static boolean static2local(Value left, Value right) {
        return left instanceof Local && right instanceof StaticFieldRef;
    }

    // local = field
    private static boolean field2local(Value left, Value right) {
        return left instanceof Local && right instanceof JInstanceFieldRef;
    }

    // field = local
    private static boolean local2field(Value left, Value right) {
        return left instanceof JInstanceFieldRef && right instanceof Local;
    }

    private static boolean isEnumType(StaticFieldRef fieldRef) {
        SootField sootField = fieldRef.getField();
        SootClass sootClass = sootField.getDeclaringClass();
        return sootClass.isEnum() && sootField.getModifiers() == 16409;
    }

    // static field = local
    private static boolean local2static(Value left, Value right) {
        return left instanceof StaticFieldRef && right instanceof Local;
    }

    private static void handlePhiExpr(VarStatusInfo out, Value left, PhiExpr right) {
        VarStatus curr = VarStatus.UNKNOWN_DEFAULT;
        for (Value v : right.getValues()) {
            VarStatus newStatus = out.getStatus(v, VarStatus.NULL);
            if (curr == VarStatus.UNKNOWN_DEFAULT) {
                curr = newStatus;
                continue;
            }
            if (VarStatus.isUnknownRisky(curr)) {
                if (VarStatus.isUnknownRisky(newStatus)) {
                    curr = VarStatus.mergeUnknown(curr, newStatus);
                } else if (newStatus.isNull()) {
                    curr = VarStatus.highestRisk(newStatus);
                }
//                else {// NON_NULL/DEFAULT
                continue;
            }
            if (curr.isNull()) {
                if (VarStatus.isUnknownRisky(newStatus) || VarStatus.isNonNull(newStatus)) {
                    curr = VarStatus.highestRisk(curr);
                }
                // newStatus == NULL || newStatus == DEFAULT
                continue;
            }
            // curr ==> NON_NULL
            VarStatus.cleanCloneMergeInfo();
            curr = VarStatus.merge(curr, newStatus);
            VarStatus.cleanCloneMergeInfo();
        }
        out.setRawStatus(left, curr);
    }
}
