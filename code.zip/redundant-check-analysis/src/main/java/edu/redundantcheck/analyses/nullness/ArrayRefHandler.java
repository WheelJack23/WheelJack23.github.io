package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.Value;
import soot.jimple.ArrayRef;

public class ArrayRefHandler {
    public static void handle(ArrayRef arrayRef, VarStatusInfo out,
                              DataflowAnalysis analysisInfo) {
        Value array = arrayRef.getBase();
        // here we know that the array must point to an object
        out.setNonNull(array, analysisInfo);
    }
}
