package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.UnknownHighRisk;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.Local;
import soot.Value;
import soot.jimple.IntConstant;
import soot.jimple.NullConstant;
import soot.jimple.internal.*;

import java.util.Map;

// handle if statement
public class IfStmtHandler {
    public static void handle(JIfStmt ifStmt, VarStatusInfo out, VarStatusInfo outBranch,
                              DataflowAnalysis analysisInfo) {
        Value condition = ifStmt.getCondition();
        if (condition instanceof JInstanceOfExpr) {
            // a instanceof X ; if this succeeds, a is not null
            JInstanceOfExpr expr = (JInstanceOfExpr) condition;
            handleInstanceOfExpression(expr, outBranch, analysisInfo);
        } else if (condition instanceof JEqExpr || condition instanceof JNeExpr) {
            // a==b or a!=b
            AbstractBinopExpr eqExpr = (AbstractBinopExpr) condition;
            handleEqualityOrNonEqualityCheck(eqExpr, out, outBranch, analysisInfo, ifStmt.getJavaSourceStartLineNumber());
        }
    }

    private static void handleInstanceOfExpression(JInstanceOfExpr expr, VarStatusInfo outBranch,
                                                   DataflowAnalysis analysisInfo) {
        Value op = expr.getOp();
        // if instanceof succeeds, we have a non-null value
        outBranch.setNonNull(op, analysisInfo);
    }


    private static void handleEqualityOrNonEqualityCheck(AbstractBinopExpr eqExpr, VarStatusInfo out,
                                                         VarStatusInfo outBranch,
                                                         DataflowAnalysis analysisInfo, int lineNo) {
        Value left = eqExpr.getOp1();
        Value right = eqExpr.getOp2();
        Map<Value, Value> instanceOfMap = analysisInfo.getInstanceOfMap();
        Map<Value, Value> isEmptyMap = analysisInfo.getIsEmptyMap();

        if (instanceOfMap.containsKey(left) || isEmptyMap.containsKey(left)) {
            IntConstant nonNullConstant = IntConstant.v(1);// (a instanceof Case1) == 1
            IntConstant nullConstant = IntConstant.v(0);// (a instanceof Case1) == 0
            Value instanceOfBase = instanceOfMap.get(left);
            if (isEmptyMap.containsKey(left)) {
                nonNullConstant = IntConstant.v(0);
                nullConstant = IntConstant.v(1);
                instanceOfBase = isEmptyMap.get(left);
            }
            if (right.equals(nullConstant)) { // TRUE --> outBranch; FALSE --> out
                if (eqExpr instanceof JEqExpr) { // (a instanceof Case1) == 0
                    out.setNonNull(instanceOfBase, analysisInfo);
                }
                else { // (a instanceof Case1) == 1
                    outBranch.setNonNull(instanceOfBase, analysisInfo);
                }
            }
            else if (right.equals(nonNullConstant)) {
                if (eqExpr instanceof JEqExpr) { // (a instanceof Case1) == 1
                    outBranch.setNonNull(instanceOfBase, analysisInfo);
                }
                else { // (a instanceof Case1) != 1
                    out.setNonNull(instanceOfBase, analysisInfo);
                }
            }
            return;
        }
        Value val = null;
        if (left == NullConstant.v()) {
            if (right != NullConstant.v()) {
                val = right;
            }
        } else if (right == NullConstant.v()) {
            if (left != NullConstant.v()) {
                val = left;
            }
        }

        // if we compare a local with null then process further...
        if (val != null && val instanceof Local) {
            if (eqExpr instanceof JEqExpr) {
                // a==null
                handleEquality(val, out, outBranch, analysisInfo, lineNo);
            } else if (eqExpr instanceof JNeExpr) {
                handleNonEquality(val, out, outBranch, analysisInfo, lineNo);
            } else {
                throw new IllegalStateException("unexpected condition: " + eqExpr.getClass());
            }
        }
    }

    private static void handleNonEquality(Value val, VarStatusInfo out,
                                          VarStatusInfo outBranch, DataflowAnalysis analysisInfo,
                                          int lineNo) {
        Null nullValue = getOriginNull(val, out, analysisInfo.declaringClass, lineNo);
        out.setNull(val, analysisInfo, nullValue);
        outBranch.setNonNull(val, analysisInfo);
    }

    private static void handleEquality(Value val, VarStatusInfo out, VarStatusInfo outBranch,
                                       DataflowAnalysis analysisInfo, int lineNo) {
        Null nullValue = getOriginNull(val, out, analysisInfo.declaringClass, lineNo);
        out.setNonNull(val, analysisInfo);
        outBranch.setNull(val, analysisInfo, nullValue);
    }

    private static Null getOriginNull(Value val, VarStatusInfo out, String declaringClass, int lineNo) {
        VarStatus status = out.getStatus(val, VarStatus.NULL);
        if (status.isNull()) return (Null) status;
        if (status instanceof UnknownHighRisk) {
            return ((UnknownHighRisk) status).getNullValue();
        }
        Null nullStatus = new Null(declaringClass, lineNo, Null.NullType.FROM_NULL_CHECK);
        nullStatus.setParamIdx(status.getParamIdx());
        return nullStatus;
    }
}
