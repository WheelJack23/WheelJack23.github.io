package edu.redundantcheck.analyses;

import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.reachable.NotReachableCollection;
import edu.redundantcheck.analyses.reachable.ReachableTool;
import soot.*;
import soot.jimple.DefinitionStmt;
import soot.jimple.StaticFieldRef;
import soot.jimple.Stmt;
import soot.jimple.ThisRef;
import soot.jimple.internal.JInstanceFieldRef;
import soot.options.Options;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.PseudoTopologicalOrderer;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.interaction.FlowInfo;
import soot.toolkits.graph.interaction.InteractionHandler;
import soot.toolkits.scalar.ForwardBranchedFlowAnalysis;
import soot.util.Chain;

import java.util.*;

// Parent class of Invocation Analysis and Intra-procedural Analysis(RedundantAnalysis and NPEAnalysis)
public abstract class DataflowAnalysis extends ForwardBranchedFlowAnalysis<VarStatusInfo> {
    protected Set<Unit> reachableSet;
    protected NotReachableCollection notReachableCollection;
    protected Set<Unit> certainReachableSet;
    protected List<VarStatus> paramConclusion;
    protected UnitGraph unitGraph;
    protected Map<Value, Value> instanceOfMap;
    protected Map<Value, Value> isEmptyMap;
    protected Local thisLocal;// for instance invocation, this reference will be assigned to a local variable.
    public VarStatus baseStatus; // for instance invocation, baseStatus is the status of this reference.
    public boolean currentStmtContainsDeadInvocation;
    public String declaringClass;

    public DataflowAnalysis(UnitGraph graph, List<VarStatus> paramConclusion, VarStatus baseStatus,
                            String declaringClass) {
        super(graph);
        initializeFields(graph, declaringClass);
        this.paramConclusion = paramConclusion;
        for (int i = 0 ; i < paramConclusion.size(); i++) {
            VarStatus status = paramConclusion.get(i);
            if (VarStatus.isUnknownRisky(status) && VarStatus.isConstants(status)) {
                paramConclusion.set(i, VarStatus.getUnknownInstance(status));
            }
        }
        this.baseStatus = baseStatus;
    }
    public DataflowAnalysis(UnitGraph graph, ParamConclusion.BaseParamConclusion baseParamConclusion,
                            int paramCount, String declaringClass) {
        super(graph);
        initializeFields(graph, declaringClass);
        if (baseParamConclusion != null) {
            this.baseStatus = baseParamConclusion.getBaseConclusion();
            this.paramConclusion = baseParamConclusion.getParamConclusion();
        }
        else {
            this.paramConclusion = new ArrayList<>();
            for (int i = 0 ; i < paramCount; i++) {
                this.paramConclusion.add(VarStatus.getUnknownInstance(VarStatus.UNKNOWN_LOW_RISK));
            }
        }
    }

    protected void prepareFlowThrough() {
        currentStmtContainsDeadInvocation = false;
    }

    private void initializeFields(UnitGraph graph, String declaringClass) {
        this.reachableSet = new HashSet<>();
        this.notReachableCollection = new NotReachableCollection();
        this.certainReachableSet = new HashSet<>();
        this.unitGraph = graph;
        this.instanceOfMap = new HashMap<>();
        this.isEmptyMap = new HashMap<>();
        this.thisLocal = getThisLocal(unitGraph);
        this.declaringClass = declaringClass;
    }


    public VarStatus getBaseStatus() {
        return baseStatus;
    }

    private static Local getThisLocal(UnitGraph unitGraph) {
        for (Unit unit: unitGraph) {
            if (unit instanceof DefinitionStmt) {
                DefinitionStmt stmt = (DefinitionStmt) unit;
                Value left = stmt.getLeftOp();
                Value right = stmt.getRightOp();
                if (left instanceof Local && right instanceof ThisRef) return (Local) left;
            }
        }
        return null;
    }

    public void handleUnreachableUnit(VarStatusInfo in, Unit unit,
                                      List<VarStatusInfo> fallOuts, List<VarStatusInfo> branchOuts) {
        for (VarStatusInfo info: fallOuts) info.setDead();
        for (VarStatusInfo info: branchOuts) info.setDead();
        ReachableTool.analyzeReachable((Stmt) unit, (UnitGraph) this.graph, in,this, fallOuts, branchOuts);
    }

    public Set<Unit> getReachableSet() {
        return reachableSet;
    }

    public NotReachableCollection getNotReachableCollection() {
        return notReachableCollection;
    }

    public Set<Unit> getCertainReachableSet() {
        return certainReachableSet;
    }

    private static boolean staticField2local(Value left, Value right) {
        return left instanceof Local && right instanceof StaticFieldRef;
    }

    private static boolean instanceField2local(Value left, Value right) {
        return left instanceof Local && right instanceof JInstanceFieldRef;
    }

    protected void clear() {
        reachableSet.clear();
        notReachableCollection.clear();
        certainReachableSet.clear();
        instanceOfMap.clear();
    }


    public List<VarStatus> getParamConclusion() {
        return paramConclusion;
    }

    public Map<Value, Value> getInstanceOfMap() {
        return instanceOfMap;
    }

    public Map<Value, Value> getIsEmptyMap() {
        return isEmptyMap;
    }


    @Override
    protected VarStatusInfo newInitialFlow() {
        return new VarStatusInfo();
    }

    @Override
    protected void merge(VarStatusInfo in1, VarStatusInfo in2, VarStatusInfo out) {
        out.clear();
        if (!in1.isAlive() && !in2.isAlive()) {
            out.setDead();
            return;
        }
        out.merge(in1);
        out.merge(in2);
    }

    @Override
    protected void copy(VarStatusInfo source, VarStatusInfo destination) {
        destination.clear();
        destination.copy(source);
    }

    @Override
    protected void doAnalysis() {
        TreeSet<Unit> changedUnits = new TreeSet<Unit>(new Comparator<Unit>() {
            // map each unit to a distinct integer for a total ordering
            final Map<Unit, Integer> numbers = new HashMap<Unit, Integer>();
            {
                int i = 1;
                for (Unit u : new PseudoTopologicalOrderer<Unit>().newList(graph, false)) {
                    numbers.put(u, i);
                    i++;
                }
            }

            @Override
            public int compare(Unit o1, Unit o2) {
                return numbers.get(o1) - numbers.get(o2);
            }
        });

        // initialize unitToIncomingFlowSets
        final int numNodes = graph.size();
        Map<Unit, ArrayList<VarStatusInfo>> unitToIncomingFlowSets = new HashMap<Unit, ArrayList<VarStatusInfo>>(numNodes * 2 + 1, 0.7f);
        for (Unit s : graph) {
            unitToIncomingFlowSets.put(s, new ArrayList<VarStatusInfo>());
        }

        int numComputations = 0;
        int maxBranchSize = 0;

        // Set initial values and nodes to visit.
        // WARNING: DO NOT HANDLE THE CASE OF THE TRAPS
        {
            Chain<Unit> sl = ((UnitGraph) graph).getBody().getUnits();
            for (Unit s : graph) {
                changedUnits.add(s);

                unitToBeforeFlow.put(s, newInitialFlow());

                List<VarStatusInfo> unitFallOut = new ArrayList<VarStatusInfo>();
                if (s.fallsThrough()) {
                    unitFallOut.add((newInitialFlow()));
                    unitToAfterFallFlow.put(s, unitFallOut);

                    Unit succ = sl.getSuccOf(s);
                    // it's possible for someone to insert some (dead)
                    // fall through code at the very end of a method body
                    if (succ != null) {
                        unitToIncomingFlowSets.get(succ).addAll(unitFallOut);
                    }
                    // new feature here: add exception successor
                    List<Unit> exceptionalSuccs = ((ExceptionalUnitGraph)unitGraph).getExceptionalSuccsOf(s);
                    for (Unit exSucc: exceptionalSuccs) {
                        unitToIncomingFlowSets.get(exSucc).addAll(unitFallOut);
                    }

                } else {
                    unitToAfterFallFlow.put(s, unitFallOut);
                }

                final List<UnitBox> unitBoxes = s.getUnitBoxes();
                List<VarStatusInfo> l = new ArrayList<VarStatusInfo>();
                if (s.branches()) {
                    for (UnitBox ub : unitBoxes) {
                        VarStatusInfo f = newInitialFlow();
                        l.add(f);
                        unitToIncomingFlowSets.get(ub.getUnit()).add(f);
                    }
                }
                unitToAfterBranchFlow.put(s, l);

                if (unitBoxes.size() > maxBranchSize) {
                    maxBranchSize = unitBoxes.size();
                }
            }
        }

        // Feng Qian: March 07, 2002
        // init entry points
        final List<Unit> heads = graph.getHeads();
        for (Unit s : heads) {
            // this is a forward flow analysis
            unitToBeforeFlow.put(s, entryInitialFlow());
        }

        if (treatTrapHandlersAsEntries()) {
            for (Trap trap : ((UnitGraph) graph).getBody().getTraps()) {
                unitToBeforeFlow.put(trap.getHandlerUnit(), entryInitialFlow());
            }
        }

        // Perform fixed point flow analysis
        {
            VarStatusInfo[] flowRepositories = new VarStatusInfo[maxBranchSize + 1];
            VarStatusInfo[] previousFlowRepositories = new VarStatusInfo[maxBranchSize + 1];
            for (int i = 0; i < maxBranchSize + 1; i++) {
                flowRepositories[i] = newInitialFlow();
                previousFlowRepositories[i] = newInitialFlow();
            }

            List<VarStatusInfo> previousAfterFlows = new ArrayList<VarStatusInfo>();
            List<VarStatusInfo> afterFlows = new ArrayList<VarStatusInfo>();
            while (!changedUnits.isEmpty()) {
                Unit s = changedUnits.first();
                changedUnits.remove(s);

                accumulateAfterFlowSets(s, previousFlowRepositories, previousAfterFlows);

                // Compute and store beforeFlow
                VarStatusInfo beforeFlow = getFlowBefore(s);
                {
                    Iterator<VarStatusInfo> preds = unitToIncomingFlowSets.get(s).iterator();
                    if (preds.hasNext()) {
                        // Handle the first pred
                        copy(preds.next(), beforeFlow);
                        // Handle remaining preds
                        while (preds.hasNext()) {
                            VarStatusInfo otherBranchFlow = preds.next();
                            VarStatusInfo newBeforeFlow = newInitialFlow();
                            merge(s, beforeFlow, otherBranchFlow, newBeforeFlow);
                            copy(newBeforeFlow, beforeFlow);
                        }

                        if (heads.contains(s)) {
                            mergeInto(s, beforeFlow, entryInitialFlow());
                        }
                    }
                }

                // Compute afterFlow and store it.
                {
                    List<VarStatusInfo> afterFallFlow = unitToAfterFallFlow.get(s);
                    List<VarStatusInfo> afterBranchFlow = getBranchFlowAfter(s);
                    if (Options.v().interactive_mode()) {
                        InteractionHandler ih = InteractionHandler.v();
                        VarStatusInfo savedFlow = newInitialFlow();
                        copy(beforeFlow, savedFlow);
                        FlowInfo<VarStatusInfo, Unit> fi = new FlowInfo<VarStatusInfo, Unit>(savedFlow, s, true);
                        if (ih.getStopUnitList() != null && ih.getStopUnitList().contains(s)) {
                            ih.handleStopAtNodeEvent(s);
                        }
                        ih.handleBeforeAnalysisEvent(fi);
                    }
                    flowThrough(beforeFlow, s, afterFallFlow, afterBranchFlow);
                    if (Options.v().interactive_mode()) {
                        List<VarStatusInfo> l = new ArrayList<VarStatusInfo>();
                        if (!afterFallFlow.isEmpty()) {
                            l.addAll(afterFallFlow);
                        }
                        if (!afterBranchFlow.isEmpty()) {
                            l.addAll(afterBranchFlow);
                        }

                        /*
                         * if (s instanceof soot.jimple.IfStmt){ l.addAll((List)afterFallFlow); l.addAll((List)afterBranchFlow); } else {
                         * l.addAll((List)afterFallFlow); }
                         */
                        FlowInfo<List<VarStatusInfo>, Unit> fi = new FlowInfo<List<VarStatusInfo>, Unit>(l, s, false);
                        InteractionHandler.v().handleAfterAnalysisEvent(fi);
                    }
                    numComputations++;
                }

                accumulateAfterFlowSets(s, flowRepositories, afterFlows);

                // Update queue appropriately
                if (!afterFlows.equals(previousAfterFlows)) {
                    for (Unit succ : graph.getSuccsOf(s)) {
                        changedUnits.add(succ);
                    }
                }
            }
        }

        Timers.v().totalFlowNodes += numNodes;
        Timers.v().totalFlowComputations += numComputations;

    } // end doAnalysis

    // Accumulate the previous afterFlow sets.
    private void accumulateAfterFlowSets(Unit s, VarStatusInfo[] flowRepositories, List<VarStatusInfo> previousAfterFlows) {
        int repCount = 0;

        previousAfterFlows.clear();
        if (s.fallsThrough()) {
            copy(unitToAfterFallFlow.get(s).get(0), flowRepositories[repCount]);
            previousAfterFlows.add(flowRepositories[repCount++]);
        }

        if (s.branches()) {
            for (VarStatusInfo fs : getBranchFlowAfter(s)) {
                copy(fs, flowRepositories[repCount]);
                previousAfterFlows.add(flowRepositories[repCount++]);
            }
        }
    } // end accumulateAfterFlowSets

    public Set<Unit> getNotReachableSet() {
        return notReachableCollection.getNotReachableSet();
    }
}
