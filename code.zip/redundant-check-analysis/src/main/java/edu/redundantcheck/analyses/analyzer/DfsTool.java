package edu.redundantcheck.analyses.analyzer;

import edu.callgraph.impurity.bean.Node;
import edu.redundantcheck.analyses.result.CombineResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class DfsTool {
    private static final Logger LOGGER = LoggerFactory.getLogger(DfsTool.class);
    public static void iterateNodes(List<Node> nodes, CombineResult result) {
        LOGGER.info("Start to analyze result, size: " + nodes.size());
        PercentageCounter pc = new PercentageCounter(nodes.size());
        for (Node node: nodes) {
            pc.addCount();
            pc.logInfo();
            AnalyzerTool.analyzeNode(node, result);
        }
    }

    public static List<Node> getNotVisitedNodes(List<Node> nodes) {
        List<Node> notVisitedNodes = new ArrayList<>();
        for (Node node: nodes) {
//            if (!node.isVisited && !node.getMethod().isPrivate()) {
            if (!node.isVisited && !node.getMethod().isPrivate()) {
                // Find a non-private method that has not been accessed
                notVisitedNodes.add(node);
//                ParamConclusion.setConclusionUnknown(node);
            }
        }
        return notVisitedNodes;
    }
}
