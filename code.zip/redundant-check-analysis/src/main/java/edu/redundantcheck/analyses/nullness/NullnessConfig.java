package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.status.VarStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class NullnessConfig {
    private static int INVOCATION_DEPTH;
    private static int FIELD_DEPTH;
    private static final Logger LOGGER = LoggerFactory.getLogger(NullnessConfig.class);
    public static Map<String, VarStatus> scene2status = new HashMap<>();

    public static boolean SHOW_UNLOOP_DETAIL = false;
    static {
        INVOCATION_DEPTH = 2;
        LOGGER.info("Initialize INVOCATION_DEPTH as " + INVOCATION_DEPTH + " for return analysis. ");
        FIELD_DEPTH = 2;
        LOGGER.info("Initialize FIELD_CLONE_DEPTH as " + FIELD_DEPTH + " for instance field clone process. ");
        // 1. When stopping invocation analysis, the return value of the invocation is conservatively set to unknown.
        scene2status.put("RETURN_VALUE_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);
        // 2. For an intra-procedural analysis, if there is not any calling context information, the parameters' statuses
        //    are set to unknown.
        scene2status.put("METHOD_PARAM_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);
        // 3. The status exceeds the depth of an instance status is marked as unknown.
        scene2status.put("FIELD_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);
        // 4. The status of an array element is unknown.
        scene2status.put("ARRAY_ELE_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);
        // 5. When opening a loop, the parameters' statuses of the entry point when performing intra-procedural analysis is set
        //    to unknown.
        scene2status.put("LOOP_ENTRY_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);
        // 6. When no information is provided for a static field, its status is unknown.
        scene2status.put("STATIC_FIELD_DEFAULT_RISK", VarStatus.UNKNOWN_LOW_RISK);

    }

    public static int getInvocationDepth() {
        return INVOCATION_DEPTH;
    }

    public static void setInvocationDepth(int invocationDepth) {
        INVOCATION_DEPTH = invocationDepth;
        LOGGER.info("Change INVOCATION_DEPTH to " + INVOCATION_DEPTH + " for return analysis. ");
    }

    public static int getFieldDepth() {
        return FIELD_DEPTH;
    }

    public static void setFieldDepth(int fieldDepth) {
        FIELD_DEPTH = fieldDepth;
        LOGGER.info("Change FIELD_CLONE_DEPTH to " + FIELD_DEPTH + " for instance field clone process. ");
    }
    public static VarStatus getReturnValueDefaultRisk() {
        return scene2status.get("RETURN_VALUE_DEFAULT_RISK");
    }
    public static VarStatus setReturnValueDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("RETURN_VALUE_DEFAULT_RISK", riskLevel);
    }

    public static VarStatus getMethodParamDefaultRisk() {
        return scene2status.get("METHOD_PARAM_DEFAULT_RISK");
    }

    public static VarStatus setMethodParamDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("METHOD_PARAM_DEFAULT_RISK", riskLevel);
    }

    public static VarStatus getFieldDefaultRisk() {
        return scene2status.get("FIELD_DEFAULT_RISK");
    }

    public static VarStatus setFieldDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("FIELD_DEFAULT_RISK", riskLevel);
    }

    public static VarStatus getArrayEleDefaultRisk() {
        return scene2status.get("ARRAY_ELE_DEFAULT_RISK");
    }

    public static VarStatus setArrayEleDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("ARRAY_ELE_DEFAULT_RISK", riskLevel);
    }

    public static VarStatus getLoopEntryDefaultRisk() {
        return scene2status.get("LOOP_ENTRY_DEFAULT_RISK");
    }

    public static VarStatus setLoopEntryDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("LOOP_ENTRY_DEFAULT_RISK", riskLevel);
    }

    public static VarStatus getStaticFieldDefaultRisk() {
        return scene2status.get("STATIC_FIELD_DEFAULT_RISK");
    }

    public static VarStatus setStaticFieldDefaultRisk(VarStatus riskLevel) {
        return scene2status.put("STATIC_FIELD_DEFAULT_RISK", riskLevel);
    }

    // 7. Library like map.get will definitely return unknown
    public static VarStatus LIBRARY_UNKNOWN_DEFAULT_RISK_LEVEL = VarStatus.UNKNOWN_LOW_RISK;
    // 8. when a method has many version for different subclasses
    public static VarStatus SUBCLASS_METHOD_DEFAULT_RISK_LEVEL = VarStatus.UNKNOWN_LOW_RISK;
}
