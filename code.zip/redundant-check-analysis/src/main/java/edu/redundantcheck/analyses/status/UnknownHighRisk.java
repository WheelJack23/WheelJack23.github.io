package edu.redundantcheck.analyses.status;

// null carriers
public class UnknownHighRisk extends VarStatus{
    private Null nullValue;
    public UnknownHighRisk(Null nullValue) {
        super();
        this.nullValue = nullValue;
        this.nullStatus = VarStatus.Status.UNKNOWN_HIGH_RISK;
        this.field2status = null;
        this.isConstant = true;
    }

    public static UnknownHighRisk getInstance(UnknownHighRisk status) {
        UnknownHighRisk instance = new UnknownHighRisk(status.getNullValue());
        instance.isConstant = false;
        return instance;
    }

    public static UnknownHighRisk getInstance(Null status) {
        UnknownHighRisk instance = new UnknownHighRisk(status);
        instance.isConstant = false;
        return instance;
    }

    public static UnknownHighRisk getConstant(UnknownHighRisk status) {
        UnknownHighRisk constant = new UnknownHighRisk(status.getNullValue());
        return constant;
    }

    public UnknownHighRisk appendTrace(Null.Trace trace) {// copy on write
        Null newNull = nullValue.appendTrace(trace);
        UnknownHighRisk unknownHighRisk = new UnknownHighRisk(newNull);
        unknownHighRisk.isConstant = isConstant;
        return unknownHighRisk;
    }

    public Null getNullValue() {
        return nullValue;
    }
}
