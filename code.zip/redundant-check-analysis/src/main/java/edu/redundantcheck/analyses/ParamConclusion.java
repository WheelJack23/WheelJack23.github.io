package edu.redundantcheck.analyses;

import edu.redundantcheck.analyses.status.Null;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.callgraph.impurity.bean.Var;
import edu.callgraph.impurity.dataflow.InvokeStmt;
import edu.redundantcheck.analyses.nullness.MethodInfo;
import soot.Unit;

import java.util.*;

// record calling context
public class ParamConclusion {
    protected static Map<Node, BaseParamConclusion> conclusions = new HashMap<>();

    public static BaseParamConclusion getConclusion(Node node) {
        BaseParamConclusion baseParamConclusion = conclusions.get(node);
        if (baseParamConclusion != null) conclusions.remove(node);
        return baseParamConclusion;
    }

    public static BaseParamConclusion getAndRetainConclusion(Node node) {
        BaseParamConclusion baseParamConclusion = conclusions.get(node);
        return baseParamConclusion;
    }

    public static boolean updateConclusion(UnitWrapperToNodePair invokeStmtAndNode, DataflowAnalysis analysis) {
        Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit;
        VarStatusInfo infoBeforeCall = analysis.getFlowBefore(unit);
        InvokeStmt invokeStmt = (InvokeStmt) invokeStmtAndNode.getFromInvokeStmt().parsedStmt;
        List<Var> arguments = invokeStmt.args;
        Node invokeNode = invokeStmtAndNode.getToInvokedMethod();
        return updateConclusion(invokeNode, infoBeforeCall, arguments, invokeStmt,
                analysis.declaringClass, unit.getJavaSourceStartLineNumber());
    }
    private static boolean updateConclusion(Node node, VarStatusInfo argumentInfo,
                                           List<Var> argList, InvokeStmt invokeStmt,
                                           String declaringClass, int lineNo) {
        // get base status
        VarStatus baseStatus = null;
        if (invokeStmt.invokeVar != null) {
            baseStatus = argumentInfo.getStatus(invokeStmt.invokeVar.value, VarStatus.NULL);
        }
        BaseParamConclusion baseParamConclusion = conclusions.get(node);
        if (baseParamConclusion == null) {
            baseParamConclusion = new BaseParamConclusion(argList, node);
            conclusions.put(node, baseParamConclusion);
        }
        return baseParamConclusion.updateParamConclusion(argList, argumentInfo, declaringClass, lineNo)
                || baseParamConclusion.updateBaseConclusion(baseStatus);
    }

    public static void setConclusionUnknown(Node node, VarStatus unknownLevel) {
        BaseParamConclusion baseParamConclusion = BaseParamConclusion.getUnknownConclusion(node, unknownLevel);
        conclusions.put(node, baseParamConclusion);
    }

    public static void clear() {
        conclusions.clear();
    }

    public static class BaseParamConclusion {
        private List<VarStatus> paramConclusion;
        private VarStatus baseConclusion;
        public BaseParamConclusion(List<Var> argList, Node node) {
            List<VarStatus> conclusion = new ArrayList<>();
            List<MethodInfo.ParamStatus> paramStatusList = MethodInfo.getAnnotatedParamStatusList(node);
            for (int i = 0 ; i < argList.size(); i++) {
                MethodInfo.ParamStatus paramStatus = MethodInfo.ParamStatus.None;
                if (i < paramStatusList.size()) paramStatus = paramStatusList.get(i);
                if (paramStatus == MethodInfo.ParamStatus.Nullable) {
                    conclusion.add(VarStatus.UNKNOWN_HIGH_RISK);
                    continue;
                }
                conclusion.add(VarStatus.UNKNOWN_DEFAULT);
            }
            paramConclusion = conclusion;
            baseConclusion = null;
        }
        public static BaseParamConclusion getUnknownConclusion(Node node, VarStatus unknownLevel) {
            return new BaseParamConclusion(node.getMethod().getParameterCount(), unknownLevel);
        }
        public BaseParamConclusion(int size, VarStatus status) {
            paramConclusion = new ArrayList<>();
            for (int i = 0 ; i < size ; i++) paramConclusion.add(status);
            baseConclusion = null;
        }

        public List<VarStatus> getParamConclusion() {
            return paramConclusion;
        }

        public VarStatus getBaseConclusion() {
            return baseConclusion;
        }

        public boolean updateBaseConclusion(VarStatus baseStatus) {
            if (baseStatus == null) return false;
            // if it's NON_NULL, it makes no sense because base is non-null for sure.
            if (!VarStatus.isNonNull(baseStatus)) return false;
            if (baseConclusion == null) {
                baseConclusion = baseStatus;
                return true;
            }
            VarStatus originConclusion = baseConclusion;
            baseStatus = getBasicInfo(baseStatus);
            BooleanContainer container = new BooleanContainer();
            baseConclusion = mergeBase(baseStatus, originConclusion, container);
//            return statusContentEqual(originConclusion, baseConclusion, new HashSet<>());
            return container.value;// this will cause dfs visit problems
        }

        private VarStatus getBasicInfo(VarStatus status) {
            VarStatus basic = VarStatus.getNonNullInstance();
            if (VarStatus.isConstants(status)) return basic;
            Map<String, VarStatus> fieldMap = status.getField2status();
            if (fieldMap == null) return basic;
            for (String field: fieldMap.keySet()) {
                VarStatus fieldStatus = fieldMap.get(field);
                if (!VarStatus.isConstants(fieldStatus)) {
                    fieldStatus = VarStatus.NON_NULL;
                }
                basic.setFieldStatus(field, fieldStatus);
            }
            return basic;
        }
        private VarStatus mergeBase(VarStatus newStatus, VarStatus originStatus, BooleanContainer container){
            VarStatus result = VarStatus.getNonNullInstance();
            Map<String, VarStatus> newMap = newStatus.getField2status();
            Map<String, VarStatus> originMap = originStatus.getField2status();
            for (String name: newStatus.getField2status().keySet()) {
                VarStatus fieldStatus1 = newMap.get(name);
                VarStatus fieldStatus2 = originMap.getOrDefault(name, VarStatus.UNKNOWN_LOW_RISK);
                VarStatus mergeResult = VarStatus.mergeNoDepth(fieldStatus1, fieldStatus2);
                container.value |= mergeResult.nullStatus != fieldStatus1.nullStatus;
                result.setFieldStatus(name, mergeResult);
            }
            for (String name: originStatus.getField2status().keySet()) {
                VarStatus fieldStatus1 = newMap.getOrDefault(name, VarStatus.UNKNOWN_LOW_RISK);
                VarStatus fieldStatus2 = originMap.get(name);
                VarStatus mergeResult = VarStatus.mergeNoDepth(fieldStatus1, fieldStatus2);
                container.value |= mergeResult.nullStatus != fieldStatus1.nullStatus;
                result.setFieldStatus(name, mergeResult);
            }
            return result;
        }
        private class BooleanContainer {
            public boolean value;// initialized as false;
        }
        // this method cause too much memory
        private boolean statusContentEqual(VarStatus status1, VarStatus status2, Set<VarStatus.VarStatusPair> pairSet) {
            VarStatus.VarStatusPair pair = new VarStatus.VarStatusPair(status1, status2);
            if (pairSet.contains(pair)) return true; // assume true, because it hasn't returned.
            pairSet.add(pair);
            Map<String, VarStatus> fieldMap1 = status1.getField2status();
            Map<String, VarStatus> fieldMap2 = status2.getField2status();
            if (fieldMap1.size() != fieldMap2.size()) return false;
            for (String field: fieldMap1.keySet()) {
                if (!fieldMap2.containsKey(field)) return false;
                VarStatus fieldStatus1 = fieldMap1.get(field);
                VarStatus fieldStatus2 = fieldMap2.get(field);
                if (VarStatus.isConstants(fieldStatus1) && VarStatus.isConstants(fieldStatus2)) {
                    if (fieldStatus1 == fieldStatus2) continue;
                    return false;
                }
                if (VarStatus.isConstants(fieldStatus1) || VarStatus.isConstants(fieldStatus2)) return false;
                if (!statusContentEqual(fieldStatus1, fieldStatus2, pairSet)) return false;
            }
            return true;
        }

        public boolean updateParamConclusion(List<Var> argList, VarStatusInfo argumentInfo,
                                             String declaringClass, int lineNo) {
            boolean isUpdated = false;
            if (argList.size() != paramConclusion.size()) {
                return false;
            }
            List<VarStatus> argStatusList = new ArrayList<>();
            for (int i = 0 ; i < argList.size();i++) {
                Var var = argList.get(i);
                VarStatus status = argumentInfo.getStatus(var.value, lineNo, declaringClass);
                Null.Trace trace = new Null.Trace(Null.Trace.PASS, declaringClass, lineNo);
                status = VarStatus.appendTrace(status, trace);
                argStatusList.add(status);
            }
            for (int i = 0 ; i < argList.size(); i++) {
                VarStatus newStatus = argStatusList.get(i);
                VarStatus originalStatus = paramConclusion.get(i);
                // NON_NULL
                if (newStatus == VarStatus.UNKNOWN_DEFAULT ||
                        originalStatus.isHighestRiskStatus()) {
                }
                else if (VarStatus.isUnknownRisky(newStatus)) {
                    if (originalStatus == VarStatus.UNKNOWN_DEFAULT
                            || VarStatus.isNonNull(originalStatus)) {
                        paramConclusion.set(i, newStatus);
                        isUpdated = true;
                    }
                    else if (VarStatus.isUnknownRisky(originalStatus)) {
                        VarStatus max = VarStatus.mergeUnknown(originalStatus, newStatus);
                        paramConclusion.set(i, max);
                        isUpdated |= max.nullStatus != originalStatus.nullStatus;
                    }
                    else {// originalStatus == NULL
                        paramConclusion.set(i, VarStatus.highestRisk(originalStatus));
                        isUpdated = true;
                    }
                }
                else if (newStatus.isNull()) {
                    if (originalStatus == VarStatus.UNKNOWN_DEFAULT) {
                        paramConclusion.set(i, newStatus);
                        isUpdated = true;
                    } else if (VarStatus.isNonNull(originalStatus)) {
                        paramConclusion.set(i, VarStatus.highestRisk(newStatus));
                        isUpdated = true;
                    }
                    else if (VarStatus.isUnknownRisky(originalStatus)) {
                        paramConclusion.set(i, VarStatus.highestRisk(newStatus));
                        isUpdated = true;
                    }
                } else {// newStatus == NON_NULL
                    if (originalStatus == VarStatus.UNKNOWN_DEFAULT) {
                        isUpdated = true;
                        VarStatus.cleanCloneMergeInfo();
                        paramConclusion.set(i, newStatus.cloneStatus());
                        VarStatus.cleanCloneMergeInfo();
                    }
                    else if (VarStatus.isUnknownRisky(originalStatus)) {
                    }
                    else if (originalStatus.isNull()) {
                        isUpdated = true;
                        paramConclusion.set(i, VarStatus.highestRisk(originalStatus));
                    }
                    else {// originalStatus == NON_NULL
                        VarStatus.cleanCloneMergeInfo();
                        paramConclusion.set(i, VarStatus.merge(originalStatus, newStatus));
                        VarStatus.cleanCloneMergeInfo();
                        isUpdated |= false;
                    }
                }
            }
            return isUpdated;
        }
    }
}
