package edu.redundantcheck.analyses.analyzer;

import edu.redundantcheck.analyses.result.CombineResult;
import edu.callgraph.impurity.bean.Node;

import java.util.*;

// There are two types of Analyzer, DfsAnalyzer and TopoAnalyzer
// Due to time concern, we use TopoAnalyzer.
public abstract class Analyzer {

    public abstract CombineResult analyzeNodes(List<Node> nodeList);


}
