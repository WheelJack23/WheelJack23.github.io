package edu.redundantcheck.analyses.analyzer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;

public class PercentageCounter {
    private static final Logger LOGGER = LoggerFactory.getLogger(PercentageCounter.class);
    private static DecimalFormat df = new DecimalFormat("#.00");
    private int count, size;
    private double percentage;
    public PercentageCounter(int size) {
        this.size = size;
        count = 0;
        percentage = 0.2;
    }
    public void addCount() {
        count++;
    }

    public boolean reachPercentage() {
        return count * 1.0 / size > percentage || count == size;
    }

    public void addPercentage() {
        percentage += 0.2;
    }

    public String getPercentage() {
        return df.format(percentage * 100);
    }

    public void logInfo() {
        if (reachPercentage()) {
            LOGGER.info("percentage info: " + getPercentage() + "% finished.");
            addPercentage();
        }
    }
}
