package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.SootMethod;
import soot.Value;

import java.util.List;

public class InvokeHelper {
    // When stopping invocation analysis,
    // 1. Invocation has a return value and leftValue is not null,
    //    set the status of leftValue to unknown. consider annotations here.
    // 2. If base's status is non-null instance, set all its field statuses to
    //    unknown. Note that base status has been set to non-null in InvokerExprHandler.
    // 3. For argument's status, if it is unknown already, set it to invocation default risk level,
    //    if it's non-null instance, set its field to unknown,
    //    if it's null, no action would be taken.
    public static void stopInvocationAnalysis(Value leftValue, VarStatusInfo out,
                                              SootMethod method, Value base, List<Value> arguments) {

        if (leftValue != null) {
            setLeftValueStatus(leftValue, out, method);
        }
        if (base != null) {
            setBaseStatus(base, out);
        }
        setArgsStatus(arguments, out);
    }

    public static void setArgsStatus(List<Value> arguments, VarStatusInfo out) {
        VarStatus invocationDefaultStatus = NullnessConfig.getReturnValueDefaultRisk();
        for (Value argVal : arguments) {
            VarStatus argStatus = out.getStatus(argVal, VarStatus.NULL);
            if (VarStatus.isUnknownRisky(argStatus)) {
                if (VarStatus.isConstants(argStatus)) {
                    out.setRawStatus(argVal, invocationDefaultStatus);
                } else {
                    VarStatus unknownInstance = VarStatus.getUnknownInstance(invocationDefaultStatus);
                    out.replace(argStatus, unknownInstance);
                }
            } else if (VarStatus.isNonNull(argStatus)) {
                if (VarStatus.isConstants(argStatus)) {
                    VarStatus instanceStatus = VarStatus.getNonNullInstance();
                    instanceStatus.setField2Unknown(invocationDefaultStatus);
                    out.setRawStatus(argVal, instanceStatus);
                } else {
                    argStatus.setField2Unknown(invocationDefaultStatus);
                }
            }
            // for null, no action would be taken.
        }
    }

    private static void setBaseStatus(Value base, VarStatusInfo out) {
        VarStatus invocationDefaultStatus = NullnessConfig.getReturnValueDefaultRisk();
        VarStatus baseStatus = out.getStatus(base, VarStatus.NULL);
        if (VarStatus.isNonNullInstance(baseStatus)) {
            baseStatus.setField2Unknown(invocationDefaultStatus);
        }
        else {// non-null constant
            VarStatus instanceStatus = VarStatus.getNonNullInstance();
            instanceStatus.setField2Unknown(invocationDefaultStatus);
            out.setRawStatus(base, instanceStatus);
        }
    }

    private static void setLeftValueStatus(Value leftValue, VarStatusInfo out, SootMethod method) {
        VarStatus returnStatus = NullnessConfig.getReturnValueDefaultRisk();
        MethodInfo.ParamStatus annotatedReturnStatus = MethodInfo.getAnnotatedReturnStatus(method);
        if (annotatedReturnStatus != MethodInfo.ParamStatus.None) {
            if (annotatedReturnStatus == MethodInfo.ParamStatus.NonNull) {
                returnStatus = VarStatus.NON_NULL;
            }
            else if (annotatedReturnStatus == MethodInfo.ParamStatus.Nullable) {
                returnStatus = VarStatus.UNKNOWN_HIGH_RISK;
            }
            // else: no other cases here.
        }
        out.setRawStatus(leftValue, returnStatus);
    }
}
