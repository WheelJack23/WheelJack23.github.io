package edu.redundantcheck.analyses.analyzer;

import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapperToNodePair;
import edu.callgraph.impurity.bean.Var;
import edu.callgraph.util.UnitGraphTool;
import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.ParamConclusion;
import edu.redundantcheck.analyses.RedundantAnalysis;
import edu.redundantcheck.analyses.status.VarStatus;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import edu.redundantcheck.analyses.result.CombineResult;
import edu.redundantcheck.analyses.result.ConditionBlock;
import edu.redundantcheck.jdt.ConditionWithRange;
import edu.redundantcheck.jdt.JDTParser;
import edu.redundantcheck.util.Class2PathUtils;
import edu.redundantcheck.util.RepoStatistics;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.Statement;
import soot.Unit;
import soot.jimple.DefinitionStmt;
import soot.jimple.internal.JIfStmt;
import soot.toolkits.graph.UnitGraph;

import java.io.File;
import java.util.*;

public class AnalyzerTool {

    public static String getDeclaringClassFromNode(Node node) {
        String declaringClass = node.getDeclaringClass();
        if (declaringClass != null) return declaringClass;
        String methodFull = node.getMethodSignatureFull();
        return getDeclaringClassFromMethodFull(methodFull);
    }

    public static String getDeclaringClassFromMethodFull(String methodFull) {
        String[] methodParts = methodFull.split("\\.");
        if (methodParts.length == 1) return ""; // case: a method without class name
        StringBuilder sb = new StringBuilder();
        for (int i = 0 ; i < methodParts.length - 2; i++) {
            sb.append(methodParts[i]).append(".");
        }
        sb.append(methodParts[methodParts.length - 2]);
        return sb.toString();
    }

    public static List<VarStatus> getArgStatusList(VarStatusInfo info, List<Var> arguments) {
        List<VarStatus> argStatusList = new ArrayList<>();
        for (int i = 0 ; i < arguments.size(); i++) {
            argStatusList.add(info.getStatus(arguments.get(i).value, VarStatus.NULL));
        }
        return argStatusList;
    }

    // Filter those condition blocks whose condition is not
    // null check. This feature is for redundant null check
    public static List<ConditionWithRange> filterRanges(List<ConditionWithRange> ranges) {
        List<ConditionWithRange> result = new ArrayList<>();
        for (ConditionWithRange range: ranges) {
            if (!containNotNullCheckCondition(range)) {
                result.add(range);
            }
        }
        return result;
    }

    // judge whether the condition is a null check
    // if there is a condition, which is not null check, the condition block should
    // not be certain reachable block or unreachable block.
    private static boolean containNotNullCheckCondition(ConditionWithRange range) {
        Statement statement = range.getStatement();
        if (statement instanceof IfStatement) {
            IfStatement ifStatement = (IfStatement) statement;
            Expression expression = ifStatement.getExpression();
            if (!RepoStatistics.isNullCheck(expression)) return true;
        }
        return false;
    }

    /**
     * units are unreachable units, which is usually sequential in line number.
     * ranges are condition blocks.
     * */
    public static Set<ConditionBlock> matchUnreachableBlocks(Set<Unit> units,
                                                             List<ConditionWithRange> ranges, Node node) {
        if (ranges.size() == 0) {
            return new HashSet<>();
        }
        String javaFilePath = Class2PathUtils.getPath(node.getMethod().getDeclaringClass().getName());
        // get corresponding line number ranges
        List<int []> unitRanges = getUnitRanges(units);

        Set<ConditionBlock> unreachableBlocks = new HashSet<>();
        for (int[] unitRange: unitRanges) {
            addBlockByUnitRange(unitRange, ranges, unreachableBlocks, javaFilePath, node);
        }
        return unreachableBlocks;
    }

    private static void addBlockByUnitRange(int[] unitRange,
                                            List<ConditionWithRange> ranges,
                                            Set<ConditionBlock> unreachableBlocks, String javaFilePath, Node node) {
        ConditionBlock conditionBlock = new ConditionBlock();
        conditionBlock.setJavaFile(new File(javaFilePath));
        conditionBlock.setDeclaringClass(node.getDeclaringClass());
        conditionBlock.setDeclaringMethod(node.getMethodSignatureFull());
        ConditionWithRange bestFit = null;
        int bestDelta = 5;// if the distance of condition start line and unreachable line number range
        // should be less than 5, or the condition block is not corresponding unreachable block.
        // case1: Ideally, unreachable unit block is included in a condition block.
        for (ConditionWithRange range: ranges) {
            int delta = unitRange[0] - range.getStart(); // if the line is in below, line number would be larger.
            if (delta < 0) continue; // lineRange[0] < range.getStart()
            if (delta <= bestDelta && range.getEnd() >= unitRange[1]) { // condition range should include units range.
                bestDelta = delta;
                bestFit = range;
            }
        }
        if (bestFit != null) {
            conditionBlock.setStartLineNo(bestFit.getStart());
            conditionBlock.setEndLineNo(bestFit.getEnd());
            unreachableBlocks.add(conditionBlock);
        }
        else {
            // case2: unreachable units are joined with other unreachable units,
            // so they exceed single condition block. unreachable units range would include one single condition blocks.
            bestDelta = Integer.MAX_VALUE;
            for (ConditionWithRange range: ranges) {
                int delta = unitRange[0] - range.getStart();
                if (delta < 0) continue; // lineRange[0] < range.getStart()
                if (delta <= bestDelta
                        && lineNoAboveOrEq(unitRange[0], range.getEnd())
                        && lineNoAboveOrEq(range.getEnd(), unitRange[1])) {
                    bestDelta = delta;
                    bestFit = range;
                }
            }
            if (bestFit != null) {
                conditionBlock.setStartLineNo(bestFit.getStart());
                conditionBlock.setEndLineNo(bestFit.getEnd());
                unreachableBlocks.add(conditionBlock);
                int[] newUnitRange = new int[]{bestFit.getEnd()+1, unitRange[1]}; // split unreachable unit range into two parts
                addBlockByUnitRange(newUnitRange, ranges, unreachableBlocks, javaFilePath, node); // handle the part left.
            }
        }
    }

    /**
     * Compare line number, small one is above, large one is below.
     * */
    private static boolean lineNoAboveOrEq(int lineA, int lineB) {
        return lineA <= lineB;
    }

    /**
     * units are certain reachable units, usually they are not sequential in line number.
     * ranges are condition blocks.
     * */
    public static Set<ConditionBlock> matchReachableBlocks(Set<Unit> units,
                                                           List<ConditionWithRange> ranges, Node node,
                                                           Set<ConditionBlock> unreachableBlocks) {
        if (ranges.size() == 0) {
            return new HashSet<>();
        }
        String javaFilePath = Class2PathUtils.getPath(node.getMethod().getDeclaringClass().getName());
        // match
        Set<ConditionBlock> reachableBlocks = new HashSet<>();
        for (Unit unit: units) {
            int lineNo = unit.getJavaSourceStartLineNumber();
            ConditionBlock conditionBlock = new ConditionBlock();
            conditionBlock.setJavaFile(new File(javaFilePath));
            conditionBlock.setDeclaringClass(node.getDeclaringClass());
            conditionBlock.setDeclaringMethod(node.getMethodSignatureFull());
            ConditionBlock[] bestNeighbors = findBestNeighbors(unreachableBlocks, unit);
            // 2. Find the nearest conditional block that contains the statement
            ConditionWithRange bestFitBlock = findBestFitBlock(ranges, unit);
            if (bestFitBlock != null) {
                if (blockContain(bestFitBlock, bestNeighbors)) continue;
                // As long as bestFitBlock doesn't contain the upper and lower blocks.
                conditionBlock.setStartLineNo(bestFitBlock.getStart());
                conditionBlock.setEndLineNo(bestFitBlock.getEnd());
                reachableBlocks.add(conditionBlock);
            }
        }
        return reachableBlocks;
    }

    // Check that bestFitBlock contains two neighbors
    private static boolean blockContain(ConditionWithRange bestFitBlock, ConditionBlock[] bestNeighbors) {
        for (ConditionBlock neighbor: bestNeighbors) {
            if (neighbor != null
                    && bestFitBlock.getStart() < neighbor.getStartLineNo()
                    && bestFitBlock.getEnd() > neighbor.getEndLineNo()) return true;
        }
        return false;
    }

    // 1. Find the nearest conditional block whose result leads to the following reachable statement.
    // So the relationship between two blocks is necessarily mutually exclusive. Or maybe not.
    private static ConditionBlock[] findBestNeighbors(Set<ConditionBlock> ranges, Unit unit) {
        ConditionBlock[] bestNeighbors = new ConditionBlock[2]; // One is above Unit and one is below Unit
        // Find the last point closest to unit.
        int lineNo = unit.getJavaSourceStartLineNumber();
        // 1. 找距离unit最近的上面的ConditionRange
        int bestDelta = Integer.MAX_VALUE;
        ConditionBlock bestNeighborBlock = null;
        for (ConditionBlock range: ranges) {
            int delta = lineNo - range.getEndLineNo();
            if (delta > 0 && delta < bestDelta) {
                bestDelta = delta;
                bestNeighborBlock = range;
            }
        }
        bestNeighbors[0] = bestNeighborBlock;
        // 2. Find the next ConditionRange that's closest to the Unit
        bestNeighborBlock = null;
        bestDelta = Integer.MAX_VALUE;
        for (ConditionBlock range: ranges) {
            int delta = range.getStartLineNo() - lineNo;
            if (delta > 0 && delta < bestDelta) {
                bestDelta = delta;
                bestNeighborBlock = range;
            }
        }
        bestNeighbors[1] = bestNeighborBlock;
        return bestNeighbors;
    }

    private static ConditionWithRange findBestFitBlock(List<ConditionWithRange> ranges, Unit unit) {
        int lineNo = unit.getJavaSourceStartLineNumber();
        ConditionWithRange bestFitBlock = null;
        ConditionWithRange secondBestFitBlock = null;
        int bestDelta = Integer.MAX_VALUE;
        for (ConditionWithRange range: ranges) {
            int delta = lineNo - range.getStart();
            if (delta < 0) continue;
            if (delta <= bestDelta && range.getEnd() >= lineNo) {
                secondBestFitBlock = bestFitBlock;
                bestDelta = delta;
                bestFitBlock = range;
            }
        }
        if (bestFitBlock != null) {
            if (bestFitBlock.getStart() != lineNo) {
                secondBestFitBlock = bestFitBlock;
                bestFitBlock = null;
            }
        }
        if (unit instanceof JIfStmt) {
            return secondBestFitBlock;
        }
        else if (unit instanceof DefinitionStmt
                && ((DefinitionStmt) unit).containsFieldRef()
                && bestFitBlock != null && bestFitBlock.getStart() == lineNo) {

            return secondBestFitBlock;
        }
        else {
            if (bestFitBlock == null) {
                return secondBestFitBlock;
            }
            return bestFitBlock;
        }
    }

    private static List<int []> getUnitRanges(Set<Unit> units) {
        List<Integer> lineNums = new ArrayList<>();
        for (Unit unit: units) {
            if (unit == null) {
                continue;
            }
            lineNums.add(unit.getJavaSourceStartLineNumber());
        }
        Collections.sort(lineNums);
        List<int []> ranges = new ArrayList<>();
        if (lineNums.size() == 0) return ranges;
        if (lineNums.size() == 1) {
            ranges.add(new int[] {lineNums.get(0), lineNums.get(0)});
            return ranges;
        }
        int begin = lineNums.get(0);
        int end = lineNums.get(0);
        for (int i = 1; i < lineNums.size(); i++) {
            int current = lineNums.get(i);
            int delta = current - end;
            if (delta == 0 || delta == 1) {
                end = current;
                if (i == lineNums.size() - 1) {
                    ranges.add(new int[] {begin, end});
                }
                continue;
            }
            ranges.add(new int[] {begin, end});
            begin = current;
            end = current;
        }
        return ranges;
    }

    public static void updateCalleeParamConclusion(Node node,
                                                   DataflowAnalysis dataflowAnalysis) {
        Set<Unit> notReachableSet = dataflowAnalysis.getNotReachableSet();
        List<UnitWrapperToNodePair> invokeStmtAndNodes = node.getUnitToNodePairList();
        if (invokeStmtAndNodes == null || invokeStmtAndNodes.size() == 0) return;
        for (UnitWrapperToNodePair invokeStmtAndNode: invokeStmtAndNodes) {
            Unit unit = invokeStmtAndNode.getFromInvokeStmt().unit;
            if (notReachableSet.contains(unit)) {
                continue;
            }
            ParamConclusion.updateConclusion(invokeStmtAndNode, dataflowAnalysis);
        }
    }

    public static List<Node> getRootNodes(List<Node> nodes) {
        Map<Node, Integer> indegrees = getIndegrees(nodes);
        List<Node> rootNodes = new ArrayList<>();
        for (Node node: nodes) {
            if (indegrees.getOrDefault(node, 0) == 0) {
                rootNodes.add(node);
            }
        }
        rootNodes.sort(Comparator.comparing(Node::getMethodSignatureFull));
        return rootNodes;
    }

    public static Map<Node, Integer> getIndegrees(List<Node> nodes) {
        Map<Node, Integer> indegrees = new HashMap<>();
        for (Node node: nodes) {
            if (node.getChildren() == null) continue;
            for (AbstractNode child: node.getChildren()) {
                Node c = (Node) child;
                Integer indegree = indegrees.getOrDefault(c, 0);
                indegrees.put(c, indegree+1);
            }
        }
        return indegrees;
    }

    public static void unvisited(Collection<Node> nodes) {
        for (Node node: nodes) node.isVisited = false;
    }

    public static RedundantAnalysis analyzeNode(Node node, CombineResult result) {
        UnitGraph unitGraph = UnitGraphTool.getUnitGraphFromNode(node);
        if (unitGraph == null) return null;
        ParamConclusion.BaseParamConclusion baseParamConclusion = ParamConclusion.getConclusion(node);
        RedundantAnalysis redundantAnalysis =
                new RedundantAnalysis(unitGraph, baseParamConclusion,
                        node.getMethod().getParameterCount(), node.getMethod().getDeclaringClass().getShortName());
        return addResult(redundantAnalysis, node, result);
    }

    public static RedundantAnalysis addResult(RedundantAnalysis analysis, Node node, CombineResult result) {
        List<ConditionWithRange> conditionWithRanges = JDTParser.getConditionRangesFromPath(
                Class2PathUtils.getPath(node.getDeclaringClass()));
        conditionWithRanges = filterRanges(conditionWithRanges);
        Set<Unit> notReachableSet = analysis.getNotReachableSet();
        Set<Unit> certainReachableSet = analysis.getCertainReachableSet();

        Set<ConditionBlock> unreachableBlocks = new HashSet<>();
        if (!notReachableSet.isEmpty()) {
            unreachableBlocks = matchUnreachableBlocks(notReachableSet, conditionWithRanges, node);
            result.getUnreachableBlocks().addAll(unreachableBlocks);
        }
        Set<ConditionBlock> certainReachableBlocks = new HashSet<>();
        if (!certainReachableSet.isEmpty()) {
            certainReachableBlocks = matchReachableBlocks(certainReachableSet, conditionWithRanges, node, unreachableBlocks);
            result.getCertainReachableBlocks().addAll(certainReachableBlocks);
        }
        return analysis;
    }
}
