package edu.redundantcheck.analyses.result;

import java.io.File;

// condition blocks
public class ConditionBlock {
    private String declaringClass;
    private String declaringMethod;
    private int startLineNo;
    private int endLineNo;
    private File javaFile;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConditionBlock that = (ConditionBlock) o;

        if (startLineNo != that.startLineNo) return false;
        if (endLineNo != that.endLineNo) return false;
        if (!declaringClass.equals(that.declaringClass)) return false;
        return declaringMethod.equals(that.declaringMethod);
    }

    @Override
    public int hashCode() {
        int result = declaringClass.hashCode();
        result = 31 * result + declaringMethod.hashCode();
        result = 31 * result + startLineNo;
        result = 31 * result + endLineNo;
        return result;
    }

    @Override
    public String toString() {
        return "{\n" +
                "\t\"declaringClass\": \"" + declaringClass + "\"" +
                ",\n\t\"declaringMethod\": \"" + declaringMethod + "\"" +
                ",\n\t\"startLineNo\": " + startLineNo +
                ",\n\t\"endLineNo\": " + endLineNo +
                "\n}";
    }

    public File getJavaFile() {
        return javaFile;
    }

    public void setJavaFile(File javaFile) {
        this.javaFile = javaFile;
    }

    public String getDeclaringClass() {
        return declaringClass;
    }

    public void setDeclaringClass(String declaringClass) {
        this.declaringClass = declaringClass;
    }

    public String getDeclaringMethod() {
        return declaringMethod;
    }

    public void setDeclaringMethod(String declaringMethod) {
        this.declaringMethod = declaringMethod;
    }

    public int getStartLineNo() {
        return startLineNo;
    }

    public void setStartLineNo(int startLineNo) {
        this.startLineNo = startLineNo;
    }

    public int getEndLineNo() {
        return endLineNo;
    }

    public void setEndLineNo(int endLineNo) {
        this.endLineNo = endLineNo;
    }
}
