package edu.redundantcheck.analyses.analyzer;

import edu.callgraph.impurity.bean.Node;
import edu.redundantcheck.analyses.RedundantAnalysis;
import edu.redundantcheck.analyses.result.CombineResult;
import edu.redundantcheck.util.GlobalCleaner;

import java.util.List;

public class TopoAnalyzerSimple extends Analyzer {
    @Override
    public CombineResult analyzeNodes(List<Node> nodeList) {
        GlobalCleaner.clean();
        CombineResult result = new CombineResult();
        GraphIterator graphIterator = new GraphIterator(nodeList);
        while (graphIterator.hasNext()) {
            Node node = graphIterator.next();
            System.out.println("start to analyze " + node.getMethodSignatureFull());
            RedundantAnalysis analysis = AnalyzerTool.analyzeNode(node, result);

            if (analysis != null) AnalyzerTool.updateCalleeParamConclusion(node, analysis);
        }
        return result;
    }
}
