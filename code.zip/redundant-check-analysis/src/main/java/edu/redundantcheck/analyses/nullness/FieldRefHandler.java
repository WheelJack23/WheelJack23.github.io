package edu.redundantcheck.analyses.nullness;

import edu.redundantcheck.analyses.DataflowAnalysis;
import edu.redundantcheck.analyses.status.VarStatusInfo;
import soot.Value;
import soot.jimple.FieldRef;
import soot.jimple.InstanceFieldRef;

public class FieldRefHandler {
    public static void handle(FieldRef fieldRef, VarStatusInfo out,
                              DataflowAnalysis analysisInfo) {
        if (fieldRef instanceof InstanceFieldRef) {
            InstanceFieldRef instanceFieldRef = (InstanceFieldRef) fieldRef;
            // here we know that the receiver must point to an object
            Value base = instanceFieldRef.getBase();
            out.setNonNull(base, analysisInfo);
        }
    }
}
