package edu.callgraph;

import edu.callgraph.global.Config;
import edu.callgraph.global.Global;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.tagkit.SignatureTag;
import soot.tagkit.Tag;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SootUtil {
    public static List<String> generics;
    private static void initGenerics(SootClass sootClass){
        if(sootClass.getTags() == null){
            generics = null;
        }else {
            generics = new ArrayList<>();
            List<Tag> tags = sootClass.getTags();
            for(Tag t:tags){
                if(t instanceof SignatureTag){
                    SignatureTag st = (SignatureTag)t;
                    String sig = st.getSignature();
                    Pattern pat = Pattern.compile("<(.*?)>");
                    Matcher matcher = pat.matcher(sig);
                    String a = null;
                    while(matcher.find()){
                        a = matcher.group(1);
                        break;
                    }
                    if(a!=null){
                        String[] data = a.split(";");
                        for(String d:data){
                            String[] data2 = d.split(":");
                            generics.add(data2[0]);
                        }
                    }
                }
            }
        }

    }

    public static Map<String,SootMethod> getSootMethodSignatureMap(SootClass sootClass) {
        initGenerics(sootClass);
        Map<String,SootMethod> sigToMethodMap = new HashMap<>();
        Iterator<SootMethod> iter = sootClass.methodIterator();
        while (iter.hasNext()) {
            SootMethod sootMethod = iter.next();
            String sootSig = SootMethodToString.getSootMethodSignatureName(sootMethod,true);
            sigToMethodMap.put(sootSig,sootMethod);
        }
        return sigToMethodMap;
    }

    public static List<SootMethod> loadEntryPoints(Map<String, List<String>> mmap) {
        List<SootMethod> entryPoints = new ArrayList();
        for (String clazzName : mmap.keySet()) {
            SootClass sootClass = Scene.v().loadClassAndSupport(clazzName);
            sootClass.setApplicationClass();
            Scene.v().loadNecessaryClasses();
            Map<String,SootMethod> sootSignatureToSootMethodMap = getSootMethodSignatureMap(sootClass);
            List<String> methods = mmap.get(clazzName);
            for (String methodKey : methods){
                String trimmedMethodKey = SootMethodToString.transParameterLongNameToShortName(methodKey);
                trimmedMethodKey = transformConstructor(trimmedMethodKey);
                if(sootSignatureToSootMethodMap.containsKey(trimmedMethodKey)){
                    SootMethod sootMethod = sootSignatureToSootMethodMap.get(trimmedMethodKey);
                    entryPoints.add(sootMethod);
                }
            }

        }
        return entryPoints;
    }

    public static List<SootMethod> loadEntryPointsByClass(Set<String> classSet) {
        List<SootMethod> entryPoints = new ArrayList();
        for (String clazzName : classSet) {
            SootClass sootClass = Scene.v().loadClassAndSupport(clazzName);
            sootClass.setApplicationClass();
            Scene.v().loadNecessaryClasses();
            Map<String, SootMethod> sootSignatureToSootMethodMap = getSootMethodSignatureMap(sootClass);
            for (SootMethod sootMethod : sootSignatureToSootMethodMap.values()) {
                if (! sootMethod.isPrivate()) {
                    try {
                        sootMethod.retrieveActiveBody();
                    }catch(RuntimeException re){
                        if (Config.LOG_SWITCH) {
                            Global.setLogger(SootUtil.class);
                            Global.logger.error("Retrieval method body error");
                        }
                    }
                    entryPoints.add(sootMethod);
                }
            }
        }
        return entryPoints;
    }

    private static boolean isConstructMethod(String className, String methodName) {
        String simpleClassName = className.split("\\.")[className.split("\\.").length - 1];
        String simpleMethodName = methodName.split("\\.")[methodName.split("\\.").length - 1];
        return simpleMethodName.startsWith(simpleClassName + "(");
    }

    public static String transformConstructor(String methodKey) {
        String[] parts = methodKey.split("\\(");
        String packageClassMethod = parts[0];
        String params = parts[1];
        parts = packageClassMethod.split("\\.");
        String className = parts[parts.length - 2];
        String methodName = parts[parts.length - 1];
        if (className.equals(methodName)) {
            return methodKey.replace(methodName + "(", "<init>(");
        }
        return methodKey;
    }
}