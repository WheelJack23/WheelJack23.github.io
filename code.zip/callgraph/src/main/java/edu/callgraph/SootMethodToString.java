package edu.callgraph;

import edu.callgraph.global.Global;
import soot.SootMethod;
import soot.Type;

import java.util.List;

public class SootMethodToString {
    public static String getSootMethodSignatureName(SootMethod sootMethod, boolean isShortName){
        return getSootMethodSignatureName(sootMethod, isShortName, Global.handleInner);
    }

    public static String getSootMethodSignatureName(SootMethod sootMethod, boolean isShortName, boolean handleInner){
        List<Type> params = sootMethod.getParameterTypes();
        StringBuilder sb = new StringBuilder();
        if(params== null || params.size()==0){
            sb.append("()");
        }else {
            sb.append("(");
            for (Type t : params) {
                String name = getNameOfType(t.toString(),isShortName);
                sb.append(transformParam(name, handleInner));
                sb.append(",");
            }
            sb.deleteCharAt(sb.length() - 1);
            sb.append(")");
        }
        String name = sootMethod.getDeclaringClass().getName() + "." + sootMethod.getName() + sb.toString();
        return name;
    }

    public static String transformParam(String param, boolean handleInner) {
        if (!handleInner) return param;
        if (!param.contains("$")) return param;
        else {
            String[] parts = param.split("\\$");
            return parts[parts.length-1];
        }
    }

    private static String getNameOfType(String s, boolean isShortName){
        if(isShortName){
            int index = s.lastIndexOf(".");
            String shortName = s.substring(index+1);
            return shortName;
        }
        return s;
    }

    public static String transParameterLongNameToShortName(String methodFullSignatureName){
        StringBuilder sb = new StringBuilder();
        if(methodFullSignatureName.endsWith(")")){
            methodFullSignatureName = methodFullSignatureName.substring(0,methodFullSignatureName.length()-1);
        }
        String[] data = methodFullSignatureName.split("\\(");
        String methodFullName = data[0];
        sb.append(methodFullName);
        sb.append("(");
        if(data.length != 1) {
            String[] params = data[1].split(",");

            for (String param : params) {
                if (param.contains(".")) {
                    String[] paramData = param.split("\\.");
                    sb.append(paramData[paramData.length - 1]);
                    sb.append(",");
                }else{
                    sb.append(param);
                    sb.append(",");
                }
            }
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append(")");
        return sb.toString();


    }

}
