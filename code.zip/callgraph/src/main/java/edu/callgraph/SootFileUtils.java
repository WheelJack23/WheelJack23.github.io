package edu.callgraph;

import com.alibaba.fastjson.JSONArray;
import soot.util.dot.DotGraph;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SootFileUtils {

    public static void toFile(String dotPath, DotGraph dg) {
        File file = new File(dotPath);
        OutputStream out;
        try {
            out = new FileOutputStream(file);
            dg.render(out, 0);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static Map<String, List<String>> getClassNameAndMethodNames(JSONArray methodNames, List<String> classNames) {
        classNames.clear();
        Map<String, List<String>> mMap = new HashMap<>();
        for (Object jo : methodNames) {
            String s = (String) jo;
            if(!s.contains("(")){
                continue;
            }
            int leftBrac = s.indexOf('(');
            String subS = s.substring(0, leftBrac);
            int classMethodSplit = subS.lastIndexOf('.');
            String className = s.substring(0, classMethodSplit);
            if(!mMap.containsKey(className)){
                mMap.put(className,new ArrayList<>());
            }
            mMap.get(className).add(s);
        }
        return mMap;

    }

    public static Map<String, List<String>> getClassNameAndMethodNames(String methodNameString, List<String> classNames) {
        classNames.clear();
        Map<String, List<String>> mMap = new HashMap<>();

        String s = methodNameString;
        int index2 = s.indexOf('(');
        String subS = s.substring(0, index2);
        int index = subS.lastIndexOf('.');
        String className = s.substring(0, index);
        String methodName = s.substring(0, index2);
        String params = s.substring(index2);
        initClassNames(classNames, className);

        for (String tempClassName : classNames) {
            String keyMethodParams = methodName + "---" + params;
            if (mMap.containsKey(tempClassName)) {
                if (!mMap.get(tempClassName).contains(keyMethodParams)) {
                    mMap.get(tempClassName).add(keyMethodParams);
                }
            } else {
                List<String> a = new ArrayList();
                mMap.put(tempClassName, a);
                mMap.get(tempClassName).add(keyMethodParams);
            }
        }


        return mMap;

    }

    private static void initClassNames(List<String> classNames, String className) {
        classNames.add(className);
        while (true) {
            int index = className.lastIndexOf(".");
            if (index == -1) {
                break;
            }
            StringBuilder classNameSb = new StringBuilder(className);
            classNameSb.replace(index, index + 1, "$");
            classNames.add(classNameSb.toString());
            className = classNameSb.toString();
        }

    }
}
