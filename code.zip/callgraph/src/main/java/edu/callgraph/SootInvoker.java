package edu.callgraph;

import com.alibaba.fastjson.JSONArray;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.dataclass.CallGraphBean;
import edu.callgraph.global.Config;
import edu.callgraph.util.OSRelated;
import edu.callgraph.global.Global;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.tagkit.AnnotationTag;
import soot.tagkit.Tag;
import soot.tagkit.VisibilityAnnotationTag;

import java.util.*;
public class SootInvoker {
    private static final Logger LOGGER = LoggerFactory.getLogger(SootInvoker.class);

    public static CallGraphBean build(String jarPath, JSONArray methodNames, String outputPath) {
        String classesPath = jarPath;
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> classToMethodMap = SootFileUtils.getClassNameAndMethodNames(methodNames, classNames);
        G.reset();
        List<String> argsList = new ArrayList<>();
        String libsAll = "./lib/rt.jar:./lib/jasmin-3.0.1.jar:./lib/java_cup-0.9.2.jar:" +
                "./lib/polyglot-2006.jar:./lib/soot-3.3.0.jar";
        if (OSRelated.isWindows()) {
            libsAll = libsAll.replaceAll(":", ";");
        }
        argsList.addAll(Arrays.asList(new String[]{
                "-allow-phantom-refs",
                "-w",
                "-keep-line-number", "enabled",
                "-cp", libsAll,
                "-process-dir",
                classesPath,}));
        String[] args;
        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_keep_line_number(true);
        Options.v().set_verbose(true);
        Options.v().set_keep_line_number(true);
        Options.v().setPhaseOption("cg", "all-reachable:true");
        Options.v().set_no_bodies_for_excluded(true);
        Options.v().set_app(true);
        List llo = Options.v().classes();
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classToMethodMap);
        if (Config.LOG_SWITCH) {
            if (entryPoints.size() != methodNames.size()) {
                LOGGER.error("No entrypoint found");
            }
        }
        Scene.v().setEntryPoints(entryPoints);

        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        if (!Config.SPARK_ENABLE) CHATransformer.v().transform();
        else SparkTransformer.v().transform();

        CallGraph callGraph = Scene.v().getCallGraph();
        CallGraphBean callGraphBean = new CallGraphBean(callGraph);
        for (SootMethod sootMethod : entryPoints) {
            Node newNode = Node.createNodeInstance(sootMethod);
            if (newNode != null) {
                callGraphBean.addCiaMethod(newNode);
            }
        }
        return callGraphBean;
    }


    private static SootClass loadClass(String name, boolean main) {
        SootClass c = Scene.v().loadClassAndSupport(name);
        c.setApplicationClass();
        if (main)
            Scene.v().setMainClass(c);
        return c;
    }


    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }


    public static CallGraphBean build3(List<String> jarPath, JSONArray methodNames) {
        Global.clear();
        preProcess(jarPath); // initialize soot arguments.
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNames, classNames);
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(mmap);
        if (entryPoints.size() == 0) {
            LOGGER.error("No entrypoint found");
        }
        else if (entryPoints.size() < methodNames.size()) {
            int loss = methodNames.size() - entryPoints.size();
            LOGGER.error(loss + " entry points lost.");
        }

        Scene.v().setEntryPoints(entryPoints);

        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        if (!Config.SPARK_ENABLE) CHATransformer.v().transform();
        else SparkTransformer.v().transform();

        LOGGER.info("Start to generate Soot native call graph...");
        CallGraph callGraph = Scene.v().getCallGraph(); // main graph
        LOGGER.info("generate Soot native call graph successfully!");

        CallGraphBean callGraphBean = new CallGraphBean(callGraph); // customized wrapping
        for (SootMethod sootMethod : entryPoints) {
            Node newNode = Node.createNodeInstance(sootMethod);
            if (newNode != null) {
                callGraphBean.addCiaMethod(newNode);
            }
        }
        return callGraphBean;
    }

    public static CallGraphBean build3(List<String> jarPath, JSONArray methodNames, boolean byClass) {
        Global.clear();
        preProcess(jarPath); // initialize soot arguments.
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNames, classNames);
        List<SootMethod> entryPoints = null;
        if (byClass) entryPoints = SootUtil.loadEntryPointsByClass(mmap.keySet());
        else {
            entryPoints = SootUtil.loadEntryPoints(mmap);
            if (entryPoints.size() == 0) {
                LOGGER.error("No entrypoint found");
            }
            else if (entryPoints.size() < methodNames.size()) {
                int loss = methodNames.size() - entryPoints.size();
                LOGGER.error(loss + " entry points lost.");
            }
        }
        entryPoints = filterDeprecated(entryPoints);
        LOGGER.info("Load " + entryPoints.size() + " entry points.");
        Scene.v().setEntryPoints(entryPoints);

        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        if (!Config.SPARK_ENABLE) CHATransformer.v().transform();
        else SparkTransformer.v().transform();

        LOGGER.info("Start to generate Soot native call graph...");
        CallGraph callGraph = Scene.v().getCallGraph(); // main graph
        LOGGER.info("generate Soot native call graph successfully!");

        CallGraphBean callGraphBean = new CallGraphBean(callGraph); // customized wrapping
        for (SootMethod sootMethod : entryPoints) {
            Node newNode = Node.createNodeInstance(sootMethod);
            if (newNode != null) {
                callGraphBean.addCiaMethod(newNode);
            }
        }
        return callGraphBean;
    }

    private static List<SootMethod> filterDeprecated(List<SootMethod> entryPoints) {
        List<SootMethod> result = new LinkedList<>();
        for (SootMethod method: entryPoints) {
            if (!isDeprecated(method)) result.add(method);
        }
        return result;
    }


    public static boolean isDeprecated(SootMethod method) {
        List<Tag> tags = method.getTags();
        for (Tag tag: tags) {
            if (tag instanceof VisibilityAnnotationTag) {
                List<AnnotationTag> annotations = ((VisibilityAnnotationTag) tag).getAnnotations();
                for (AnnotationTag annotation: annotations) {
                    if (isDeprecated(annotation)) return true;
                }
            }
        }
        return false;
    }

    private static boolean isDeprecated(AnnotationTag annotation) {
        String annotationStr = annotation.getType().toLowerCase();
        return annotationStr.contains("deprecated");
    }

    public static CallGraphBean build3(List<String> jarPath, List<SootMethod> sootMethods){
        preProcess(jarPath);
        Scene.v().setEntryPoints(sootMethods);

        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        if (!Config.SPARK_ENABLE) CHATransformer.v().transform();
        else SparkTransformer.v().transform();

        CallGraph callGraph = Scene.v().getCallGraph();
        CallGraphBean callGraphBean = new CallGraphBean(callGraph);
        for (SootMethod sootMethod : sootMethods) {
            Node newNode = Node.createNodeInstance(sootMethod);
            if (newNode != null) {
                callGraphBean.addCiaMethod(newNode);
            }
        }
        return callGraphBean;
    }

    private static void preProcess(List<String> jarPath){
        G.reset();
        List<String> argsList = new ArrayList<>();
        String libsAll = Config.JAR_PATH;
        argsList.addAll(Arrays.asList(new String[]{
                "-allow-phantom-refs",
                "-w",
                "-keep-line-number", "enabled",
                // "-no-bodies-for-excluded",
                "-cp", libsAll}));
        for (String s : jarPath) {
            argsList.add("-process-dir");
            argsList.add(s);
        }
        argsList.addAll(Arrays.asList(new String[]{"-p", "jb", "use-original-names:true"}));
        String[] args;
        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_keep_line_number(true);
        Options.v().set_verbose(true);
        Options.v().set_keep_line_number(true);
        Options.v().setPhaseOption("cg", "all-reachable:true");
        Options.v().set_no_bodies_for_excluded(true);
        Options.v().set_app(true);
        if (Config.SPARK_ENABLE) enableSpark();
        List llo = Options.v().classes();
    }
}

