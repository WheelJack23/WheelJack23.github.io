package edu.callgraph.global;

import edu.callgraph.SootMethodToString;
import edu.callgraph.impurity.bean.Node;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import soot.SootMethod;
import soot.jimple.toolkits.callgraph.CallGraph;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

public class Global {
    public static CallGraph callGraph = null;

    public static int nodeCounter =0 ;

    public static int treeConrolCount = 0;

    public static Logger logger ;

    public static boolean handleInner = false;

    public static void setLogger(Class clazzName){
        logger = Logger.getLogger(clazzName.getSimpleName());
    }

    public static void initLogger(){
        if(Config.LOG_FILE_DIR !=null) {
            File file = new File(Config.LOG_FILE_DIR + "/log4j.properties");
            if (file.exists()) {
                PropertyConfigurator.configure(Config.LOG_FILE_DIR + "/log4j.properties");
                setLogger(Global.class);
            } else {
                BasicConfigurator.configure();
            }
        }
    }

    public static List<SootMethod> sootMethodAll = new ArrayList<>();

    public static Map<SootMethod, Node> nodeAll = new HashMap<>();

    public static Set<Node> nodeSet = new HashSet<>();

    public static void clear() {
        nodeCounter =0;
        treeConrolCount = 0;
        sootMethodAll.clear();
        nodeAll.clear();
        nodeSet.clear();
    }

    public static void outputNodes(String fileName, List<SootMethod> methods) {
        File file = new File("files/" + fileName);
        try {
            PrintWriter output = new PrintWriter(file);
            for (SootMethod method: methods) {
                output.println(SootMethodToString.getSootMethodSignatureName(method, true, true));
            }
            output.close();
        } catch (FileNotFoundException e) {
            System.err.println("output failed!");
        }
    }
}
