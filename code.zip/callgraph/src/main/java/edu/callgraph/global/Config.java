package edu.callgraph.global;

import java.util.Properties;


public class Config {

    public static Properties CONFIG;
    public static String OUTPUT_ROOT;

    public static String CONFIG_FILE_PATH;
    public static String LOG_FILE_DIR;
    public static String JAVA_DOC_PATH;
    public static String JAR_PATH;
    public static boolean LOG_SWITCH;
    public static boolean SPARK_ENABLE;
    public static boolean SHOW_ALL_JARS_IN_PROJECT;
    public static boolean SHOW_JARS_EXCLUDED;
    public static boolean SHOW_JARS_RESERVED;

    public static boolean IGNORE_JDK = true;

    public static void setConfig(String outputRoot, String configFile) {
//        OUTPUT_ROOT = outputRoot;
//        CONFIG_FILE_PATH = configFile;
//        File configFileFile = new File(configFile);
//        LOG_FILE_DIR = configFileFile.getParentFile().getAbsolutePath();
//        CONFIG = PropertyUtil.readProperty(CONFIG_FILE_PATH);

    }


}
