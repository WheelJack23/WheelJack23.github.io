package edu.callgraph;

import com.alibaba.fastjson.JSONArray;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.archivetransform.Transformer;
import edu.callgraph.dataclass.CallGraphBean;
import edu.callgraph.global.Config;
import edu.callgraph.global.Global;
import edu.callgraph.impurity.vis.InitGraphNodeVisitor;
import edu.callgraph.impurity.vis.SetNodeMethodNameVisitor;
import edu.callgraph.util.CGCleaner;
import edu.callgraph.util.MultiModuleTool;
import edu.callgraph.util.PersistUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import soot.SootMethod;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CallGraphMain {
    private static final Logger LOGGER = LoggerFactory.getLogger(CallGraphMain.class);

    public CallGraphMain(String javaDocPath,String logFilePath, String jarPath){
        Config.JAVA_DOC_PATH = javaDocPath; 
        Config.LOG_FILE_DIR = logFilePath;
        Config.JAR_PATH = jarPath;
        Global.initLogger();
    }

    public CallGraphBean generateCallGraph(JSONArray jMethods, String jarPath){
        CGCleaner.clean();
        return generateCallGraph(jMethods, jarPath, false);
    }

    public CallGraphBean generateCallGraphByClass(JSONArray jMethods, String jarPath){
        CGCleaner.clean();
        return generateCallGraph(jMethods, jarPath, true);
    }

    private CallGraphBean generateCallGraph(JSONArray jMethods, String jarPath, boolean byClass){
        CGCleaner.clean();
        if (Transformer.isSpringbootJar(jarPath)) {
            try {
                jarPath = Transformer.transformSpringbootJarInParent(jarPath).getAbsolutePath();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        List<String> path = new ArrayList<>();
        path.add(jarPath);
        CallGraphBean callGraphBean = SootInvoker.build3(path, remove(jMethods), byClass);
        return analysisCallGraphBean(callGraphBean);
    }

    public CallGraphBean generateCallGraphForSingleWar(JSONArray jMethods, String warPath) throws IOException {
        CGCleaner.clean();
        String jarPath = Transformer.transformWarInParent(warPath).getAbsolutePath();
        return generateCallGraph(jMethods, jarPath, false);
    }

    public CallGraphBean generateCallGraphForSingleWarByClass(JSONArray jMethods, String warPath) throws IOException {
        CGCleaner.clean();
        String jarPath = Transformer.transformWarInParent(warPath).getAbsolutePath();
        return generateCallGraph(jMethods, jarPath, true);
    }

    public CallGraphBean generateCallGraphForMultiModule(String[] methodNames, String projectPath) {
        CGCleaner.clean();
        return generateCallGraphForMultiModule(methodNames, projectPath, false);
    }

    public CallGraphBean generateCallGraphForMultiModuleByClass(String[] methodNames, String projectPath) {
        CGCleaner.clean();
        return generateCallGraphForMultiModule(methodNames, projectPath, true);
    }

    public CallGraphBean generateCallGraphForMultiModule(String[] methodNames,
                                                         String projectPath, boolean byClass) {
        CGCleaner.clean();
        List<String> jarPath = MultiModuleTool.getJarPaths(projectPath);
        JSONArray methodsJson = new JSONArray();
        for (String methodName: methodNames) methodsJson.add(methodName);
        CallGraphBean callGraphBean = SootInvoker.build3(jarPath, remove(methodsJson), byClass);
        return analysisCallGraphBean(callGraphBean);
    }

    public void generateCallGraphForMultiModulePersist(String[] methodNames, String projectPath) {
        CGCleaner.clean();
        List<String> jarPath = MultiModuleTool.getJarPaths(projectPath);
        File projectFile = new File(projectPath);
        JSONArray methodsJson = new JSONArray();
        int count = 0;
        for (String methodName: methodNames) {
            methodsJson.add(methodName);
            count++;
            if (count % 500 == 0) {
                Global.clear();
                CallGraphBean callGraphBean = SootInvoker.build3(jarPath, remove(methodsJson));
                analysisCallGraphBean(callGraphBean);
                PersistUtil.storeNodes(Global.nodeSet, projectFile);
                methodsJson.clear();
            }
        }
    }

    public CallGraphBean generateCallGraph(List<SootMethod> list, String jarPath){
        CGCleaner.clean();
        List<String> path = new ArrayList<>();
        path.add(jarPath);
        CallGraphBean callGraphBean = SootInvoker.build3(path, list);
        return analysisCallGraphBean(callGraphBean);
    }

    public CallGraphBean generateCallGraph(JSONArray jMethods, List<String> jarPath){
        CGCleaner.clean();
        CallGraphBean callGraphBean = SootInvoker.build3(jarPath,remove(jMethods));
        return analysisCallGraphBean(callGraphBean);
    }

    private CallGraphBean analysisCallGraphBean(CallGraphBean callGraphBean){
        for(Node method: callGraphBean.getCiaMethod()) {
            method.acceptBFS(new InitGraphNodeVisitor(callGraphBean.getCallGraph()));
        }
        Global.callGraph = callGraphBean.getCallGraph();
        callGraphBean.setCallGraph(null);
        SetNodeMethodNameVisitor setNodeMethodNameVisitor = new SetNodeMethodNameVisitor();
        for(Node n : callGraphBean.getCiaMethod()){
            n.accept(setNodeMethodNameVisitor);
        }
        for(Node n : Global.nodeSet){
            n.isVisited = false;
        }
        LOGGER.info("generate " + Global.nodeSet.size() + " customized nodes successfully!");
        return callGraphBean;
    }

    private JSONArray remove(JSONArray jsonArray){
        for(int i = 0; i < jsonArray.size(); i++){
            String s = (String) jsonArray.get(i);
            if(!s.contains("(")){
                jsonArray.remove(s);
            }
        }
        return jsonArray;
    }
}
