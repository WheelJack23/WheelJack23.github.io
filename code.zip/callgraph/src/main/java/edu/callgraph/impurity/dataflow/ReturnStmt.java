package edu.callgraph.impurity.dataflow;

import edu.callgraph.impurity.bean.Var;
import soot.Value;

import java.util.ArrayList;
import java.util.List;

public class ReturnStmt extends AbstractStmt {

    public ReturnStmt(Value v){
        if(v != null) {
            this.var = new Var(v);
            isVoid = false;
        }else{
            isVoid = true;
        }
    }

    public boolean isVoid;

    public Var var;


    @Override
    public List<Var> getUsedVars(){
        if(isVoid){
            return null;
        }
        List<Var> result = new ArrayList<>();
        if(!this.var.isConstant) {
            result.add(this.var);
        }
        return result;
    }

    @Override
    public List<Var> getRightVars(){
        return null;
    }
}
