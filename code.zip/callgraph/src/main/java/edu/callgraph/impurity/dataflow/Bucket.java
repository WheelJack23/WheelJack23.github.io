package edu.callgraph.impurity.dataflow;

import java.util.Arrays;

public class Bucket {

    public Bucket(int size,int[] bound){
        arr = new int[size];
        Arrays.fill(arr,0);
        this.bound = bound;
        isFirst = true;
    }

    private int[] bound;

    private int[] arr;


    public boolean hasNext(){
        for(int i=0;i<arr.length;i++){
            if(arr[i] != bound[i]){
                return true;
            }
        }
        return false;
    }

    private boolean isFirst;

    public int[] next(){
        for(int i=0;i<arr.length;i++){
            if(arr[i] != bound[i]){
                if(isFirst){
                    isFirst = false;
                    break;
                }
                arr[i]+=1;
                break;
            }
        }
        return arr;
    }


}
