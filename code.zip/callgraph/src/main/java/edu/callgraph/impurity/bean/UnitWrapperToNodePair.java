package edu.callgraph.impurity.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UnitWrapperToNodePair implements Serializable {

    private UnitWrapper fromInvokeStmt;
    private Node toInvokedMethod;
    private List<VarPair> returnValuePair;
    private List<VarPair> baseAndArgsPair;

    public UnitWrapperToNodePair(UnitWrapper uw, Node node){
        this.fromInvokeStmt = uw;
        this.toInvokedMethod = node;
        this.baseAndArgsPair = new ArrayList<>();
        this.returnValuePair = new ArrayList<>();
    }

    private void initValuePair(){
        // UnitWrapper -> Node
    }

    public Node getToInvokedMethod() {
        return toInvokedMethod;
    }


    public List<VarPair> getReturnValuePair() {
        return returnValuePair;
    }

    public List<VarPair> getBaseAndArgsPair() {
        return baseAndArgsPair;
    }


    public UnitWrapper getFromInvokeStmt() {
        return fromInvokeStmt;
    }
}
