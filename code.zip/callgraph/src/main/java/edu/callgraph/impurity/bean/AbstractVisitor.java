package edu.callgraph.impurity.bean;


import edu.callgraph.global.Global;

public abstract class AbstractVisitor {
    private boolean getMethodFlag = true;
    public AbstractVisitor(){
        for(Node n : Global.nodeSet){
            n.isVisited = false;
        }
    }

    public AbstractVisitor(boolean flag){
        this.getMethodFlag = flag;
    }

    public abstract boolean preVisit(AbstractNode node);

    public abstract boolean postVisit(AbstractNode node);

    public abstract boolean visit(AbstractNode node);

    public abstract boolean endVisit(AbstractNode node);

    public boolean isPhantom(AbstractNode n){
        if(n instanceof Node){
            Node node = (Node) n;
            if (!this.getMethodFlag){
                return false;
            }
            if (node.getMethod() != null) {
                if (node.getMethod().isPhantom()) {
                    return true;
                }
            }else{
                return true;
            }
            return false;
        }
        return false;
    }


}
