package edu.callgraph.impurity.dataflow;

import edu.callgraph.global.Global;
import edu.callgraph.global.MyConstants;
import edu.callgraph.impurity.bean.*;
import soot.jimple.Constant;
import soot.jimple.internal.JIdentityStmt;

import java.util.ArrayList;
import java.util.List;

/**
 * core
 */
public class DataFlowParse {
    public static boolean beginFlow(Node node, UnitWrapper prevUnit, List<UnitWrapper> successorUnits, VarChain varChain, List<Var> changedUnitId) {
        if (successorUnits.isEmpty()) return false;
        for (UnitWrapper successor : successorUnits) {
            if (successor.parsedStmt instanceof ParameterStmt){
                beginFlow(node,prevUnit, successor.successorUnitWrapper, varChain,changedUnitId);
            } else if(successor.parsedStmt instanceof AssignmentInvokeStmt) {
                isSuccessorInvokeStmt(prevUnit,successor, node, varChain,changedUnitId,true);
            } else if (successor.parsedStmt instanceof AssignmentStmt) {
                isSuccessorAssigment(prevUnit,successor, node, varChain,changedUnitId);
            } else if (successor.parsedStmt instanceof InvokeStmt) {
                isSuccessorInvokeStmt(prevUnit,successor, node, varChain, changedUnitId, false);
            } else if(successor.parsedStmt instanceof ReturnStmt) {
                isSetReturnVarChange(prevUnit,successor, node, varChain, changedUnitId);
            } else if(successor.parsedStmt instanceof IfStmt){
                isIfStmt(prevUnit,successor,node,varChain,changedUnitId);
            } else{
                Global.setLogger(DataFlowParse.class);
                Global.logger.error("new case");
            }
        }
        return true;
    }

    private static void isIfStmt(UnitWrapper prevUnit, UnitWrapper successor, Node node, VarChain varChain, List<Var> changedUnitId){
        IfStmt ifStmt = (IfStmt) successor.parsedStmt;
        Var opt1 = ifStmt.opt1;
        Var opt2 = ifStmt.opt2;
        if(opt1.isConstant && !opt2.isConstant){
            if(varChain.hasVar(opt2, MyConstants.FORWARD)){
                Var prev = varChain.getSameVarName(opt2, MyConstants.FORWARD);
                varChain.addVarLink(prev,opt2, MyConstants.VarLinkType.LINK0);
            }
        }


        if(!opt1.isConstant && opt2.isConstant){
            if(varChain.hasVar(opt1, MyConstants.FORWARD)){
                Var prev = varChain.getSameVarName(opt1, MyConstants.FORWARD);
                varChain.addVarLink(prev,opt1, MyConstants.VarLinkType.LINK0);
            }
        }
        beginFlow(node,successor, successor.successorUnitWrapper,varChain, changedUnitId);

    }

    private static void isSetReturnVarChange(UnitWrapper prevUnit, UnitWrapper successor, Node node, VarChain varChain, List<Var> changedUnitId){
        ReturnStmt returnStmt = (ReturnStmt) successor.parsedStmt;
        if(returnStmt.isVoid){
            return;
        }
        if(!returnStmt.var.isConstant) {
            if (varChain.hasVar(returnStmt.var, MyConstants.FORWARD)) {
                Var prev = varChain.getSameVarName(returnStmt.var, MyConstants.FORWARD);
                varChain.addVarLink(prev, returnStmt.var, MyConstants.VarLinkType.LINK0);
//            returnStmt.var.isChange = true;
            }
        }else{
            varChain.addVarLink(varChain.newAddedVar,returnStmt.var, MyConstants.VarLinkType.LINK0);
        }
    }

    private static void isSuccessorInvokeStmt(UnitWrapper prevUnit, UnitWrapper successor, Node node, VarChain varChain, List<Var> changedUnitId, boolean isAssignmentInvoke) {
        UnitWrapperToNodePair child = node.getMappedNodeOfUnitWrapper(successor);
        List<VarPair> varPair = child.getBaseAndArgsPair();
        boolean haveIsChange = false;
        List<VarPair> isChangeVp = new ArrayList<>();
        for(VarPair vp:varPair){
            if(vp.to.isChange){
                vp.from.isChange = true;
                haveIsChange = true;
                isChangeVp.add(vp);
            }
        }
        if(haveIsChange){
            if(isAssignmentInvoke){
                List<Var> retVar = child.getToInvokedMethod().getNodeIOVars().getChangedReturnVar();
                if(retVar.size()!=0){
                    AssignmentInvokeStmt assignmentInvokeStmt = (AssignmentInvokeStmt) successor.parsedStmt;
                    assignmentInvokeStmt.leftVar.isChange = true;
                    varChain.addVarLink(null,assignmentInvokeStmt.leftVar, MyConstants.VarLinkType.LINK0);
                }
            }
        }
        beginFlow(node, successor, successor.successorUnitWrapper,varChain, changedUnitId);
        return;

    }

    private static void isSuccessorAssigment(UnitWrapper prevUnit, UnitWrapper successor, Node node, VarChain varChain, List<Var> changedUnitId) {
        AssignmentStmt assignStmt = (AssignmentStmt) successor.parsedStmt;
        Var left = assignStmt.leftVar;
        List<Var> rights = assignStmt.rightVars;
        for(Var right:rights){
            if(isValuePrimitive(right)){
                continue;
            }
            if(varChain.hasVar(right, MyConstants.FORWARD)){
                List<Var> relatedVar =varChain.getRelatedVar(right);
                for(Var relates:relatedVar) {
                    varChain.addVarLink(relates,left, MyConstants.VarLinkType.LINK0);
                }
            }
        }
        beginFlow(node, successor,successor.successorUnitWrapper,varChain, changedUnitId);

    }

    private static boolean isValuePrimitive(Var v){
        if (v.value instanceof Constant){
            return true;
        }
        return false;
    }

    public static List<UnitWrapper> getParamUnit(Node cianode) {
        List<UnitWrapper> inputParamUnits = new ArrayList<>();
        for (UnitWrapper unitWrapper : cianode.getUnitWrapperContainer().getUnitWrappers()) {
            if (unitWrapper.unit instanceof JIdentityStmt) {
                inputParamUnits.add(unitWrapper);
            }
        }
        return inputParamUnits;
    }

}
