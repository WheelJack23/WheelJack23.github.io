package edu.callgraph.impurity.bean;

import edu.callgraph.global.Global;
import edu.callgraph.global.MyConstants;
import soot.SootMethod;
import soot.Type;
import soot.toolkits.graph.UnitGraph;

import java.io.Serializable;
import java.util.*;

public class Node extends AbstractNode implements Serializable {
    private transient SootMethod method = null;
    private List<String> childrenStr = null;

    public void setChildrenStr() {
        childrenStr = new ArrayList<>();
        for (AbstractNode node: super.getChildren()) {
            childrenStr.add(((Node)node).getMethodSignatureFull());
        }
    }

    private String declaringClass;
    private String methodSignatureParamShort;
    private String methodSignatureFull;
    private transient UnitWrapperContainer unitWrapperContainer;
    private transient List<UnitWrapperToNodePair> unitToNodePairList;
    private transient UnitGraph unitGraph;

    private transient NodeIOVar nodeIOVars;

    private transient List<Var> changeSpot;

    public int isChange;

    private transient List<Node> callers;
    private transient List<Node> callees;
    private transient Set<String> usedFields;
    private transient Set<String> fieldList;
    private transient Map<String, Integer> isWrite;
    private transient Map<String, Integer> isRead;
    private transient List<String> usedClassList;
    private transient Map<String, String> degradeMap;
    private transient Set<String> pathSet;


    public Node(){
        this.methodSignatureFull = null;
    }

    private Node(SootMethod method) {
        super();
        Global.sootMethodAll.add(method);
        this.method = method;
        isChange = MyConstants.SAME;
        this.methodSignatureFull = null;
    }

    public void initAdditionalFields() {
        pathSet = new HashSet<>();
        degradeMap = new HashMap<>();
        usedClassList = new ArrayList<>();
        isRead = new HashMap<>();
        isWrite = new HashMap<>();
        fieldList = new HashSet<>();
        usedFields = new HashSet<>();
        callees = new ArrayList<>();
        callers = new ArrayList<>();
    }

    public static Node createNodeInstance(SootMethod method){
        if(Global.nodeAll.containsKey(method)){
            return Global.nodeAll.get(method);
        }
        Node node = new Node(method);
        Global.nodeAll.put(method,node);
        return node;
    }


    public void initUnitWrapperContainer(int index){
        this.unitWrapperContainer = new UnitWrapperContainer(index);
    }

    public void initUnitToNodePair(){
        this.unitToNodePairList = new ArrayList<>();
    }

    public List<UnitWrapperToNodePair> getUnitToNodePairList() {
        return unitToNodePairList;
    }

    public UnitWrapperContainer getUnitWrapperContainer() {
        return unitWrapperContainer;
    }

    public SootMethod getMethod() {
        return method;
    }


    public void setMethod(SootMethod method) {
        this.method = method;
    }

    public void setChangeSpot(List<Var> changeSpot) {
        this.changeSpot = changeSpot;
    }

    public List<Var> getChangeSpot() {
        return changeSpot;
    }

    public UnitGraph getUnitGraph() {
        return unitGraph;
    }

    public void setUnitGraph(UnitGraph unitGraph) {
        this.unitGraph = unitGraph;
    }

    public List<Node> getCallers() {
        return callers;
    }

    public void setCallers(List<Node> callers) {
        this.callers = callers;
    }

    public List<Node> getCallees() {
        return callees;
    }

    public void setCallees(List<Node> callees) {
        this.callees = callees;
    }

    public Set<String> getUsedFields() {
        return usedFields;
    }

    public void setUsedFields(Set<String> usedFields) {
        this.usedFields = usedFields;
    }

    public Set<String> getFieldList() {
        return fieldList;
    }

    public void setFieldList(Set<String> fieldList) {
        this.fieldList = fieldList;
    }

    public Map<String, Integer> getIsWrite() {
        return isWrite;
    }

    public void setIsWrite(Map<String, Integer> isWrite) {
        this.isWrite = isWrite;
    }

    public Map<String, Integer> getIsRead() {
        return isRead;
    }

    public void setIsRead(Map<String, Integer> isRead) {
        this.isRead = isRead;
    }

    public List<String> getUsedClassList() {
        return usedClassList;
    }

    public void setUsedClassList(List<String> usedClassList) {
        this.usedClassList = usedClassList;
    }

    public Map<String, String> getDegradeMap() {
        return degradeMap;
    }

    public void setDegradeMap(Map<String, String> degradeMap) {
        this.degradeMap = degradeMap;
    }

    public Set<String> getPathSet() {
        return pathSet;
    }

    public void setPathSet(Set<String> pathSet) {
        this.pathSet = pathSet;
    }

    public String getMethodSignatureFull(){
        if (methodSignatureFull != null) return methodSignatureFull;
        List<Type> params = method.getParameterTypes();
        StringBuilder sb = new StringBuilder();
        if(params== null || params.size()==0){
            sb.append("()");
        }else {
            sb.append("(");
            for (Type t : params) {
                sb.append(t.toString());
                sb.append(",");
            }
            sb.deleteCharAt(sb.length() - 1);
            sb.append(")");
        }
        methodSignatureFull = method.getDeclaringClass().getName()+"."+method.getName()+sb.toString();
        return methodSignatureFull;
    }

    public String getMethodSignatureName(){
        return method.getDeclaringClass().getName()+"."+method.getName();
    }

    public String getMethodSignatureShortName(){
        return method.getDeclaringClass().getShortName()+"."+method.getName();
    }

    public void setUnitWrapperContainer(UnitWrapperContainer unitWrapperContainer) {
        this.unitWrapperContainer = unitWrapperContainer;
    }

    public void addunitToNodePair(UnitWrapperToNodePair unitWrapperToNodePair) {
        this.unitToNodePairList.add(unitWrapperToNodePair);
    }


    public NodeIOVar getNodeIOVars() {
        return nodeIOVars;
    }

    public void setNodeIOVars(NodeIOVar nodeIOVars) {
        this.nodeIOVars = nodeIOVars;
    }

    public UnitWrapperToNodePair getMappedNodeOfUnitWrapper(UnitWrapper unitWrapper){
        for(UnitWrapperToNodePair unitWrapperToNodePair:this.unitToNodePairList){
            if(unitWrapperToNodePair.getFromInvokeStmt() == unitWrapper){
                return unitWrapperToNodePair;
            }
        }
        return null;
    }

    @Override
    public String toString(){
        return this.getMethodSignatureFull();
    }


    public String getDeclaringClass() {
        return declaringClass;
    }

    public void setDeclaringClass(String declaringClass) {
        this.declaringClass = declaringClass;
    }

    public String getMethodSignatureParamShort() {
        return methodSignatureParamShort;
    }

    public void setMethodSignatureParamShort(String methodSignatureParamShort) {
        this.methodSignatureParamShort = methodSignatureParamShort;
    }

    @Override
    public void acceptChild(AbstractVisitor visitor, List nodes) {
        if(nodes == null){
            return;
        }
        for (Object n : nodes) {
            Node node = (Node) n;

            if(visitor.isPhantom(node)){
                continue;
            }

            node.accept(visitor);
        }
    }
}
