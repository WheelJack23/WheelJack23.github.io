package edu.callgraph.impurity.vis;


import edu.callgraph.impurity.MyRange;

import java.util.ArrayList;
import java.util.List;

public class MethodData {

    public boolean isAddedOrDeleteOnGraph;

    public String methodSignature;

    /**
     * METHOD RANGE
     */
    public MyRange range;


    public List<Integer> taintedLines;

    public MethodData(String s){
        this.methodSignature = s;
        this.taintedLines = new ArrayList<>();
    }

}
