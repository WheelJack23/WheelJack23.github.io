package edu.callgraph.impurity;

import java.io.Serializable;

public class MyRange implements Serializable {

    public int startLineNo;
    public int endLineNo;

    public MyRange(int start, int end){
        this.startLineNo = start;
        this.endLineNo = end;
    }



    @Override
    public String toString(){
        return "("+this.startLineNo+","+this.endLineNo+")";
    }



}
