package edu.callgraph.impurity.vis;

import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;
import edu.callgraph.impurity.bean.Node;

/**
 * traverse from root and collect method name and class name
 * put into classDataContainer
 */
public class CollectMethodNameVisitor extends AbstractVisitor {

    public ClassDataContainer classDataContainer = new ClassDataContainer();


    public boolean preVisit(AbstractNode node) {
        return true;
    }

    public boolean postVisit(AbstractNode node){

        return true;
    }


    public boolean visit(AbstractNode node){
        Node n =  (Node)node;
        classDataContainer.addEntry(n.getDeclaringClass(),n.getMethodSignatureParamShort());
        return true;

    }

    public boolean endVisit(AbstractNode node){
        return true;
    }


}
