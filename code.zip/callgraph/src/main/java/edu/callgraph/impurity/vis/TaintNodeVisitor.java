package edu.callgraph.impurity.vis;

import edu.callgraph.global.Global;
import edu.callgraph.global.MyConstants;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapper;
import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;

import java.util.List;
import java.util.Map;

public class TaintNodeVisitor extends AbstractVisitor {

    public TaintNodeVisitor(ClassDataContainer container,Map<String, Node> counterMap){
        this.container = container;
        this.counterNodeMap = counterMap;
    }

    private ClassDataContainer container;

    /**
     * prev->curr curr->prev
     */
    private Map<String, Node> counterNodeMap;

    public boolean preVisit(AbstractNode node) {
        return true;
    }

    public boolean postVisit(AbstractNode node){
        return true;
    }


    public boolean visit(AbstractNode node){
        Node n =  (Node)node;
        List<UnitWrapper> wrappers = n.getUnitWrapperContainer().getUnitWrappers();
        n.getUnitWrapperContainer().initRange();
        MethodData matchedMethodData = isTaintable(container,n.getDeclaringClass(),n.getMethodSignatureParamShort());
        if(matchedMethodData.isAddedOrDeleteOnGraph){
            n.isChange = MyConstants.ADD_OR_DELETE;
        }
        boolean isChange = false;
        for(UnitWrapper uw:wrappers){
            if(matchedMethodData.taintedLines.contains(uw.lineNumber)){
                uw.isChange = true;
                isChange = true;
            }
        }
        if(isChange) {
            n.isChange = MyConstants.CHANGE;
            if(counterNodeMap.containsKey(n.getMethodSignatureFull())){
                Node counterpartNode = counterNodeMap.get(n.getMethodSignatureFull());
                counterpartNode.isChange = MyConstants.CHANGE;
            }else{
                Global.setLogger(TaintNodeVisitor.class);
                Global.logger.error("CORNER CONDITION");
            }
        }
        return true;

    }

    public MethodData isTaintable(ClassDataContainer container,String className,String methodName){
        MethodData methodData =  container.classDataMap.get(className).methodDataMap.get(methodName);
        return methodData;
    }

    public boolean endVisit(AbstractNode node){
        return true;
    }

}
