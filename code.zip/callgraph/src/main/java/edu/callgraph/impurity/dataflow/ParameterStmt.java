package edu.callgraph.impurity.dataflow;

import edu.callgraph.impurity.bean.Var;
import soot.Value;

import java.util.ArrayList;
import java.util.List;

public class ParameterStmt extends AssignmentStmt {

    public ParameterStmt(Value lv, List<Value> rightValues) {
        super(lv, rightValues);
    }


    @Override
    public List<Var> getUsedVars(){
        List<Var> result = new ArrayList<>();
        result.add(this.leftVar);
        return result;
    }

}
