package edu.callgraph.impurity.vis;

import com.alibaba.fastjson.JSONArray;
import edu.callgraph.global.Config;
import edu.callgraph.global.Global;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.UnitWrapper;
import edu.callgraph.impurity.dataflow.InvokeStmt;
import edu.callgraph.impurity.init.UnitParser;
import edu.callgraph.util.JsonUtil;
import edu.callgraph.util.UnitGraphTool;
import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;
import soot.*;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.toolkits.graph.UnitGraph;

import java.util.*;

/**
 * generate graph
 */
public class InitGraphNodeVisitor extends AbstractVisitor {

    public InitGraphNodeVisitor(CallGraph callGraph){
        this.callGraph = callGraph;
        this.jdkClasses = new HashSet<>();
        this.used = new HashSet<>();
    }

    private CallGraph callGraph;
    private Set<String> jdkClasses;
    private Set<String> used;


    public boolean preVisit(AbstractNode node) {
        return true;
    }

    public boolean postVisit(AbstractNode node){
        return true;
    }

    public boolean visit(AbstractNode node){
        // BFS
        Node n = (Node) node;
        if(Global.nodeSet.contains(n)){
            return true;
        }
        Global.nodeSet.add(n);
        initNode(n);
        UnitParser.runParseUnit(n);
//        List<Unit> li = new ArrayList<>();
        if(n.getUnitWrapperContainer()!=null) {
            List<UnitWrapper> uws = n.getUnitWrapperContainer().getUnitWrappers();
            Map<UnitWrapper, List<SootMethod>> unitToNodePair = new HashMap<>();
            for (UnitWrapper uw : uws) {
                if (uw.parsedStmt instanceof InvokeStmt) {
                    if (isValidUnit(uw)) {
                        Iterator<Edge> edges = callGraph.edgesOutOf(uw.unit);
                        List<SootMethod> value = new ArrayList<>();
                        while (edges.hasNext()) {
                            Edge e = edges.next();
                            SootMethod sootMethod = (SootMethod) e.getTgt();
                            SootClass sootClass = sootMethod.getDeclaringClass();
                            if(isValidCallGraphNode(sootClass) && isValidMethod(sootMethod)) {
                                value.add(sootMethod);
                            }
                        }
                        if(value.size() == 0){
                            InvokeStmt stmt = (InvokeStmt) uw.parsedStmt;
                            SootMethod sootMethod2 = stmt.sootMethod;
                            if(sootMethod2!=null) {
                                value.add(sootMethod2);
                            }
                        }
                        unitToNodePair.put(uw, value);
                    }
                }
            }
            UnitParser.runMapUnitToNode(n, unitToNodePair);
        }
        return true;
    }

    public boolean endVisit(AbstractNode node){
        return true;
    }

    /**
     * remove jdk nodes
     * @param uw
     * @return
     */
    public boolean isValidUnit(UnitWrapper uw){
        if(!Config.IGNORE_JDK){
            // always valid unit.
            return true;
        }
        InvokeStmt invokeStmt = (InvokeStmt) uw.parsedStmt;
        if(invokeStmt.invokeType == InvokeStmt.CLASS_NEW){
            return false;
        }
        SootMethod sootMethod = invokeStmt.sootMethod;
        SootClass sootClass = sootMethod.getDeclaringClass();
        return isValidCallGraphNode(sootClass);
    }

    public boolean isValidCallGraphNode(SootClass sootClass){
        String name = sootClass.getName();

        if(name.startsWith("java.")){
            return false;
        }
        if(name.startsWith("javax.")){
            return false;
        }
        if(name.startsWith("org.xml")){
            return false;
        }
        if(name.startsWith("org.ietf")){
            return false;
        }
        if(name.startsWith("org.omg")){
            return false;
        }
        if(name.startsWith("org.w3c")){
            return false;
        }
        if(isJDKMethod(name)){
            return false;
        }

        return true;

    }

    public boolean isJDKMethod(String className){
        if(jdkClasses.size() == 0){
            JSONArray jarr = JsonUtil.readJsonFileAsArray(Config.JAVA_DOC_PATH);
            for (Object o : jarr) {
                String name = (String) o;
                jdkClasses.add(name);
            }
        }

        String fileName = "/docs/api/" + className + ".html";
        if(used.contains(fileName)){
            return true;
        }
        else if(jdkClasses.contains(fileName)) {
            used.add(fileName);
            return true;
        }
        return false;
    }

    public boolean isValidMethod(SootMethod sootMethod){
        String name = sootMethod.getName();
        if("<clinit>".equals(name)){//||"<init>".equals(name)
            return false;
        }
        return true;
    }

    public void initNode(Node node){
        Node n =  node;
        if (n.getMethod().isPhantom()) {
            return;
        }
        try{
            if(n.getUnitWrapperContainer() == null) {
                n.initUnitWrapperContainer(0);
                UnitGraph ug = UnitGraphTool.getUnitGraphFromNode(n);
                if (ug == null) return;
                n.setUnitGraph(ug);
                Iterator<Unit> iter = ug.iterator();
                int i = 0;
                while (iter.hasNext()) {
                    Unit unit = (Unit) iter.next();
                    n.getUnitWrapperContainer().addUnitToUnitWrapper(i, unit);
                    n.getUnitWrapperContainer().initRange();
                    i++;
                }
            }
        } catch(RuntimeException re){
        }
    }


}
