package edu.callgraph.impurity.vis;

import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;
import edu.callgraph.impurity.bean.Node;

import java.util.Map;

public class SetMapVisitor extends AbstractVisitor {

    public Map<String, Node> innerMap;

    public boolean preVisit(AbstractNode node) {
        return true;
    }

    public boolean postVisit(AbstractNode node){
        return true;
    }


    public boolean visit(AbstractNode node){
        Node n = (Node) node;
        String methodSig = n.getMethodSignatureFull();
        innerMap.put(methodSig,n);
        return true;

    }

    public boolean endVisit(AbstractNode node){
        return true;
    }
}
