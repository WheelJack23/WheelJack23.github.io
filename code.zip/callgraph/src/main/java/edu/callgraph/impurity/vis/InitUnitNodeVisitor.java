package edu.callgraph.impurity.vis;

import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.init.UnitParser;

public class InitUnitNodeVisitor extends AbstractVisitor {

    @Override
    public boolean preVisit(AbstractNode node) {
        return true;
    }

    @Override
    public boolean postVisit(AbstractNode node){
        return true;
    }

    @Override
    public boolean visit(AbstractNode node){
        Node n = (Node)node;
        UnitParser.runUnitGraph(n);
        UnitParser.parseNodeIO(n);
        UnitParser.parseUnitPredecessorAndSuccessor(n);
        if (node.getChildren() != null && node.getChildren().size() != 0) {
            return true;
        }

        return false;
    }

    @Override
    public boolean endVisit(AbstractNode node){
        if (node.getChildren() != null && node.getChildren().size() != 0) {
            UnitParser.parseVarPair((Node) node);
        }
        return true;
    }

    public void setParentNode(AbstractNode node) {
        if (node.getChildren() != null && node.getChildren().size() != 0) {
            for (AbstractNode n : node.getChildren()) {
                n.getParents().add(node);
            }
        }
    }
}
