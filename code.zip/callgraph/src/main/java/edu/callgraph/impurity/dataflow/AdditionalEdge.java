package edu.callgraph.impurity.dataflow;

import edu.callgraph.impurity.bean.UnitWrapper;

public class AdditionalEdge {

    UnitWrapper a;
    UnitWrapper b;

    public AdditionalEdge(UnitWrapper a, UnitWrapper b){
        this.a = a;
        this.b = b;

    }
}
