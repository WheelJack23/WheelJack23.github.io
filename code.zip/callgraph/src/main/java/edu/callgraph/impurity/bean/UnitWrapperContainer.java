package edu.callgraph.impurity.bean;

import edu.callgraph.impurity.MyRange;
import edu.callgraph.impurity.init.UnitParser;
import soot.Unit;
import soot.tagkit.LineNumberTag;
import soot.tagkit.SourceLnNamePosTag;
import soot.tagkit.Tag;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UnitWrapperContainer implements Serializable {

    private int startIndex;
    private List<UnitWrapper> unitWrappers;
    private Map<Unit, Integer> unitToIdMap;

    private boolean isUnitParsed;

    private MyRange range;

    public UnitWrapperContainer(int startIndex){
        this.unitWrappers = new ArrayList<>();
        this.startIndex = startIndex;
        this.unitToIdMap = new HashMap<>();
        this.isUnitParsed = false;
    }


    public int getStartIndex() {
        return startIndex;
    }

    public List<UnitWrapper> getUnitWrappers() {
        return unitWrappers;
    }

    public void addUnitToUnitWrapper(int id,Unit unit) {
        UnitWrapper uw = UnitParser.initUnit(unit,id);
        unitWrappers.add(uw);
        unitToIdMap.put(uw.unit,uw.id);
    }

    public int getUnitIdByUnit(Unit unit){
        return unitToIdMap.get(unit);
    }

    public UnitWrapper getUnitWrapperByUnit(Unit unit){
        return unitWrappers.get(unitToIdMap.get(unit));
    }

    public boolean isUnitParsed() {
        return isUnitParsed;
    }

    public void setUnitParsed(boolean unitParsed) {
        isUnitParsed = unitParsed;
    }

    public void resetVisitFlag(){
        for(UnitWrapper uw:this.getUnitWrappers()){
            uw.isVisited = false;
        }
    }

    public MyRange getRange() {
        return range;
    }

    public void initRange() {
        boolean isFirst = true;
        int start = 0, end =0 ;
        for(int i = 0; i < unitWrappers.size(); i ++) {
            UnitWrapper uw = unitWrappers.get(i);
            List<Tag> tags = uw.unit.getTags();
            if(tags == null || tags.size() == 0) {
                continue;
            }
            int lineNumber = 0;
            for(Tag tag : tags) {
                if(tag instanceof LineNumberTag) {
                    LineNumberTag lineNumberTag = (LineNumberTag) tag;
                    lineNumber = lineNumberTag.getLineNumber();
                    uw.lineNumber = lineNumber;
                }
                else if(tag instanceof SourceLnNamePosTag) {
                    SourceLnNamePosTag lineNumberTag = (SourceLnNamePosTag) tag;
                    lineNumber = lineNumberTag.startLn();
                    uw.lineNumber = lineNumber;
                }
            }
            if (isFirst) {
                start = lineNumber;
                isFirst = false;
            }
            if (i == unitWrappers.size() - 1) {
                end = lineNumber;
            }
        }
        if (end != 0) {
            range = new MyRange(start,end);
        }
    }
}
