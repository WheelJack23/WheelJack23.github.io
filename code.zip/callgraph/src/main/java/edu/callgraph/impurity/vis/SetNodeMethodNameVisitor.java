package edu.callgraph.impurity.vis;

import edu.callgraph.SootMethodToString;
import edu.callgraph.impurity.bean.Node;
import edu.callgraph.impurity.bean.AbstractNode;
import edu.callgraph.impurity.bean.AbstractVisitor;

/**
 * traverse and set method name, class name
 */
public class SetNodeMethodNameVisitor extends AbstractVisitor {

    @Override
    public boolean preVisit(AbstractNode node) {
        return true;
    }

    @Override
    public boolean postVisit(AbstractNode node){
        return true;
    }

    @Override
    public boolean visit(AbstractNode node){
        if(node.isVisited){
            return false;
        }
        node.isVisited = true;
        Node n =  (Node)node;
        String s  = n.getMethod().getDeclaringClass().getName();
        n.setDeclaringClass(s);
        String methodSig = SootMethodToString.getSootMethodSignatureName(n.getMethod(),true);
        n.setMethodSignatureParamShort(methodSig);
        return true;

    }

    @Override
    public boolean endVisit(AbstractNode node){
        return true;
    }


    @Override
    public boolean isPhantom(AbstractNode node){
        return false;
    }

}
