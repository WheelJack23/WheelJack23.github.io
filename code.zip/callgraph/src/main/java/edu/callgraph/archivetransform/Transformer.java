package edu.callgraph.archivetransform;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

public class Transformer {
    private static File transformDir;

    public static void clearDir(File parent) {
        transformDir = new File(parent, ".transform");
        if (transformDir.exists()) {
            try {
                if (transformDir.isFile()) FileUtils.forceDelete(transformDir);
                else FileUtils.cleanDirectory(transformDir);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        transformDir.mkdir();
    }

    public static File transformSpringbootJar(String path) throws IOException {
        File file = new File(path);
        File folder = ZipTool.unzipInParent(file, transformDir);

        File classesFile = findClassesFileForSpringBootJar(folder);

        return jar(classesFile, folder);
    }

    public static File transformSpringbootJarInParent(String path) throws IOException {
        File file = new File(path);
        File folder = ZipTool.unzipInParent(file, file.getParentFile());

        File classesFile = findClassesFileForSpringBootJar(folder);

        return jar(classesFile, folder);
    }

    public static boolean isSpringbootJar(File file) {
        JarFile jar = null;
        try {
            jar = new JarFile(file);
            ZipEntry bootEntry = jar.getJarEntry("BOOT-INF/");
            return bootEntry != null;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static boolean isSpringbootJar(String path) {
        return isSpringbootJar(new File(path));
    }

    public static File transformWar(String path) throws IOException {
        File file = new File(path);
        File folder = ZipTool.unzipInParent(file, transformDir);

        File classesFile = findClassesFileForWar(folder);

        return jar(classesFile, folder);
    }

    public static File transformWarInParent(String path) throws IOException {
        File file = new File(path);
        File folder = ZipTool.unzipInParent(file, file.getParentFile());

        File classesFile = findClassesFileForWar(folder);

        return jar(classesFile, folder);
    }

    private static File jar(File classesFile, File parentFile) throws IOException {
        String newJarName = TmpManager.folderName(classesFile.getAbsolutePath()) + ".jar";
        File newJarFile = new File(parentFile, newJarName);
        if (newJarFile.exists()) {
            if (!TmpManager.delete(newJarFile))
                throw new RuntimeException("failed to delete newJar file.");
        }
        ZipTool.compress(classesFile, newJarFile);
        return newJarFile;
    }

    private static File jar(File classesFile) throws IOException {
        String newJarName = TmpManager.folderName(classesFile.getAbsolutePath()) + ".jar";
        File newJarFile = new File(TmpManager.TMP_PATH, newJarName);
        if (newJarFile.exists()) {
            if (!TmpManager.delete(newJarFile))
                throw new RuntimeException("failed to delete newJar file.");
        }
        ZipTool.compress(classesFile, newJarFile);
        return newJarFile;
    }

    public static File findClassesFileForWar(File folder) {
        File[] files = folder.listFiles();
        if (files == null) throw new RuntimeException("No files in unzip folder. ");
        for (File file: files) {
            if (file.getName().equals("WEB-INF") && file.isDirectory()) {
                File[] filesInBootInf = file.listFiles();
                if (filesInBootInf == null)
                    throw new RuntimeException("No files in WEB-INF directory.");
                for (File fileInBootInf: filesInBootInf) {
                    if (fileInBootInf.getName().equals("classes") && fileInBootInf.isDirectory()) {
                        return fileInBootInf;
                    }
                }
            }
        }
        throw new RuntimeException("WEB-INF directory not found in unzip folder.");
    }

    public static File findClassesFileForSpringBootJar(File folder) {
        File[] files = folder.listFiles();
        if (files == null) throw new RuntimeException("No files in unzip folder. ");
        for (File file: files) {
            if (file.getName().equals("BOOT-INF") && file.isDirectory()) {
                File[] filesInBootInf = file.listFiles();
                if (filesInBootInf == null)
                    throw new RuntimeException("No files in BOOT-INF directory.");
                for (File fileInBootInf: filesInBootInf) {
                    if (fileInBootInf.getName().equals("classes") && fileInBootInf.isDirectory()) {
                        return fileInBootInf;
                    }
                }
            }
        }
        throw new RuntimeException("BOOT-INF directory not found in unzip folder.");
    }

}
