package edu.callgraph.archivetransform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class TmpManager {
    private static final int TMP_SIZE_THRESHOLD = 1000;
    private static final double FRACTION = 1/5.0; 
    public static final String TMP_PATH = "tmp";
    private static final Logger LOGGER = LoggerFactory.getLogger(TmpManager.class);


    public static void prepareTmp() {
        File file = new File(TMP_PATH);
        createDirectory(file);
        File[] subFiles = file.listFiles();
        if (subFiles == null) return;
        int size = subFiles.length;
        if (size >= TMP_SIZE_THRESHOLD) {
            int deleteNum = tryDelete(file);
            LOGGER.info(deleteNum + " files have been deleted.");
        }
    }

    private static int tryDelete(File file) {
        File[] subFiles = file.listFiles();
        if (subFiles == null) return 0;
        int totalNum = subFiles.length;
        int deleteNum = (int)(totalNum * FRACTION);
        int[] deleteIdx = getKFromN(deleteNum, totalNum);
        int deleteCount = 0;
        for (int i = 0 ; i < deleteNum ; i ++) {
            if (delete(subFiles[deleteIdx[i]])) deleteCount++;
            else System.out.println("delete file failed.");
        }
        return deleteCount;
    }


    private static void createDirectory(File file) {
        if(!file.exists()){
            if (!file.mkdirs())
                throw new RuntimeException("tmp directory initialize failed.");
        }

        if (file.exists() && file.isFile()) {
            if (!file.delete()) {
                throw new RuntimeException("tmp file delete failed.");
            }
            if (!file.mkdirs())
                throw new RuntimeException("tmp directory initialize failed.");
        }
    }

    public static boolean delete(File file) {
        if (file.isFile()) {
            return file.delete();
        }
        else {
            File[] subs = file.listFiles();
            boolean deleteSuccess = true;
            if (subs != null ) {
                for (File sub: subs) {
                    deleteSuccess &= delete(sub);
                }
            }
            deleteSuccess &= file.delete();
            return deleteSuccess;
        }
    }


    public static int[] getKFromN(int k, int n) {
        int[] rand = new int[k];
        Map<Integer, Integer> idx2num = new HashMap<>();
        for (int i = 0 ; i < k ; i++) {
            int idx = (int)(Math.random() * (n - i));
            int num = idx2num.getOrDefault(idx, idx);
            rand[i] = num;
            idx2num.put(idx, idx2num.getOrDefault(n-i-1, n-i-1));
        }
        return rand;
    }

    public static String folderName(String url) {
        String folderName = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(url.getBytes(StandardCharsets.UTF_8));
            folderName = new BigInteger(1, md5.digest()).toString(16);
            return folderName;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            throw new RuntimeException("No MD5 algorithm. ");
        }
    }
}
