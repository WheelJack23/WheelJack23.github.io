package edu.callgraph.archivetransform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.zip.*;


public class ZipTool {
    private static final Logger LOGGER = LoggerFactory.getLogger(ZipTool.class);

    private static final int BUF_SIZE = 65536/4;

    private static final int BUFFER = 8192;

    public static void compress(File srcFile , File dstFile) throws IOException{
        if (!srcFile.exists()) {
            throw new FileNotFoundException(srcFile.getAbsolutePath() + "does not exist!");
        }

        FileOutputStream out = null;
        ZipOutputStream zipOut = null;
        try {
            out = new FileOutputStream(dstFile);
            CheckedOutputStream cos = new CheckedOutputStream(out,new CRC32());
            zipOut = new ZipOutputStream(cos);
            String baseDir = "";
            if (!srcFile.isDirectory())
                throw new RuntimeException("zip failed: srcFile is not a valid directory");
            File[] files = srcFile.listFiles();
            for (int i = 0; i < files.length; i++) {
                compress(files[i], zipOut, "");
            }
        }
        finally {
            if(null != zipOut){
                zipOut.close();
                out = null;
            }

            if(null != out){
                out.close();
            }
        }
    }

    private static void compress(File file, ZipOutputStream zipOut, String baseDir) throws IOException{
        if (file.isDirectory()) {
            compressDirectory(file, zipOut, baseDir);
        } else {
            compressFile(file, zipOut, baseDir);
        }
    }

    private static void compressDirectory(File dir, ZipOutputStream zipOut, String baseDir) throws IOException{
        File[] files = dir.listFiles();
        if(files == null || files.length == 0){
            zipOut.putNextEntry(new ZipEntry(baseDir + dir.getName() + "/"));
            zipOut.closeEntry();
            return;
        }
        for (int i = 0; i < files.length; i++) {
            compress(files[i], zipOut, baseDir + dir.getName() + "/");
        }
    }

    private static void compressFile(File file, ZipOutputStream zipOut, String baseDir)  throws IOException{
        if (!file.exists()){
            return;
        }

        BufferedInputStream bis = null;
        try {
            bis = new BufferedInputStream(new FileInputStream(file));
            ZipEntry entry = new ZipEntry(baseDir + file.getName());
            zipOut.putNextEntry(entry);
            int count;
            byte data[] = new byte[BUFFER];
            while ((count = bis.read(data, 0, BUFFER)) != -1) {
                zipOut.write(data, 0, count);
            }
        }finally {
            if(null != bis){
                bis.close();
            }
        }
    }


    private static void unzip(File file, File folder) {
        if (folder.exists()) {
            if (!TmpManager.delete(folder)) {
                throw new RuntimeException("clean unzip folder failed.");
            }
        }
        if (!folder.mkdirs()) {
            throw new RuntimeException("Create unzip folder failed.");
        }

        try (FileInputStream fileInputStream = new FileInputStream(file);
             BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream, BUF_SIZE);
             ZipInputStream zin = new ZipInputStream(bufferedInputStream)) {
            ZipEntry entry = null;
            while ((entry = zin.getNextEntry()) != null) {
                File newFile = new File(folder, entry.getName());
                if (entry.isDirectory()) {
                    newFile.mkdirs();
                    continue;
                }

                new File(newFile.getParent()).mkdirs();
                FileOutputStream fileOutputStream = new FileOutputStream(newFile);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream, BUF_SIZE);
                int bytesRead;
                byte[] dataBuffer = new byte[BUF_SIZE];
                while ((bytesRead = zin.read(dataBuffer)) != -1) {
                    bufferedOutputStream.write(dataBuffer, 0, bytesRead);
                }
                bufferedOutputStream.close();
                fileOutputStream.close();
            }
            // TmpManager.delete(file);
            // LOGGER.info("unzip successfully...");
        } catch (IOException e) {
            e.printStackTrace();
            // TmpManager.delete(file);
            throw new RuntimeException("unzip failed.");
        }
    }

    public static File unzipInParent(File file, File parent) {
        String folderName = TmpManager.folderName(file.getAbsolutePath());
        File folder = new File(parent, folderName);

        unzip(file, folder);
        return folder;
    }
}
