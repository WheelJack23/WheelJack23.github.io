package edu.callgraph.util;

import edu.callgraph.impurity.bean.Node;
import soot.SootMethod;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;

import java.util.HashMap;
import java.util.Map;

public class UnitGraphTool {
    private static Map<SootMethod, UnitGraph> method2unitGraph = new HashMap<>();
    public static void clean() {
        method2unitGraph.clear();
    }

    public static UnitGraph getUnitGraphFromNode(Node node) {
        SootMethod method = node.getMethod();
        return getUnitGraphFromMethod(method);
    }
    public static UnitGraph getUnitGraphFromMethod(SootMethod method) {
        if (method2unitGraph.containsKey(method)) return method2unitGraph.get(method);
        UnitGraph unitGraph = null;
        try {
            unitGraph = new ExceptionalUnitGraph(method.retrieveActiveBody());
            method2unitGraph.put(method, unitGraph);
            return unitGraph;
        } catch (Exception e) { // no method body.
            return null;
        }
    }
}
