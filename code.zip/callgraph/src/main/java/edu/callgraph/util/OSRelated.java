package edu.callgraph.util;

public class OSRelated {

    public static boolean isWindows() {
        return System.getProperties().getProperty("os.name").toUpperCase().indexOf("WINDOWS") != -1;
    }

    public static String sootCpSplitter(){
        if(isWindows()){
            return ";";
        }else{
            return ":";
        }
    }

}
