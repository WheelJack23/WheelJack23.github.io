package edu.callgraph.util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.*;
public class JsonUtil {
    public static String readJsonFile(String path) {
        String jsonStr = "";
        try {
            File jsonFile = new File(path);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            char[] cache = new char[1024];
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read(cache)) != -1) {
                sb.append(cache,0,ch);
//				sb.append(cache);

            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONObject readJsonFileAsObject(String path) {
        String s = readJsonFile(path);
        JSONObject jo = JSONObject.parseObject(s);
        return jo;

    }

    public static JSONArray readJsonFileAsArray(String path) {
        String s = readJsonFile(path);
        JSONArray ja = JSONArray.parseArray(s);
        //todo JSONArray.parseObject()
        return ja;
    }

    public static <T> List<T> castList(Object obj, Class<T> clazz) {
        List<T> result = new ArrayList<T>();
        if(obj instanceof List<?>) {
            for (Object o : (List<?>) obj) {
                result.add(clazz.cast(o));
            }
            return result;
        }
        return null;
    }
}
