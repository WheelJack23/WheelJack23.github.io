package edu.callgraph.util;

public class CGCleaner {
    public static void clean() {
        UnitGraphTool.clean();
    }
}
