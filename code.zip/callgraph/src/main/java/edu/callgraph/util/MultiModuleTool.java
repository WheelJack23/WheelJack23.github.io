package edu.callgraph.util;

import edu.callgraph.archivetransform.Transformer;
import edu.callgraph.global.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MultiModuleTool {
    private static final Logger LOGGER = LoggerFactory.getLogger(MultiModuleTool.class);

    public static List<String> getJarPaths(String path) {
        File parent = new File(path);
        Transformer.clearDir(parent);

        List<String> jarAndWars = selectJarAndWars(parent);
        if (Config.SHOW_ALL_JARS_IN_PROJECT) {
            LOGGER.info("scan the following " + jarAndWars.size() + " jar and wars: ");
            for (String jarOrWar : jarAndWars) LOGGER.info(jarOrWar);
        }
        else LOGGER.info("This project contains " + jarAndWars.size() +
                " jars and wars.\n" +
                "set Config.SHOW_ALL_JARS_IN_PROJECT to show all jars and wars.");

        jarAndWars = excludeLibJarAndWar(jarAndWars);

        List<String> result = transformWarAndSpringboot(jarAndWars);
        LOGGER.info("Reserved " + result.size() + " jars for project " + parent.getName() + ".");
        if (Config.SHOW_JARS_RESERVED) {
            for (String jarPath: result) LOGGER.info(jarPath);
        }
        else {
            LOGGER.info("set SHOW_JARS_RESERVED to show details.");
        }
        return result;
    }
    public static List<String> excludeLibJarAndWar(List<String> jarAndWars) {
        String[] words = new String[]{"\\lib\\", "/lib/",
                "\\dependency\\", "/dependency/",
                "\\libs\\", "/libs/",
                "\\.mvn\\", "/.mvn/"};
        List<String> listLeft = new ArrayList<>();
        List<String> listExcluded = new ArrayList<>();
        out:
        for (String path: jarAndWars) {
            for (String keyword: words) {
                if (path.contains(keyword)) {
                    listExcluded.add(path);
//                    LOGGER.info("exclude: " + path);
                    continue out;
                }
            }
            listLeft.add(path);
        }
        if (Config.SHOW_JARS_EXCLUDED) {
            LOGGER.info("The following jars and wars are excluded:");
            for (String jarPath: listExcluded) LOGGER.info(jarPath);
        }
        else {
            LOGGER.info("Exclude " + listExcluded.size() + " jar and wars.\n" +
                    "set Config.SHOW_JARS_EXCLUDED to show details.");
        }
        return listLeft;
    }

    private static List<String> transformWarAndSpringboot(List<String> jarAndWars) {
        List<String> result = new ArrayList<>();
        for (String filePath: jarAndWars) {
            File jarOrWar = new File(filePath);
            if (filePath.endsWith(".war")) {
                try {
                    String warPath = Transformer.transformWar(filePath).getAbsolutePath();
                    result.add(warPath);
                    LOGGER.info("transform war to ordinary jar: " + filePath);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (Transformer.isSpringbootJar(jarOrWar)) {
                try {
                    String springBootPath = Transformer.transformSpringbootJar(filePath).getAbsolutePath();
                    result.add(springBootPath);
                    LOGGER.info("transform springboot to ordinary jar: " + filePath);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            else result.add(filePath);
        }
        return result;
    }

    private static List<String> selectJarAndWars(File file) {
        List<String> jarPaths = new ArrayList<>();
        List<String> warPaths = new ArrayList<>();
        List<String> paths = new ArrayList<>();
        File[] children = file.listFiles();
        if (children == null) return paths;
        for (File child: children) {
            if (child.isDirectory()) paths.addAll(selectJarAndWars(child));
            else {
                if (child.getName().endsWith(".war")) warPaths.add(child.getAbsolutePath());
                else if (child.getName().endsWith(".jar")) jarPaths.add(child.getAbsolutePath());
            }
        }
        paths.addAll(warPaths);
        paths.addAll(jarPaths);
        paths = filterJars(paths);
        return paths;
    }


    private static List<String> filterJars(List<String> paths) {
        File[] files = new File[paths.size()];
        boolean[] shouldRemove = new boolean[paths.size()];
        List<String> result = new ArrayList<>();
        for (int i = 0 ; i < paths.size(); i++) {
            files[i] = new File(paths.get(i));
        }
        for (int i = 0; i < files.length; i++) {
            String fileIName = files[i].getName().split("\\.")[0];
            if (fileIName.contains("-dependencies")) {
                for (int j = 0 ; j < files.length; j++) {
                    if (i == j) continue;
                    String fileJName = files[j].getName().split("\\.")[0];
                    if (fileIName.contains(fileJName)) {
                        shouldRemove[i] = true;
                    }
                }
            }
        }

        for (int i = 0 ; i < shouldRemove.length;i++) {
            if (!shouldRemove[i]) {
                result.add(paths.get(i));
            }
        }

        return result;
    }

}
