package edu.callgraph.util;

import edu.callgraph.impurity.bean.Node;

import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

public class PersistUtil {

    public static Set<Node> loadNodesInProject(File projectFile) {
        Set<Node> nodes = new HashSet<>();
        File nodeDir = new File(projectFile, ".nodes");
        if (!nodeDir.exists()) return nodes;
        File[] md5Files = nodeDir.listFiles();
        if (md5Files == null) return nodes;
        for (File md5Dir: md5Files) {
            File[] nodeFiles = md5Dir.listFiles();
            if (nodeFiles == null) continue;
            for (File nodeFile: nodeFiles) {
                Node node = loadNode(nodeFile);
                nodes.add(node);
            }
        }
        return nodes;
    }

    public static void storeNodes(Set<Node> nodes, File projectFile) {
        File nodesDir = new File(projectFile, ".nodes");
        if (!nodesDir.exists()) nodesDir.mkdir();
        for (Node node: nodes) {
            String nodeMD5 = getNodeMD5(node.getMethodSignatureFull());
            File md5Dir = new File(nodesDir, nodeMD5);
            int fileIndex = 0;
            if (md5Dir.exists()) {
                Set<Node> md5Nodes = loadNodes(md5Dir);
                if (contains(md5Nodes, node)) continue;
                fileIndex = md5Nodes.size();
            }
            else md5Dir.mkdir();
            String fileName = "node" + fileIndex + ".bin";
            File nodeFile = new File(md5Dir, fileName);
            storeNode(node, nodeFile);
        }
    }

    private static boolean contains(Set<Node> md5Nodes, Node node) {
        for (Node md5Node: md5Nodes) {
            if (md5Node.getMethodSignatureFull().equals(node.getMethodSignatureFull())) return true;
        }
        return false;
    }


    private static String getNodeMD5(String methodSignature) {
        String fileName = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(methodSignature.getBytes(StandardCharsets.UTF_8));
            fileName = new BigInteger(1, md5.digest()).toString(16);
            return fileName;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            throw new RuntimeException("No MD5 algorithm. ");
        }
    }



    private static Set<Node> loadNodes(File md5Dir) {
        Set<Node> nodes = new HashSet<>();
        File[] files = md5Dir.listFiles();
        if (files == null) return nodes;
        for (File file: files) {
            Node node = loadNode(file);
            nodes.add(node);
        }
        return nodes;
    }

    private static Node loadNode(File file) {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
            Node node = (Node) ois.readObject();
            ois.close();
            return node;
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static void storeNode(Node node, File file) {
        node.setChildrenStr();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(node);
            oos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
