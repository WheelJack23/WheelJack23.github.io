package edu.callgraph.util;

import java.io.*;
import java.util.Properties;

public class PropertyUtil {

    public static void addProperty(String filePath, String key, String value) {
        FileOutputStream oFile;
        try {
            Properties prop = readProperty(filePath);
            oFile = new FileOutputStream(filePath, false);
            prop.setProperty(key, value);
            prop.store(oFile, null);
            oFile.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static Properties readProperty(String filePath) {
        Properties prop = new Properties();
        try {
            InputStream in = new BufferedInputStream(new FileInputStream(filePath));
            prop.load(in);

            in.close();
            return prop;
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return prop;
    }

}
